package Tools.Utility;



import java.awt.event.ActionEvent;
import javax.swing.JButton;

public class FrameProcess {

    //-------------------判斷按到哪一個JButton-------------------//
    public static int JButtonWhichOne(ActionEvent e, JButton[] jButton) {
        for (int i = 0; i < jButton.length; i++) {
            if (e.getSource() == jButton[i]) {
                return i;
            }
        }
        return 0;
    }
}
