DROP TABLE Customers.TempDB; -- 刪除資料表

USE Customers; -- 使用資料庫

CREATE TABLE TempDB(
	ID INTEGER(10) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
	WaittingCount INTEGER(2) DEFAULT 0, -- 最後的等待總人次
	TicketPrintNumer VARCHAR(4) DEFAULT, '0000' -- 號碼牌最後印出的號碼
	TicketPrintInitialValue VARCHAR(4) DEFAULT '0000' -- 號碼牌印出號碼初始值
);