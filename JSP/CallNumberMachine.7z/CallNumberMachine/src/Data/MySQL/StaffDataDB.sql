DROP TABLE Customers.StaffDataDB; -- 刪除資料表

USE Customers; -- 使用資料庫

CREATE TABLE StaffDataDB(
	ID INTEGER(10) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
	StaffID VARCHAR(4) DEFAULT '----', -- 員工編號
	StaffPassword VARCHAR(4) DEFAULT '----', -- 員工密碼
	StaffStatus VARCHAR(4) DEFAULT '----', -- 員工狀態
	StaffStartData VARCHAR(10) DEFAULT '1911-01-01', -- 員工就職日期
	StaffStartTime VARCHAR(12) DEFAULT '00:00:00:000', -- 員工就職時間
	StaffEndData VARCHAR(10) DEFAULT '1911-01-01', -- 員工離職日期
	StaffEndTime VARCHAR(12) DEFAULT '00:00:00:000' -- 員工離職時間
);