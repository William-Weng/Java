DROP TABLE Customers.PrinterInfo; -- 刪除資料表

USE Customers; -- 使用資料庫

CREATE TABLE PrinterInfo(
	ID INTEGER(10) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
	Text VARCHAR(4) DEFAULT '----', -- 文字內容
	TextAxisX INTEGER(4) DEFAULT '----', -- 文字X坐標
	TextAxisY INTEGER(4) DEFAULT '----', -- 文字Y坐標
	TextFont VARCHAR(30) DEFAULT '1911-01-01', -- 字體名稱
	TextFontSize VARCHAR(2) DEFAULT '----', -- 字體大小
	TextFontType VARCHAR(3) DEFAULT '1911-01-01', -- 字體樣式
	TextFontColor VARCHAR(10) DEFAULT '1911-01-01', -- 字體顏色
);