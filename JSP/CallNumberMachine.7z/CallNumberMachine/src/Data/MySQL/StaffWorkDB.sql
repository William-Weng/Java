DROP TABLE Customers.StaffWorkDB; -- 刪除資料表

USE Customers; -- 使用資料庫

CREATE TABLE StaffWorkDB(
	ID INTEGER(10) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
	StaffID VARCHAR(4) DEFAULT '----', -- 員工編號
	StaffGetTicketNumer VARCHAR(4) DEFAULT '----', -- 員工叫號的號碼
	StaffGetTicketNumerDate VARCHAR(10) DEFAULT '1911-01-01', -- 開始處理號碼牌的日期
	StaffGetTicketNumerTime VARCHAR(12) DEFAULT '00:00:00:000', -- 開始處理號碼牌的時間
	StaffeEndTicketNumerDate VARCHAR(10) DEFAULT '1911-01-01', -- 結束處理號碼牌日期
	StaffEndTicketNumerTime VARCHAR(12) DEFAULT '00:00:00:000', -- 結束處理取得號碼牌時間
	TicketStatus VARCHAR(4) DEFAULT '----' -- 號碼牌處理狀態
);