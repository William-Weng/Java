CREATE DATABASE Customers;

DROP TABLE Customers.CelledMachineDB; -- 刪除資料表

USE Customers; -- 使用資料庫

CREATE TABLE CelledMachineDB(
	ID INTEGER(10) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
	BusinessType VARCHAR(4) DEFAULT '----', -- 業務別
	TicketPrintNumer VARCHAR(4) DEFAULT '----', -- 號碼牌印出號碼
	TicketPrintDate VARCHAR(12) DEFAULT '1911-01-01', -- 號碼牌印出日期
	TicketPrintTime VARCHAR(12) DEFAULT '00:00:00:000', -- 號碼牌印出時間
	TicketStatus VARCHAR(4) DEFAULT '----' -- 號碼牌處理狀態
);

DROP TABLE Customers.StaffWorkDB; -- 刪除資料表

USE Customers; -- 使用資料庫

CREATE TABLE StaffWorkDB(
	ID INTEGER(10) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
	StaffID VARCHAR(4) DEFAULT '----', -- 員工編號
	StaffGetTicketNumer VARCHAR(4) DEFAULT '----', -- 員工叫號的號碼
	StaffGetTicketNumerDate VARCHAR(10) DEFAULT '1911-01-01', -- 開始處理號碼牌的日期
	StaffGetTicketNumerTime VARCHAR(12) DEFAULT '00:00:00:000', -- 開始處理號碼牌的時間
	StaffeEndTicketNumerDate VARCHAR(10) DEFAULT '1911-01-01', -- 結束處理號碼牌日期
	StaffEndTicketNumerTime VARCHAR(12) DEFAULT '00:00:00:000', -- 結束處理取得號碼牌時間
	TicketStatus VARCHAR(4) DEFAULT '----' -- 號碼牌處理狀態
);


DROP TABLE Customers.StaffDataDB; -- 刪除資料表

USE Customers; -- 使用資料庫

CREATE TABLE StaffDataDB(
	ID INTEGER(10) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
	StaffID VARCHAR(4) DEFAULT '----', -- 員工編號
	StaffPassword VARCHAR(4) DEFAULT '----', -- 員工密碼
	StaffStatus VARCHAR(4) DEFAULT '----', -- 員工狀態
	StaffStartData VARCHAR(10) DEFAULT '1911-01-01', -- 員工就職日期
	StaffStartTime VARCHAR(12) DEFAULT '00:00:00:000', -- 員工就職時間
	StaffEndData VARCHAR(10) DEFAULT '1911-01-01', -- 員工離職日期
	StaffEndTime VARCHAR(12) DEFAULT '00:00:00:000' -- 員工離職時間
);

DROP TABLE Customers.TempDB; -- 刪除資料表

USE Customers; -- 使用資料庫

CREATE TABLE TempDB(
	ID INTEGER(10) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
	WaittingCount INTEGER(2) DEFAULT 0, -- 最後的等待總人次
	TicketPrintNumer VARCHAR(4) DEFAULT '0000', -- 號碼牌最後印出的號碼
	TicketPrintInitialValue VARCHAR(4) DEFAULT '0000' -- 號碼牌印出號碼初始值
);

INSERT INTO Customers.TempDB (WaittingCount, TicketPrintNumer, TicketPrintInitialValue) VALUES('0','0000','0000');
INSERT INTO Customers.TempDB (WaittingCount, TicketPrintNumer, TicketPrintInitialValue) VALUES('0','5000','5000');
INSERT INTO Customers.TempDB (WaittingCount, TicketPrintNumer, TicketPrintInitialValue) VALUES('0','8000','8000');