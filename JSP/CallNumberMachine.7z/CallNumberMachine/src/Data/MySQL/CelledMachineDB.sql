DROP TABLE Customers.CelledMachineDB; -- 刪除資料表

USE Customers; -- 使用資料庫

CREATE TABLE CelledMachineDB(
	ID INTEGER(10) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
	BusinessType VARCHAR(4) DEFAULT '----', -- 業務別
	TicketPrintNumer VARCHAR(4) DEFAULT '----', -- 號碼牌印出號碼
	TicketPrintDate VARCHAR(12) DEFAULT '1911-01-01', -- 號碼牌印出日期
	TicketPrintTime VARCHAR(12) DEFAULT '00:00:00:000', -- 號碼牌印出時間
	TicketStatus VARCHAR(4) DEFAULT '----' -- 號碼牌處理狀態
);