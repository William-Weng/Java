// =====櫃檯控制器===== //
package com.safewayoa.celledmachine;

import Tools.MySQL.ExecuteDatabase;
import Tools.Utility.WordProcess;
import Tools.Utility.TimeNow;
import Tools.Utility.PlaySound;
import Tools.Utility.ArrayProcess;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;

public class ControlPanel extends JFrame {

//----------------------------------------------------變數宣告-----------------------------------------------------//
    Container ContentPane; // 取得最底層容器…
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize(); // 取得當前螢幕解析度…
    ClassLoader ClassLoading = this.getClass().getClassLoader(); // 取得當前專案的位置…

    JLabel jLabelControlPanel;
    JButton[] jButtonControlPanel = new JButton[keyNumber.length];

    int iSizeMenu[] = {
        0,
        (int) (screenSize.getWidth() / 5.0),
        (int) (screenSize.getHeight() * 0.6)
    }; // 視窗大小…

    int iTicketNumber = 0;
    int iCountOfDay = 0;
    int iWaittingCount = 0;
    int iCounterNumber = 9;
    final int iLableTextLengthMax = 4;

    static String sStaffID = "C001";
    static String sLabelStr[] = {"", ""};
    static String sStatus = "----";
    static String sLastUntreatedTicketNumber = "0000";
    static String sBusinessType = "1";
    static int iMyID = 1;
    static int[] iTicketPrintInitialValue = {0, 0, 5000, 8000};
    static final int iJButtonCount = 1 + 2; //做兩個按鍵…
    final static String[] keyNumber = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "T", "W", "S", "OK", "C", "E", "."}; // 按鈕上的數字編號…

    ArrayProcess arrayProcess = new ArrayProcess();
    PlaySound playSound = new PlaySound();
    WordProcess wordProcess = new WordProcess();

//---------------------------------------------------初始化函數---------------------------------------------------//
    public ControlPanel() {

        // 設定視窗大小跟起始位置…
        ContentPane = this.getContentPane();
        ContentPane.setLayout(null);

        initNumeric(); // 數值初始化…
        initControlPanel(); // 按鈕初始化…

        this.setTitle("控制面板測試一號機…"); // 視窗標題名稱…
        this.setBounds(1024, 0, iSizeMenu[1], iSizeMenu[2]); // 視窗起始位置、大小…
        this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE); // 設定視窗關閉按鈕…
        this.setVisible(true); // 視窗顯示開啟…
        ContentPane.setBackground(Color.ORANGE); // 視窗背景顏色…
    }

//-----------------------------------------------------建構函數----------------------------------------------------//
    public void setJLabel(String str) {
        jLabelControlPanel.setText(str);
    }

//----------------------------------------------------按鈕初始化--------------------------------------------------//
    private void initControlPanel() {

        int iJButtonSize[] = {50, 110};
        int iGap = 10;
        int iJLabelSize = 100;

        jLabelControlPanel = new JLabel("大鑫資訊", SwingConstants.CENTER);
        jLabelControlPanel.setBounds(0, 0, iSizeMenu[1], iJLabelSize);
        jLabelControlPanel.setFont(new Font("", 1, 30));
        jLabelControlPanel.setBackground(Color.BLUE);
        jLabelControlPanel.setOpaque(true);

        for (int i = 0; i < keyNumber.length; i++) {
            jButtonControlPanel[i] = new JButton(keyNumber[i]);
            jButtonControlPanel[i].setFont(new Font("", 1, 8));
            jButtonControlPanel[i].setForeground(Color.BLUE);
        }

        jButtonControlPanel[0].setBounds(iGap * 1, iSizeMenu[2] - iJButtonSize[0] * 2, iJButtonSize[1], iJButtonSize[0]);
        jButtonControlPanel[16].setBounds(iGap * 3 + iJButtonSize[0] * 2, iSizeMenu[2] - iJButtonSize[0] * 2, iJButtonSize[0], iJButtonSize[0]);
        jButtonControlPanel[13].setBounds(iGap * 4 + iJButtonSize[0] * 3, iSizeMenu[2] - iJButtonSize[0] * 6 - iGap * 4, iJButtonSize[0], iJButtonSize[0]);
        jButtonControlPanel[14].setBounds(iGap * 4 + iJButtonSize[0] * 3, iSizeMenu[2] - iJButtonSize[0] * 5 - iGap * 3, iJButtonSize[0], iJButtonSize[1]);
        jButtonControlPanel[15].setBounds(iGap * 4 + iJButtonSize[0] * 3, iSizeMenu[2] - iJButtonSize[0] * 3 - iGap * 1, iJButtonSize[0], iJButtonSize[1]);

        jButtonControlPanel[1].setBounds(iGap * 1 + iJButtonSize[0] * 0, iSizeMenu[2] - iJButtonSize[0] * 3 - iGap * 1, iJButtonSize[0], iJButtonSize[0]);
        jButtonControlPanel[2].setBounds(iGap * 2 + iJButtonSize[0] * 1, iSizeMenu[2] - iJButtonSize[0] * 3 - iGap * 1, iJButtonSize[0], iJButtonSize[0]);
        jButtonControlPanel[3].setBounds(iGap * 3 + iJButtonSize[0] * 2, iSizeMenu[2] - iJButtonSize[0] * 3 - iGap * 1, iJButtonSize[0], iJButtonSize[0]);

        jButtonControlPanel[4].setBounds(iGap * 1 + iJButtonSize[0] * 0, iSizeMenu[2] - iJButtonSize[0] * 4 - iGap * 2, iJButtonSize[0], iJButtonSize[0]);
        jButtonControlPanel[5].setBounds(iGap * 2 + iJButtonSize[0] * 1, iSizeMenu[2] - iJButtonSize[0] * 4 - iGap * 2, iJButtonSize[0], iJButtonSize[0]);
        jButtonControlPanel[6].setBounds(iGap * 3 + iJButtonSize[0] * 2, iSizeMenu[2] - iJButtonSize[0] * 4 - iGap * 2, iJButtonSize[0], iJButtonSize[0]);

        jButtonControlPanel[7].setBounds(iGap * 1 + iJButtonSize[0] * 0, iSizeMenu[2] - iJButtonSize[0] * 5 - iGap * 3, iJButtonSize[0], iJButtonSize[0]);
        jButtonControlPanel[8].setBounds(iGap * 2 + iJButtonSize[0] * 1, iSizeMenu[2] - iJButtonSize[0] * 5 - iGap * 3, iJButtonSize[0], iJButtonSize[0]);
        jButtonControlPanel[9].setBounds(iGap * 3 + iJButtonSize[0] * 2, iSizeMenu[2] - iJButtonSize[0] * 5 - iGap * 3, iJButtonSize[0], iJButtonSize[0]);

        jButtonControlPanel[10].setBounds(iGap * 1 + iJButtonSize[0] * 0, iSizeMenu[2] - iJButtonSize[0] * 6 - iGap * 4, iJButtonSize[0], iJButtonSize[0]);
        jButtonControlPanel[11].setBounds(iGap * 2 + iJButtonSize[0] * 1, iSizeMenu[2] - iJButtonSize[0] * 6 - iGap * 4, iJButtonSize[0], iJButtonSize[0]);
        jButtonControlPanel[12].setBounds(iGap * 3 + iJButtonSize[0] * 2, iSizeMenu[2] - iJButtonSize[0] * 6 - iGap * 4, iJButtonSize[0], iJButtonSize[0]);

        for (JButton jButtonControlPanel1 : jButtonControlPanel) {
            ContentPane.add(jButtonControlPanel1);
            jButtonControlPanel1.addActionListener(new jButtonActionListener());
        }

        ContentPane.add(jLabelControlPanel);
    }

//----------------------------------------------------數值初始化--------------------------------------------------//
    private void initNumeric() {

        String[] arrayStr = null;
        ExecuteDatabase execDB = new ExecuteDatabase();
        List<String> list;
        for (int ID = 1; ID < iJButtonCount; ID++) {
            list = execDB.selectTable_TempDB(ID); // 找出TempDB中，ID=1的所有值，也就是第1個按鈕的暫存器…
            arrayStr = arrayProcess.ListToArray(list);
            iTicketPrintInitialValue[ID] = Integer.parseInt(arrayStr[3]); //取得各業務的起始號碼…
            System.out.println("Integer.parseInt(arrayStr = )" + iTicketPrintInitialValue[ID]);
        }
    }

//--------------------------------------------------按鈕動作-------------------------------------------------------//
    class jButtonActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            JButton temp = (JButton) e.getSource();

            sLabelStr[0] = temp.getText(); // 取得螢幕上輸入的第一個字…

            switch (sLabelStr[0]) {

                case "C": // 清除螢幕上的文字…
                    sLabelStr[0] = "";
                    sLabelStr[1] = "";
                    jLabelControlPanel.setText("");
                    break;

                case "T": // 將號碼牌數值歸零…
                    sLabelStr[0] = "";
                    JLabelUpToZero();
                    break;

                case "W": // 將等待人數歸零…
                    sLabelStr[0] = "";
                    JLabelDownToZero();
                    break;

                case "E": // 將號碼送到其它螢幕上，並寫入資料庫…
                    KeyEnter();
                    sLabelStr[0] = "";
                    break;

                case "S": // 切換功能…
                    sLabelStr[0] = "";
                    BackColorChange();
                    break;

                case "OK": // 將號碼送到其它螢幕上，並寫入資料庫，狀態為『已完成：OK』…

                    KeyOK();
                    sLabelStr[0] = "";
                    sLabelStr[1] = "";
                    jLabelControlPanel.setText("");
                    break;

                case ".": // 未處理的號碼牌…
                    sLabelStr[0] = "";

                    String[] arrayStr = null;
                    arrayStr = FindUntreatedTicketNumber(); // 取得未處理的號碼…

                    if (!arrayStr[0].equals("0") && !arrayStr[0].equals("")) { // 沒有未處理的號碼時就顯示為上一號…
                        sLastUntreatedTicketNumber = arrayStr[0]; // 取得最前面一個未處理的號碼，並將其輸出在螢幕上…
                    }
                    sLabelStr[1] = sLastUntreatedTicketNumber;

                    jLabelControlPanel.setText(sLabelStr[1]);

                    NotOK();
                    InsertNotOK();
                    UpLabelPrint(sLabelStr[1], iCounterNumber);
                    break;

                default: // 按數字鍵時將一個個字累加起來輸出在螢幕上…
                    if (sLabelStr[1].length() < iLableTextLengthMax) {
                        sLabelStr[1] = sLabelStr[1] + sLabelStr[0];
                    }
                    jLabelControlPanel.setText(sLabelStr[1]);
                    break;
            }
        }

        //===============將號碼牌數值歸零===============//
        public void JLabelUpToZero() {
            ExecuteDatabase execDB = new ExecuteDatabase();
            execDB.update_TableDBstr(1, 0); // 將暫存資料庫的值歸零…
            UpLabelPrint("0000", iCounterNumber);  // 將值輸出到上螢幕…
        }

        //===============將等待人數歸零================//
        public void JLabelDownToZero() {
            ExecuteDatabase execDB = new ExecuteDatabase();
            execDB.update_TableDBint(iMyID, 0); // 將ID=1暫存資料庫的值歸零…
            DownLabelPrint(iMyID, 0);
        }

        //==========將已完成的號碼牌寫入資料庫，狀態為『已完成：OK』，並將號碼送到其它螢幕上========//
        public void KeyOK() {

            if (!jLabelControlPanel.getText().equals("")) { // 螢幕上有值才做下列動作…

                TimeNow nowTime = new TimeNow();
                ExecuteDatabase execDB = new ExecuteDatabase();
                List list = null;

                execDB.updateTable_CelledMachineDB(jLabelControlPanel.getText(), nowTime.getDate(), "ing", "OK"); // 將螢幕上的號碼狀態變更為：OK
                execDB.updateTable_StaffWorkDB(sStaffID, nowTime.getDate(), jLabelControlPanel.getText(), "ing", nowTime.getDate(), nowTime.getTime(), "OK");

                iWaittingCount = FindWaittingCount(iMyID); // 取得等待人數值…

                list = execDB.selectTable_TicketStatus(nowTime.getDate(), jLabelControlPanel.getText());
                String[] nowStatus;
                nowStatus = arrayProcess.ListToArray(list);

                System.out.println("nowStatus[0] = " + nowStatus[0]);

                if (nowStatus[0].equals("----")) { // 未處理的號碼才處理等待人數…

                    if (iWaittingCount > 0) { // 等待人數值少一個，如果為0的話就輸出0，並將其結果寫入資料庫…
                        execDB.update_TableDBint(iMyID, --iWaittingCount);
                        System.out.println("nowStatus[0] = " + nowStatus[0]);
                        DownLabelPrint(iMyID, iWaittingCount);
                    } else {
                        execDB.update_TableDBint(iMyID, 0);
                        DownLabelPrint(iMyID, 0);
                    }

                }

            } else {
                System.out.println("T.T");
            }

            System.out.println(iWaittingCount);
            //DownLabelPrint(ID, iWaittingCount);
        }

        //===========將號碼送到其它螢幕上===========//
        public void KeyEnter() {
            if (!jLabelControlPanel.getText().equals("")) { // 螢幕上有值才做下列動作…

                TimeNow nowTime = new TimeNow();
                ExecuteDatabase execDB = new ExecuteDatabase();

                List list = null;
                list = execDB.selectTable_TicketStatus("2014-07-18", jLabelControlPanel.getText());
                String[] nowStatus;
                nowStatus = arrayProcess.ListToArray(list); // 取得當前號碼的狀態…
                System.out.println("nowStatus[0] = " + nowStatus[0]);

                if (nowStatus[0].equals("----")) { // 未處理的號碼才處理等待人數…
                    if (iWaittingCount > 0) { // 等待人數值少一個，如果為0的話就輸出0，並將其結果寫入資料庫…
                        execDB.update_TableDBint(1, --iWaittingCount);
                        DownLabelPrint(iMyID, iWaittingCount);
                    } else {
                        execDB.update_TableDBint(1, 0);
                        DownLabelPrint(iMyID, 0);
                    }
                }

                execDB.updateTable_CelledMachineDB(jLabelControlPanel.getText(), nowTime.getDate(), "----", "ing"); // 將螢幕上的號碼狀態變更為：OK
                execDB.insertTable_StaffWorkDB(sStaffID, jLabelControlPanel.getText(), nowTime.getDate(), nowTime.getTime(), "ing");

                UpLabelPrint(sLabelStr[1], iCounterNumber);
                playSound.playWav(Integer.parseInt(jLabelControlPanel.getText()), iCounterNumber);
            }
        }

        //==============處理過號未處理的號碼=============//
        public void NotOK() {

            TimeNow nowTime = new TimeNow();
            ExecuteDatabase execDB = new ExecuteDatabase();

            execDB.updateTable_CelledMachineDB(jLabelControlPanel.getText(), nowTime.getDate(), "----", "ing"); // 將螢幕上的號碼狀態變更為：ing

            iWaittingCount = FindWaittingCount(iMyID); // 取得等待人數值…

            if (iWaittingCount > 0) { // 等待人數值少一個，如果為0的話就輸出0…
                execDB.update_TableDBint(iMyID, --iWaittingCount);
                DownLabelPrint(iMyID, iWaittingCount);
            } else {
                execDB.update_TableDBint(iMyID, 0);
                DownLabelPrint(iMyID, 0);
            }

            System.out.println(iWaittingCount);

            playSound.playWav(Integer.parseInt(jLabelControlPanel.getText()), iCounterNumber);
        }

        //==============將未完成的號碼牌寫入員工資料庫，狀態為『處理中：ing』==============//
        public void InsertNotOK() {

            if (!jLabelControlPanel.getText().isEmpty() && !jLabelControlPanel.getText().equals("0000")) { // 當螢幕上有字才寫入員工資料庫，號碼牌處理狀態為『進行中：ing』…
                TimeNow nowTime = new TimeNow();
                ExecuteDatabase execDB = new ExecuteDatabase();
                execDB.insertTable_StaffWorkDB(sStaffID, jLabelControlPanel.getText(), nowTime.getDate(), nowTime.getTime(), "ing");
            }
        }

        //~~~~~~~~~~~~~找出所有未處理的號碼~~~~~~~~~~~~~//
        public String[] FindUntreatedTicketNumber() {

            List<String> list;
            TimeNow nowTime = new TimeNow();
            String[] array = null;

            ExecuteDatabase execDB = new ExecuteDatabase();
            list = execDB.selectTable_CelledMachineDB(nowTime.getDate(), "----", sBusinessType); // 找出今天狀態為『未處理：----』的號碼

            System.out.println(list);
            array = arrayProcess.ListToArray(list);

            return array;
        }

        //~~~~~~~~~~~~找出所有TempDB的值，並取出等待人數值~~~~~~~~~~~~//
        public int FindWaittingCount(int ID) {
            int finalCount = 0;
            String[] arrayStr = null;
            List<String> list;
            ExecuteDatabase execDB = new ExecuteDatabase();

            list = execDB.selectTable_TempDB(ID); // 找出TempDB所有的值…

            arrayStr = arrayProcess.ListToArray(list);
            finalCount = Integer.parseInt(arrayStr[1]); // 只取第二列的資料 -- WaittingCount
            return finalCount;
        }

        //~~~~~~~~~~~將值輸出到上螢幕~~~~~~~~~~~~//
        public void UpLabelPrint(String sTicketNumber, int iCounterNumber) {
            Display.setjLabelDisplayUp(sTicketNumber, wordProcess.IntToString(iCounterNumber));
            Menu.setjLabelMenuUp(sTicketNumber, wordProcess.IntToString(iCounterNumber));
        }

        //~~~~~~~~~~~將值輸出到下螢幕~~~~~~~~~~~//
        public void DownLabelPrint(int ID, int iWaittingCount) {
            Display.setjLabelDisplayDown(ID, iWaittingCount);
            Menu.setjLabelMenuDown(ID, iWaittingCount);
        }

        //~~~~~~~~~~~~設定視窗功能業務範圍~~~~~~~~~~~~//
        public void BackColorChange() {

            int tempInt = Integer.parseInt(sBusinessType) + 1;

            if (tempInt > 2) {
                tempInt = 1;
            }

            switch (tempInt) {
                case 1:
                    ContentPane.setBackground(Color.ORANGE); // 視窗背景顏色…
                    iMyID = 1;
                    break;
                case 2:
                    ContentPane.setBackground(Color.GREEN); // 視窗背景顏色…
                    iMyID = 2;
                    break;
                case 3:
                    ContentPane.setBackground(Color.PINK); // 視窗背景顏色…
                    iMyID = 3;
                    break;
            }

            System.out.println("tempInt = " + tempInt);

            sBusinessType = String.valueOf(tempInt);
        }
//----------------------------------------------按鍵動作結束---------------------------------------------------------//
    }
//-----------------------------------------------------結束----------------------------------------------------------//
}
