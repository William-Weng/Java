// =====叫號機初始畫面設定===== //
package com.safewayoa.celledmachine;

import Tools.Utility.FrameProcess;
import Tools.MySQL.ExecuteDatabase;
import Tools.Utility.WordProcess;
import Tools.Utility.TimeNow;
import Tools.Utility.Printer;
import Tools.Utility.PlaySound;
import Tools.Utility.ArrayProcess;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;

public class Menu extends JFrame {

//----------------------------------------------------變數宣告-----------------------------------------------------//
    Container ContentPane; // 取得最底層容器…
    Dimension ScreenSize = Toolkit.getDefaultToolkit().getScreenSize(); // 取得當前螢幕解析度…
    ClassLoader ClassLoading = this.getClass().getClassLoader(); // 取得當前專案的位置…

    static final int iJButtonCount = 1 + 2; //做兩個按鍵…
    static JLabel jLabelMenu = new JLabel(); // 建立叫號及等待人數框…
    static JButton[] jButtonMenu = new JButton[iJButtonCount]; // 建立作用按鈕…
    static JLabel[] jLabelWaittingCount = new JLabel[iJButtonCount]; // 建立叫號及等待人數框…

    static int[] iWaittingCount = {0, 0, 0}; // 等待人次…
    static int[] iTicketNumber = {0, 1, 501}; // 號碼牌號碼…
    static int iCounterNumber = 3; // 櫃臺號碼…
    static int[] iTicketPrintInitialValue = {0, 0, 5000, 8000}; //各業務的初始號碼牌號碼…

    static String sBusinessType = "----"; // 號碼牌的業務狀態…

    final int iGap = 15; // 間隙大小…
    final int iSizeJLabel = 50; // 顯示窗大小…
    final int iFontSize = 20;

    final int iSizeMenu[] = { // 主視窗大小…
        0,
        (int) ScreenSize.getWidth() / 2,
        (int) ScreenSize.getHeight() / 2
    };

    final int iSizeButton[] = { // 按鈕大小…
        0,
        iSizeMenu[1] / 2 - 2 * iGap,
        iSizeMenu[2] - 2 * iSizeJLabel - 3 * iGap
    };

    ArrayProcess arrayProcess = new ArrayProcess();
    PlaySound playSound = new PlaySound();
    Printer printer = new Printer();
    WordProcess wordProcess = new WordProcess();

//---------------------------------------------------初始化函數---------------------------------------------------//
    public Menu() {

        ContentPane = this.getContentPane(); // 取得容器實體…
        ContentPane.setLayout(null); // 容器的排列方法…

        initNumeric(); // 數值初始化…
        initMenu(); // 按鈕初始化…

        this.setTitle("叫號機測試一號機…"); // 視窗標題名稱…
        this.setBounds(iSizeMenu[1] / 2, iSizeMenu[2] / 2, iSizeMenu[1], iSizeMenu[2] + 38); // 視窗起始位置、大小…
//        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // 設定視窗關閉按鈕…
        this.setVisible(true); // 視窗顯示開啟…
        this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE); // 設定視窗關閉按鈕…

        ContentPane.setBackground(Color.BLACK); // 視窗背景顏色…
    }

//-----------------------------------------------------取值方法----------------------------------------------------//
    public static int getTicketNumber(int ID) {
        return iTicketNumber[ID];
    }

    public static void setTicketNumber(int ID, int intTicketNumber) {
        iTicketNumber[ID] = intTicketNumber;
    }

    public static void setjLabelMenuUp(String number, String counter) {
        jLabelMenu.setText("來賓 " + number + " 號 請至 " + counter + " 號櫃臺辦理…");
    }

    public static void setjLabelMenuDown(int ID, int count) {
        jLabelWaittingCount[ID].setText("等待人數" + count + "人…");
    }

//----------------------------------------------------按鈕初始化--------------------------------------------------//
    private void initMenu() {

        jLabelMenu = new JLabel("來賓 " + wordProcess.IntToString(iTicketNumber[1]) + " 號 請至 " + wordProcess.IntToString(iCounterNumber) + " 號櫃臺辦理…", SwingConstants.CENTER); // 設定初值…
        jLabelMenu.setFont(new Font("", Font.BOLD, iFontSize)); // 設定字型…
        jLabelMenu.setBackground(Color.BLUE); // 設定背景顏色…
        jLabelMenu.setOpaque(true); // 設定背景是否不透明…

        jButtonMenu[1] = new JButton("一般業務…");
        jButtonMenu[1].setFont(new Font("", Font.BOLD, iFontSize));
        jButtonMenu[1].setForeground(Color.BLUE);
        jButtonMenu[1].setBackground(Color.ORANGE);
        jButtonMenu[1].setBorder(null); // 把邊框去掉…
        //jButtonMenu[1].setIcon(new ImageIcon(ClassLoading.getResource("./image/1.jpg")));
        //jButtonMenu[1].setRolloverIcon(new ImageIcon(ClassLoading.getResource("./image/2.jpeg")));
        jButtonMenu[1].setMnemonic('1'); // 設定輔助辨識碼… alt + 1
        jButtonMenu[1].addActionListener(new jButtonActionListener()); // 使用按鍵的動作方式…

        jLabelWaittingCount[1] = new JLabel("等待人數" + iWaittingCount[1] + "人…", SwingConstants.CENTER);
        jLabelWaittingCount[1].setFont(new Font("", Font.BOLD, iFontSize)); // 設定字型…
        jLabelWaittingCount[1].setBackground(Color.ORANGE); // 設定背景顏色…
        jLabelWaittingCount[1].setOpaque(true); // 設定背景是否不透明…

        jButtonMenu[2] = new JButton("金融業務…");
        jButtonMenu[2].setFont(new Font("", Font.BOLD, iFontSize));
        jButtonMenu[2].setForeground(Color.BLUE);
        jButtonMenu[2].setBackground(Color.GREEN);
        jButtonMenu[2].setBorder(null); // 把邊框去掉…
        jButtonMenu[2].addActionListener(new jButtonActionListener());

        jLabelWaittingCount[2] = new JLabel("等待人數" + iWaittingCount[2] + "人…", SwingConstants.CENTER);
        jLabelWaittingCount[2].setFont(new Font("", Font.BOLD, iFontSize)); // 設定字型…
        jLabelWaittingCount[2].setBackground(Color.GREEN); // 設定背景顏色…
        jLabelWaittingCount[2].setOpaque(true); // 設定背景是否不透明…

        //============設定JLabel跟JButton的位置===========//
        jLabelMenu.setBounds(0, 0, iSizeMenu[1], iSizeJLabel); // 設定(x, y ,寬, 高)…

        jButtonMenu[1].setBounds(iGap, iSizeJLabel + iGap, iSizeButton[1], iSizeButton[2]);
        jLabelWaittingCount[1].setBounds(iGap, iSizeJLabel + iSizeButton[2] + iGap * 2, iSizeButton[1], iSizeJLabel); // 設定(x, y ,寬, 高)…

        jButtonMenu[2].setBounds(iSizeMenu[1] / 2, iSizeJLabel + iGap, iSizeButton[1], iSizeButton[2]);
        jLabelWaittingCount[2].setBounds(iSizeMenu[1] / 2, iSizeJLabel + iSizeButton[2] + iGap * 2, iSizeButton[1], iSizeJLabel); // 設定(x, y ,寬, 高)…

        //============將Label跟Button加入容器中===========//
        for (int i = 1; i < iJButtonCount; i++) {
            ContentPane.add(jButtonMenu[i]);
            ContentPane.add(jLabelWaittingCount[i]);
        }
        ContentPane.add(jLabelMenu);

    }

//----------------------------------------------------數值初始化--------------------------------------------------//
    private void initNumeric() {
        String[] arrayStr = null;
        ExecuteDatabase execDB = new ExecuteDatabase();
        List<String> list;

        for (int ID = 1; ID < iJButtonCount; ID++) {
            list = execDB.selectTable_TempDB(ID); // 找出TempDB中，ID=1的所有值，也就是第1個按鈕的暫存器…
            arrayStr = arrayProcess.ListToArray(list);
            iWaittingCount[ID] = Integer.parseInt(arrayStr[1]); // 只取第二列的資料 -- WaittingCount
            iTicketNumber[ID] = Integer.parseInt(arrayStr[2]); // 只取第三列的資料 -- TicketNumber
            iTicketPrintInitialValue[ID] = Integer.parseInt(arrayStr[3]); //取得各業務的起始號碼…
//            System.out.println("Integer.parseInt(arrayStr = )" +iTicketPrintInitialValue[ID]);
//            System.out.println("第" + ID + "次初始化數值：" + iWaittingCount[ID] + "跟" + iTicketNumber[ID]);
        }
    }

//--------------------------------------------------按鈕動作-------------------------------------------------------//
    class jButtonActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            int ID = FrameProcess.JButtonWhichOne(e, jButtonMenu); // 看按到哪個按鈕…
            System.out.println("ID = " + ID);

            JButton tempJBtutton = (JButton) e.getSource();
            TimeNow timeTemp = new TimeNow();
            ExecuteDatabase execDB = new ExecuteDatabase();

            initNumeric();

            iTicketNumber[ID]++; // 將號碼跟等待人數+1
            iWaittingCount[ID]++;

            System.out.println("iTicketNumber[" + ID + "] =" + iTicketNumber[ID]);

            for (int i = 1; i < iJButtonCount; i++) { // 尋找號碼牌分組的狀態，例如：001~699／700~799／800~999…
                if ((iTicketNumber[ID] / (iTicketPrintInitialValue[i] + 1)) >= 1) {
                    sBusinessType = String.valueOf(i);
                }
            }

            execDB.insertTable_CelledMachineDB(iTicketNumber[ID], timeTemp.getDate(), timeTemp.getTime(), sBusinessType); // 將號碼牌印出的時間寫入資料庫
            execDB.update_TableDBint(ID, iWaittingCount[ID]); // 更新號碼跟等待人數…
            execDB.update_TableDBstr(ID, iTicketNumber[ID]);

            jLabelMenu.setText("來賓 " + wordProcess.IntToString(iTicketNumber[ID]) + " 號 請至 " + wordProcess.IntToString(iCounterNumber) + " 號櫃臺辦理…");
            jLabelWaittingCount[ID].setText("等待人數" + iWaittingCount[ID] + "人…");

            Display.setjLabelDisplayUp(wordProcess.IntToString(iTicketNumber[ID]), wordProcess.IntToString(iCounterNumber));
            Display.setjLabelDisplayDown(ID, iWaittingCount[ID]);

            printer.PrintNumber(iTicketNumber[ID], timeTemp.getAllTime()); // 印出號碼與等待時間…
            playSound.playWav(iTicketNumber[ID], iCounterNumber);
        }
    }
//-----------------------------------------------------結束----------------------------------------------------------//
}
