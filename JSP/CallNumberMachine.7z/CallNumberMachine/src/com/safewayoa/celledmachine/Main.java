package com.safewayoa.celledmachine;

public class Main {

    public static void main(String[] args) {
        Menu menu = new Menu();
        Display display = new Display();
        ControlPanel controlPanel = new ControlPanel();
    }
}
