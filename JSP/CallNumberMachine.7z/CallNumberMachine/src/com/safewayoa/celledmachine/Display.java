// =====顯示幕初始畫面設定===== //
package com.safewayoa.celledmachine;

import Tools.MySQL.ExecuteDatabase;
import Tools.Utility.WordProcess;
import Tools.Utility.ArrayProcess;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;

public class Display extends JFrame {

//----------------------------------------------------變數宣告-----------------------------------------------------//
    Container ContentPane; // 取得最底層容器…
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize(); // 取得當前螢幕解析度…
    ClassLoader ClassLoading = this.getClass().getClassLoader(); // 取得當前專案的位置…

    static JLabel[] jLabelDisplay = new JLabel[2]; // 建立叫號及等待人數框…

    final int iSizeDisplay[] = {
        0,
        (int) screenSize.getWidth() / 2,
        (int) screenSize.getHeight() / 2
    }; // 視窗大小

    int[] iWaittingCount = {0, 0, 0}; // 等待人次…
    int iCounterNumber = 10; // 櫃臺號碼…
    final int iSizeJLabel = 50; // 顯示窗大小…
    static int[] iTicketNumber = {0, 0, 0}; // 號碼牌號碼…

    ArrayProcess arrayProcess = new ArrayProcess();
    WordProcess wordProcess = new WordProcess();

//-------------------------------------------------初始化函數------------------------------------------------------//
    public Display() {

        ContentPane = this.getContentPane(); // 取得容器實體…
        ContentPane.setLayout(null); // 容器的排列方法…

        initNumeric(); // 數值初始化…
        initDisplay(); // 按鈕初始化…

        this.setTitle("多媒體測試一號機…"); // 視窗標題名稱…
        this.setBounds(0, 0, iSizeDisplay[1], iSizeDisplay[2] + 38); // 視窗起始位置、大小…
        this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE); // 設定視窗關閉按鈕…
        this.setVisible(true); // 視窗顯示開啟…
        ContentPane.setBackground(Color.BLACK); // 視窗背景顏色…
    }

//-----------------------------------------------------建構函數----------------------------------------------------//
    public static void setjLabelDisplayUp(String str, String counter) {
        jLabelDisplay[0].setText("來賓 " + str + " 號 請至 " + counter + " 號櫃臺辦理…");
    }

    public static void setjLabelDisplayDown(int ID, int number) {
        jLabelDisplay[1].setText("等待人數" + number + "人…");
    }

//----------------------------------------------------按鈕初始化--------------------------------------------------//
    private void initDisplay() {

        jLabelDisplay[0] = new JLabel("來賓 " + wordProcess.IntToString(iTicketNumber[1]) + " 號 請至 " + wordProcess.IntToString(iCounterNumber) + " 號櫃臺辦理…", SwingConstants.CENTER);
        jLabelDisplay[0].setBounds(0, 0, iSizeDisplay[1], iSizeJLabel);
        jLabelDisplay[0].setFont(new Font("", 1, 20));
        jLabelDisplay[0].setBackground(Color.BLUE);
        jLabelDisplay[0].setOpaque(true);

        jLabelDisplay[1] = new JLabel("等待人數" + iWaittingCount[1] + "人…", SwingConstants.CENTER);
        jLabelDisplay[1].setBounds(0, iSizeDisplay[2] - iSizeJLabel, iSizeDisplay[1], iSizeJLabel);
        jLabelDisplay[1].setFont(new Font("", 1, 20));
        jLabelDisplay[1].setBackground(Color.ORANGE);
        jLabelDisplay[1].setOpaque(true);

        ContentPane.add(jLabelDisplay[0]);
        ContentPane.add(jLabelDisplay[1]);
    }

//----------------------------------------------------數值初始化--------------------------------------------------//
    private void initNumeric() {
        ExecuteDatabase execDB = new ExecuteDatabase();
        List<String> list;
        String[] arrayStr = null;
        list = execDB.selectTable_TempDB(1);
        arrayStr = arrayProcess.ListToArray(list);

        iWaittingCount[1] = Integer.parseInt(arrayStr[1]); // 只取第二列的資料 -- WaittingCount
        iTicketNumber[1] = Integer.parseInt(arrayStr[2]); // 只取第三列的資料 -- TicketNumber
    }
//-----------------------------------------------------結束----------------------------------------------------------//
}
