package Setup;

import java.awt.event.ActionEvent;
import javax.swing.JButton;

public class FrameProcess {

    //-------------------判斷按到哪一個JButton-------------------//
    public int JObjectWhichOne(Object eGetSource, Object... jObject) {
        for (int i = 0; i < jObject.length; i++) {
            if (eGetSource == jObject[i]) {
                return i;
            }
        }
        return 0;
    }

    //-------------------判斷按到哪一個JButton-------------------//
    public static int JButtonWhichOne(ActionEvent e, JButton[] jButton) {
        for (int i = 0; i < jButton.length; i++) {
            if (e.getSource() == jButton[i]) {
                return i;
            }
        }
        return 0;
    }
}
