package Setup;

public class Main {

    public static void main(String[] args) {
        _SetupPrinterTitle ticketPrintType = new _SetupPrinterTitle();
    }
}
