// ======文數字處理====== //
package Setup;

import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

public class WordProcess {

    private final String wavFile[] = {
        "src/wav/0.wav",
        "src/wav/1.wav",
        "src/wav/2.wav",
        "src/wav/3.wav",
        "src/wav/4.wav",
        "src/wav/5.wav",
        "src/wav/6.wav",
        "src/wav/7.wav",
        "src/wav/8.wav",
        "src/wav/9.wav",
        "src/wav/來賓.wav",
        "src/wav/號.wav",
        "src/wav/請.wav",
        "src/wav/櫃台.wav"
    };

    //-------------------------將10轉成0010------------------------//
    public String IntToString(int number) {
        String str = "";

        if (number / 10000 == 0) {
            str = "" + number;
        }

        if (number / 1000 == 0) {
            str = "0" + number;
        }

        if (number / 100 == 0) {
            str = "00" + number;
        }

        if (number / 10 == 0) {
            str = "000" + number;
        }

        return str;
    }

    //----------------------將0005轉成0005.wav-----------------------//
    public List<String> IntToWav(int number, int counter) {
        List<String> list = new ArrayList();
        String str1 = this.IntToString(number);
        char[] arrayChar = str1.toCharArray();
        int index = 0;

        list.add(wavFile[10]); // 來賓.wav

        for (char charStr : arrayChar) {
            list.add(wavFile[Integer.parseInt(String.valueOf(charStr))]); // 1→1.wav
            System.out.println(charStr);
        }

        list.add(wavFile[11]); // 號.wav
        list.add(wavFile[12]); // 請.wav
        list.add(wavFile[counter]);
        list.add(wavFile[11]); // 號.wav
        list.add(wavFile[13]); // 櫃台.wav

        System.out.println(list);

        return list;
    }

    //-------把文字轉成HTML顯示-------//
    public List<String> TextToHTML(String sText) {

        List<String> _list = new ArrayList();

        String _sText = "";
        int _iAmountBR = 0;
        for (int i = 0; i < sText.length(); i++) {

            switch (sText.charAt(i)) {
                case KeyEvent.VK_SPACE:
                    _sText += "&nbsp;";
                    break;
                case '_':
                    _sText += "<BR/>";
                    _iAmountBR++;
                    break;
                case KeyEvent.VK_ENTER:
                    break;
                case KeyEvent.VK_LESS:
                    _sText += "$amp;";
                    break;
                default:
                    _sText += sText.charAt(i);
            }
        }

        _sText = "<HTML>" + _sText + "</HTML>";
        System.out.println("_sText = " + _sText);
        _list.add(_sText);
        _list.add(String.valueOf(_iAmountBR));

        return _list;
    }

}
