package Setup;

import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;

public class TestJTextArea extends JFrame {

    Container ContentPane; // 視窗本體…
    JTextArea[] jTextArea = new JTextArea[3];
    JButton jButtonSetup; // 設定按鈕…

    ArrayProcess arrayProcess = new ArrayProcess();

    public TestJTextArea() {

        ContentPane = this.getContentPane();
        ContentPane.setBackground(Color.GREEN);
        ContentPane.setLayout(null);

        this.init();

        this.setTitle("設定號碼牌的列印外觀…");
        this.setBounds(100, 100, 640, 480);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    private void init() {
        for (int i = 0; i < jTextArea.length; i++) {
            jTextArea[i] = new JTextArea("");
            jTextArea[i].setBounds(200 * (i + 1), 100, 100, 50);
            jTextArea[i].setLineWrap(rootPaneCheckingEnabled); // 設置換行

            ContentPane.add(jTextArea[i]);
        }
        jButtonSetup = new JButton("測試用");
        jButtonSetup.setBounds(300, 200, 50, 50);
        jButtonSetup.addActionListener(new jButtonActionListener());
        ContentPane.add(jButtonSetup);
    }

    class jButtonActionListener implements ActionListener {

        List<String> _list = new ArrayList();

        @Override
        public void actionPerformed(ActionEvent e) {
            jTextArea[1].setEditable(false);
            jTextArea[1].setOpaque(false);
            jTextArea[1].setText(jTextArea[0].getText());
            _list.add(jTextArea[0].getText());

            arrayProcess.WriteFile(_list, "D:/1.ini");
            _list = arrayProcess.ReadFile("D:/1.ini");
            Object[] _oText;
            _oText = _list.toArray();

            for (int i = 0; i < _oText.length; i++) {
                System.out.println(_oText[i]);

                jTextArea[2].append(_oText[i].toString() + "\n");
            }
        }
    }

    public static void main(String[] args) {
        TestJTextArea testJTextArea = new TestJTextArea();
    }
}
