package Setup;

public class DataTextInput {

    private String sText; // 文字內容…
    private int iAxisX; // X坐標…
    private int iAxisY; // Y坐標…
    private int iSizeFont; // 字體大小…
    private String sTypeFont; // 字體樣式…
    private String sNameFont; // 字體名稱…
    private int iNumberUnderline; // 底線數量…
    private int iLengthText; // 文字長度…

    public int getAxisX() {
        return iAxisX;
    }

    public int getAxisY() {
        return iAxisY;
    }

    public int getLengthText() {
        return iLengthText;
    }

    public int getNumberUnderline() {
        return iNumberUnderline;
    }

    public int getSizeFont() {
        return iSizeFont;
    }

    public String getNameFont() {
        return sNameFont;
    }

    public String getText() {
        return sText;
    }

    public String getTypeFont() {
        return sTypeFont;
    }

    public void setAxisX(int iAxisX) {
        this.iAxisX = iAxisX;
    }

    public void setAxisY(int iAxisY) {
        this.iAxisY = iAxisY;
    }

    public void setLengthText(int iLengthText) {
        this.iLengthText = iLengthText;
    }

    public void setNumberNnderline(int iNumberUnderline) {
        this.iNumberUnderline = iNumberUnderline;
    }

    public void setSizeFont(int iSizeFont) {
        this.iSizeFont = iSizeFont;
    }

    public void setNameFont(String sNameFont) {
        this.sNameFont = sNameFont;
    }

    public void setText(String sText) {
        this.sText = sText;
    }

    public void setTypeFont(String sTypeFont) {
        this.sTypeFont = sTypeFont;
    }
}
