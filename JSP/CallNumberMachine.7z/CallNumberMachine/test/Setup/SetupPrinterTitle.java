package Setup;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class SetupPrinterTitle extends JFrame {

    Container ContentPane; // 視窗本體…
    JPanel jPanelBasic; // 列印單的底部…
    JTextArea jTextAreaAdvert; // 廣告輸入框…
    JLabel jLabelAreaAdvert; // 廣告輸出Label…

    JButton[] jButtonSetup; // 設定按鈕…
    JLabel[] jLabelText, jLabelTitle; // 說明文字…
    JTextField[] jTextField, jTextFieldSizePanel; // 文字輸入框…
    JComboBox[] jComboBoxFontSize, jComboBoxFontType, jComboBoxFont; // 文字屬性選單…

    FrameProcess frameProcess = new FrameProcess();
    ArrayProcess arrayProcess = new ArrayProcess();

    private final int iNumber = 1 + 8; // 有1+N個…
    private final int iCounter = 1 + 9; // 有1+N項…
    private final int iGapTextField = 50; // 間距
    private final int iGapComboBox = 20; // 間距
    private final int iGapPanel = 50; // 間距
    private final int iGapFont = 5; // 間距

    private final String sPathPrinterDoc = "D:/TicketBase.ini"; // 列印時的文字格式設定檔…
    private final String _sPathPrinterDoc = "D:/_TicketBase.ini"; // 列印時的文字格式設定檔…

    private final int[] iTypeFont = {
        Font.PLAIN, Font.BOLD, Font.ITALIC, Font.BOLD + Font.ITALIC
    }; // 一般、粗體、斜體、粗體+斜體…

    private final static String[] sSizeFont = {
        "6", "8", "10", "12", "14", "16",
        "18", "20", "22", "24", "26", "28",
        "30", "32", "34", "36", "38", "40"
    }; // 設定字體大小(pt)…

    private final static String[] sTypeFont = {
        "標準", "粗體", "斜體", "粗斜體"
    }; // 設定字體樣式…

    private final String[] sNameFont = {
        "Digital Readout ExpUpright", "LcdD", "Segoe Print", "Segoe Script", "Times New Roman",
        "細明體", "新細明體", "標楷體", "微軟正黑體", "文泉驛等寬微米黑"
    }; // 字型…

    int[] iSizeFontJLabelText = new int[iNumber]; // JLabel上字型大小…
    String[] sTypeFontJLabelText = new String[iNumber]; // JLabel上字型樣式…
    String[] sNameFontJLabelText = new String[iNumber]; // JLabel上字型名稱…

    int[] iLocationContainer = {0, 60, 60};  // 位置 (0, x, y)…
    int[] iSizeContainer = {0, 800, 600};  // 大小 (0, 寬, 高)…

    int[] iLocationJPanel = {0, 300, 20};
    int[] iSizeJPanel = {0, 200, 300};

    int[] iLocationjTextField = {0, 20, 40};
    int[] iSizeTextField = {0, 250, 40};

    int[][] iLocationJLabelText = new int[iNumber][3]; // JLabel上位置…
    int[] iSizeLabelText = {0, 300, 45};

    int[] iLocationJLabelTitle = {0, 10, 10};
    int[] iSizeJLabelTitle = {0, 100, 20};

    int[] iLocationJComboBox = {0, 10, 10};
    int[][] iSizeJComboBox = {
        {0, 0, 0},
        {1, 50, 40},
        {2, 70, 40},
        {3, 120, 40}
    };

    int[] iSizeJButton = {0, 90, 20};
    int[] iSizeTextFieldPanel = {0, 90, 20};

    private int x0, y0; // 滑鼠點擊的點 (x0, y0)
    static int index = 1; // 第幾個Label…
    int iSizeFontJLabelTitle = 16;

    boolean jButtonSaveKeyed = false;

    //-----------------------------------------------------------//
    public SetupPrinterTitle() {

        ContentPane = this.getContentPane();
        ContentPane.setBackground(Color.GREEN);
        ContentPane.setLayout(null);

        this.initPrintType(); // 初始化按鍵…
        this.initNumeric(sPathPrinterDoc); // 初始化數值…

        this.setTitle("設定號碼牌的列印外觀…");
        this.setBounds(iLocationContainer[1], iLocationContainer[2], iSizeContainer[1], iSizeContainer[2]);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    //-----------------------------------------------------------//
    private void initPrintType() {

        jLabelText = new JLabel[iNumber];
        jTextField = new JTextField[iNumber];
        jComboBoxFontSize = new JComboBox[iNumber];
        jComboBoxFontType = new JComboBox[iNumber];
        jComboBoxFont = new JComboBox[iNumber];
        jLabelTitle = new JLabel[iCounter];
        jButtonSetup = new JButton[1 + 3];
        jTextFieldSizePanel = new JTextField[1 + 2];
        jLabelAreaAdvert = new JLabel();

        iLocationJLabelTitle[1] = (iSizeTextField[1] - 20) / 2;
        iLocationJLabelTitle[2] = iLocationjTextField[2] - 25;

        iLocationJComboBox[1] = iSizeTextField[1] + iGapComboBox;
        iLocationJComboBox[2] = iLocationjTextField[2];

        iLocationJPanel[1] = iSizeTextField[1] + iSizeJComboBox[1][1] + iSizeJComboBox[2][1] + iSizeJComboBox[3][1] + iGapPanel;
        iLocationJPanel[2] = iLocationjTextField[2];

        jLabelTitle[1] = new JLabel("文字輸入");
        jLabelTitle[1].setBounds(iLocationJLabelTitle[1], iLocationJLabelTitle[2], iSizeJLabelTitle[1], iSizeJLabelTitle[2]);
        jLabelTitle[1].setFont(new Font("標楷體", iTypeFont[0], iSizeFontJLabelTitle));

        jLabelTitle[2] = new JLabel("大小");
        jLabelTitle[2].setBounds(iLocationJLabelTitle[1] + 155, iLocationJLabelTitle[2], iSizeJLabelTitle[1], iSizeJLabelTitle[2]);
        jLabelTitle[2].setFont(new Font("標楷體", iTypeFont[1], iSizeFontJLabelTitle));

        jLabelTitle[3] = new JLabel("樣式");
        jLabelTitle[3].setBounds(iLocationJLabelTitle[1] + 215, iLocationJLabelTitle[2], iSizeJLabelTitle[1], iSizeJLabelTitle[2]);
        jLabelTitle[3].setFont(new Font("標楷體", iTypeFont[1], iSizeFontJLabelTitle));

        jLabelTitle[4] = new JLabel("字型");
        jLabelTitle[4].setBounds(iLocationJLabelTitle[1] + 305, iLocationJLabelTitle[2], iSizeJLabelTitle[1], iSizeJLabelTitle[2]);
        jLabelTitle[4].setFont(new Font("標楷體", iTypeFont[1], iSizeFontJLabelTitle));

        jLabelTitle[5] = new JLabel("示意圖");
        jLabelTitle[5].setBounds(iLocationJLabelTitle[1] + 500, iLocationJLabelTitle[2], iSizeJLabelTitle[1], iSizeJLabelTitle[2]);
        jLabelTitle[5].setFont(new Font("標楷體", iTypeFont[1], iSizeFontJLabelTitle));

        for (int i = 1; i < iNumber; i++) {
            jTextField[i] = new JTextField();
            jTextField[i].setBounds(iLocationjTextField[1], iLocationjTextField[2] + iGapTextField * (i - 1), iSizeTextField[1], iSizeTextField[2]);
            jTextField[i].setFont(new Font("", iTypeFont[1], 14));
            jTextField[i].getDocument().addDocumentListener(new jTextFieldDocumentListener());
            jTextField[i].addMouseListener(new jTextFieldMouseListener());
            jTextField[i].addKeyListener(new jTextFieldKeyListener());

            jComboBoxFontSize[i] = new JComboBox(sSizeFont);
            jComboBoxFontSize[i].setBounds(iLocationJComboBox[1], iLocationJComboBox[2] + iGapTextField * (i - 1), iSizeJComboBox[1][1], iSizeJComboBox[1][2]);
            jComboBoxFontSize[i].setFont(new Font("", iTypeFont[1], 14));
            jComboBoxFontSize[i].addActionListener(new jComboBoxFontSizeActionListener());

            jComboBoxFontType[i] = new JComboBox(sTypeFont);
            jComboBoxFontType[i].setBounds(iLocationJComboBox[1] + iSizeJComboBox[1][1], iLocationJComboBox[2] + iGapTextField * (i - 1), iSizeJComboBox[2][1], iSizeJComboBox[2][2]);
            jComboBoxFontType[i].setFont(new Font("", iTypeFont[1], 14));
            jComboBoxFontType[i].addActionListener(new jComboBoxFontTypeActionListener());

            jComboBoxFont[i] = new JComboBox(sNameFont);
            jComboBoxFont[i].setBounds(iLocationJComboBox[1] + iSizeJComboBox[1][1] + iSizeJComboBox[2][1], iLocationJComboBox[2] + iGapTextField * (i - 1), iSizeJComboBox[3][1], iSizeJComboBox[3][2]);
            jComboBoxFont[i].setFont(new Font("", iTypeFont[1], 14));
            jComboBoxFont[i].addActionListener(new jComboBoxFontActionListener());

            jLabelText[i] = new JLabel();
            jLabelText[i].setBounds(iSizeTextField[1] + iSizeJComboBox[1][1] + iSizeJComboBox[2][1] + iSizeJComboBox[3][1] + iGapPanel, iLocationjTextField[2] + iGapTextField * (i - 1), iSizeLabelText[1], iSizeLabelText[2]);
            jLabelText[i].setFont(new Font("", iTypeFont[1], 16));
            jLabelText[i].addMouseListener(new jLabelTextMouseAdapter());
            jLabelText[i].addMouseMotionListener(new jLabelTextMouseMotionAdapter());
        }

        jPanelBasic = new JPanel();
        jPanelBasic.setBounds(iLocationJPanel[1], iLocationJPanel[2], iSizeJPanel[1], iSizeJPanel[2]);
        jPanelBasic.setFont(new Font("", iTypeFont[1], 16));
        jPanelBasic.setOpaque(rootPaneCheckingEnabled);
        jPanelBasic.setBackground(Color.WHITE);

        jButtonSetup[1] = new JButton("存入");
        jButtonSetup[1].setBounds(iLocationJPanel[1], iSizeJPanel[2] + 50, iSizeJButton[1], iSizeJButton[2]);
        jButtonSetup[1].setFont(new Font("", iTypeFont[1], 12));
        jButtonSetup[1].addActionListener(new jButtonSaveActionListener());

        jButtonSetup[2] = new JButton("還原");
        jButtonSetup[2].setBounds(iLocationJPanel[1] + iSizeJButton[1] + 20, iSizeJPanel[2] + 50, iSizeJButton[1], iSizeJButton[2]);
        jButtonSetup[2].setFont(new Font("", iTypeFont[1], 12));
        jButtonSetup[2].addActionListener(new jButtonResetActionListener());

        jLabelTitle[6] = new JLabel("長");
        jLabelTitle[6].setBounds(iLocationJPanel[1], iSizeJPanel[2] + 80, iSizeJLabelTitle[1], iSizeJLabelTitle[2]);
        jLabelTitle[6].setFont(new Font("標楷體", iTypeFont[1], iSizeFontJLabelTitle));

        jLabelTitle[7] = new JLabel("寬");
        jLabelTitle[7].setBounds(iLocationJPanel[1], iSizeJPanel[2] + 120, iSizeJLabelTitle[1], iSizeJLabelTitle[2]);
        jLabelTitle[7].setFont(new Font("標楷體", iTypeFont[1], iSizeFontJLabelTitle));

        jButtonSetup[3] = new JButton("設定大小");
        jButtonSetup[3].setBounds(iLocationJPanel[1] + iSizeJButton[1] + 20, iSizeJPanel[2] + 80, iSizeJButton[1], iSizeJButton[2] * 3);
        jButtonSetup[3].setFont(new Font("", iTypeFont[1], 12));
        jButtonSetup[3].addActionListener(new jButtonSetJPanelSizeActionListener());

        jTextFieldSizePanel[1] = new JTextField();
        jTextFieldSizePanel[1].setBounds(iLocationJPanel[1] + 25, iSizeJPanel[2] + 80, iSizeTextFieldPanel[1] - 50, iSizeTextFieldPanel[2]);
        jTextFieldSizePanel[1].setFont(new Font("", iTypeFont[1], 14));
        jTextFieldSizePanel[1].addKeyListener(new jTextFieldSizePanelKeyListener());

        jTextFieldSizePanel[2] = new JTextField();
        jTextFieldSizePanel[2].setBounds(iLocationJPanel[1] + 25, iSizeJPanel[2] + 120, iSizeTextFieldPanel[1] - 50, iSizeTextFieldPanel[2]);
        jTextFieldSizePanel[2].setFont(new Font("", iTypeFont[1], 14));
        jTextFieldSizePanel[2].addKeyListener(new jTextFieldSizePanelKeyListener());

        jLabelTitle[8] = new JLabel("px");
        jLabelTitle[8].setBounds(iLocationJPanel[1] + 70, iSizeJPanel[2] + 80, iSizeJLabelTitle[1], iSizeJLabelTitle[2]);
        jLabelTitle[8].setFont(new Font("標楷體", iTypeFont[1], iSizeFontJLabelTitle));

        jLabelTitle[9] = new JLabel("px");
        jLabelTitle[9].setBounds(iLocationJPanel[1] + 70, iSizeJPanel[2] + 120, iSizeJLabelTitle[1], iSizeJLabelTitle[2]);
        jLabelTitle[9].setFont(new Font("標楷體", iTypeFont[1], iSizeFontJLabelTitle));

        jTextAreaAdvert = new JTextArea();
        jTextAreaAdvert.setBounds(iLocationjTextField[1], iLocationjTextField[2] + iGapTextField * (iNumber - 1), iSizeTextField[1], iSizeTextField[2] * 3);
        jTextAreaAdvert.setFont(new Font("", iTypeFont[1], 14));
        jTextAreaAdvert.getDocument().addDocumentListener(new jTextAreaAdvertDocumentListener());

        jLabelAreaAdvert = new JLabel("123456789");
        jLabelAreaAdvert.setBounds(iSizeTextField[1] + iSizeJComboBox[1][1] + iSizeJComboBox[2][1] + iSizeJComboBox[3][1] + iGapPanel, iLocationjTextField[2] + iGapTextField * (iNumber - 1), iSizeLabelText[1], iSizeLabelText[2]);
        jLabelAreaAdvert.setFont(new Font("", iTypeFont[1], 16));
        jLabelAreaAdvert.addMouseListener(new jLabelTextMouseAdapter());
        jLabelAreaAdvert.addMouseMotionListener(new jLabelAreaAdvertMouseMotionAdapter());

        //=======將元件加入至容器中=======//
        for (int i = 1; i < jLabelText.length; i++) {
            ContentPane.add(jLabelText[i]);
        }

        for (int i = 1; i < jTextField.length; i++) {
            ContentPane.add(jTextField[i]);
        }

        for (int i = 1; i < jComboBoxFontSize.length; i++) {
            ContentPane.add(jComboBoxFontSize[i]);
        }

        for (int i = 1; i < jComboBoxFontType.length; i++) {
            ContentPane.add(jComboBoxFontType[i]);
        }

        for (int i = 1; i < jComboBoxFont.length; i++) {
            ContentPane.add(jComboBoxFont[i]);
        }

        for (int i = 1; i < jLabelTitle.length; i++) {
            ContentPane.add(jLabelTitle[i]);
        }

        for (int i = 1; i < jButtonSetup.length; i++) {
            ContentPane.add(jButtonSetup[i]);
        }

        for (int i = 1; i < jTextFieldSizePanel.length; i++) {
            ContentPane.add(jTextFieldSizePanel[i]);
        }
        ContentPane.add(jTextAreaAdvert);
        ContentPane.add(jLabelAreaAdvert);
        ContentPane.add(jPanelBasic);
    }

    //-----------------------------------------------------------//
    private void initNumeric(String _sPath) {

        for (int i = 0; i < iSizeFontJLabelText.length; i++) {
            iSizeFontJLabelText[i] = 12;
        } // 預設字體大小為12pt

        for (int i = 0; i < iLocationJLabelText.length; i++) {
            for (int j = 0; j < iLocationJLabelText[i].length; j++) {
                if (j == 0) {
                    iLocationJLabelText[i][j] = i;
                }
                iLocationJLabelText[i][j] = 0;
            }
        } // iLocationJLabelText[][] = {{0,0,0},{1,0,0}}…

        for (int i = 0; i < sTypeFontJLabelText.length; i++) {
            sTypeFontJLabelText[i] = sTypeFont[0];
        }

        List<String> list;
        int iFontType = iTypeFont[0];
        String sFontName = null;

        list = arrayProcess.ReadFile(_sPath);
        String[] arrStr = arrayProcess.ListToArray(list);
        // System.out.println("list.size" + list.size());

        for (int i = 1; i < arrStr.length; i++) { // 第一行是註解列，所以不印…
            String[] tempStr; // 利用tab來分欄位…
            tempStr = arrStr[i].split("\t");
            // ⓪文字　①X坐標　②Y坐標　③字體大小　④字體型式　⑤字體名稱

            iLocationJLabelText[i][1] = Integer.parseInt(tempStr[1]); // ①X坐標
            iLocationJLabelText[i][2] = Integer.parseInt(tempStr[2]); // ②Y坐標
            iSizeFontJLabelText[i] = Integer.parseInt(tempStr[3]); // ③字體大小
            sFontName = tempStr[5]; // ⑤字體名稱

            for (int j = 0; j < iTypeFont.length; j++) {
                if (tempStr[4].equals(sTypeFont[j])) {
                    iFontType = iTypeFont[j];
                }
            } // ④字體型式

            //System.out.println(iLocationJLabelText[i][1] + " " + iLocationJLabelText[i][2] + " " + iSizeFontJLabelText[i]);
            jTextField[i].setText(tempStr[0]); // 初始化文字輸入框的值…

            jLabelText[i].setFont(new Font(sFontName, iFontType, iSizeFontJLabelText[i])); // 初始化Label上的文字
            jLabelText[i].setText(tempStr[0]);
            iSizeLabelText[2] = iSizeFontJLabelText[i] + iGapFont; // Label大小比字體大小大一點點…
            jLabelText[i].setBounds(iLocationJLabelText[i][1] + iLocationJPanel[1], iLocationJLabelText[i][2] + iLocationJPanel[2], iSizeLabelText[1], iSizeLabelText[2]);

            // 初始化下拉選單（③字體大小）…
            for (int j = 0; j < sSizeFont.length; j++) {
                if (tempStr[3].equals(sSizeFont[j])) {
                    jComboBoxFontSize[i].setSelectedIndex(j);
                }
            }

            // 初始化下拉選單（④字體型式）…
            for (int j = 0; j < sTypeFont.length; j++) {
                if (tempStr[4].equals(sTypeFont[j])) {
                    jComboBoxFontType[i].setSelectedIndex(j);
                }
            }

            // 初始化下拉選單（⑤字體名稱）…
            for (int j = 0; j < sNameFont.length; j++) {
                if (tempStr[5].equals(sNameFont[j])) {
                    jComboBoxFont[i].setSelectedIndex(j);
                }
            }
        }
        index = 1;
    }

    //-----------------------------------------------------------//
    public List<String> SetupTicketBaseINI() {

        String tempStr;
        List<String> list = new ArrayList<>();
        list.add("文字\tX坐標\tY坐標\t字體大小\t字體樣式\t字體名稱");
        // ⓪文字　①X坐標　②Y坐標　③字體大小　④字體型式　⑤字體名稱

        for (int i = 1; i < iLocationJLabelText.length; i++) {

            tempStr = jLabelText[i].getText() + "\t"; // 輸入的文字：第1列…

            for (int j = 1; j < iLocationJLabelText[i].length; j++) {
                tempStr += iLocationJLabelText[i][j] + "\t";
                System.out.println("tempStr = " + tempStr);
            } // (x, y)坐標：第2丶3列…

            tempStr += iSizeFontJLabelText[i] + "\t"
                    + sTypeFontJLabelText[i] + "\t"
                    + sNameFontJLabelText[i]; // 字體大小、字體樣式：第4、5列…

            list.add(tempStr);
            System.out.println("");
        }
        return list;
    }

    //=======把所得的數據存至src/data/TicketBase.ini，並備份至src/data/_TicketBase.ini=======//
    class jButtonSaveActionListener implements ActionListener {

        String tempStr = null;

        @Override
        public void actionPerformed(ActionEvent e) {
            List<String> list, _list;
            list = SetupTicketBaseINI();

            if (!jButtonSaveKeyed) {
                arrayProcess.WriteFile(list, sPathPrinterDoc);
                jButtonSaveKeyed = true;
            } else {
                _list = arrayProcess.ReadFile(sPathPrinterDoc);  // 備份上一次的資料…
                arrayProcess.WriteFile(_list, _sPathPrinterDoc);
                arrayProcess.WriteFile(list, sPathPrinterDoc);
            }

        }
    }

    //=======還原原本的數據=======//
    class jButtonResetActionListener implements ActionListener {

        String tempStr = null;

        @Override
        public void actionPerformed(ActionEvent e) {
            if (jButtonSaveKeyed) {
                initNumeric(_sPathPrinterDoc);

            } else {
                initNumeric(sPathPrinterDoc);
            }
        }
    }

    //=======設定JPaenl的大小=======//
    class jButtonSetJPanelSizeActionListener implements ActionListener {

        int[] _iSizeJPanel = {0, iSizeJPanel[1], iSizeJPanel[2]};

        @Override
        public void actionPerformed(ActionEvent e) {

            if (!jTextFieldSizePanel[1].getText().isEmpty()) {
                _iSizeJPanel[1] = Integer.parseInt(jTextFieldSizePanel[1].getText());
            } // 防止沒有輸入任何字…

            if (!jTextFieldSizePanel[2].getText().isEmpty()) {
                _iSizeJPanel[2] = Integer.parseInt(jTextFieldSizePanel[1].getText());
            } // 防止沒有輸入任何字…

            jPanelBasic.setSize(_iSizeJPanel[1], _iSizeJPanel[2]);
            //System.out.println(_iSizeJPanel[1] + " " + _iSizeJPanel[2]);
        }
    }

    //=======取得文字大小後設定印出，Label的寬度隨字型大小改變=======//
    class jComboBoxFontSizeActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            JComboBox temp = (JComboBox) e.getSource();
            int indexFont = temp.getSelectedIndex();
            index = frameProcess.JObjectWhichOne(e.getSource(), (Object[]) jComboBoxFontSize); // 看按到哪一個ComboBox

            int iFontType = 0;

            for (int j = 0; j < iTypeFont.length; j++) {
                if (sTypeFontJLabelText[index].equals(sTypeFont[j])) {
                    iFontType = iTypeFont[j];
                }
            } // ④字體型式

            iSizeFontJLabelText[index] = Integer.parseInt(sSizeFont[indexFont]); // 取得字體大小，然後設定，印出來…
            jLabelText[index].setFont(new Font(sNameFontJLabelText[index], iFontType, iSizeFontJLabelText[index]));
            jLabelText[index].setText(jTextField[index].getText());
            // System.out.println("iSizeFontJLabelText[" + index + "] " + iSizeFontJLabelText[index]);

            iSizeLabelText[2] = iSizeFontJLabelText[index] + iGapFont; // Label大小比字體大小大一點點…
            jLabelText[index].setSize(iSizeLabelText[1], iSizeLabelText[2]); // Label的寬度隨字型大小改變…
        }
    }

    //=======取得文字樣式後設定印出=======//
    class jComboBoxFontTypeActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            JComboBox temp = (JComboBox) e.getSource();
            int indexFont = temp.getSelectedIndex();

            index = frameProcess.JObjectWhichOne(e.getSource(), (Object[]) jComboBoxFontType); // 看按到哪一個ComboBox
            sTypeFontJLabelText[index] = sTypeFont[indexFont];

            jLabelText[index].setFont(new Font(sNameFontJLabelText[index], iTypeFont[indexFont], iSizeFontJLabelText[index]));// 取得文字樣式設定印出…
            jLabelText[index].setText(jTextField[index].getText());
        }
    }

    //=======取得字型後設定印出=======//
    class jComboBoxFontActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            JComboBox temp = (JComboBox) e.getSource();
            int indexFont = temp.getSelectedIndex();

            index = frameProcess.JObjectWhichOne(e.getSource(), (Object[]) jComboBoxFont); // 看按到哪一個ComboBox
            sNameFontJLabelText[index] = sNameFont[indexFont];

            int iFontType = 0;

            for (int j = 0; j < iTypeFont.length; j++) {
                if (sTypeFontJLabelText[index].equals(sTypeFont[j])) {
                    iFontType = iTypeFont[j];
                }
            } // ④字體型式

            jLabelText[index].setFont(new Font(sNameFont[indexFont], iFontType, iSizeFontJLabelText[index]));// 取得文字樣式設定印出…
            jLabelText[index].setText(jTextField[index].getText());
        }
    }

    //=======輸入文字時，同步變更Label上的字=======//
    class jTextFieldDocumentListener implements DocumentListener {

        String _sText;

        @Override
        public void insertUpdate(DocumentEvent e) {
            _sText = jLabelText[index].getText();
            jLabelText[index].setText(jTextField[index].getText());

            System.out.println(_sText);
        }

        @Override
        public void removeUpdate(DocumentEvent e) {
            jLabelText[index].setText(jTextField[index].getText());
        }

        @Override
        public void changedUpdate(DocumentEvent e) {
            jLabelText[index].setText(jTextField[index].getText());
        }
    }

    //=======找出空白跟斷行=======//
    class jTextFieldKeyListener implements KeyListener {

        String _sText, _sTextOK;

        @Override
        public void keyTyped(KeyEvent e) {

            for (int i = 0; i < _sText.length(); i++) {

                switch (_sText.charAt(i)) {
                    case KeyEvent.VK_SPACE:
                        _sTextOK += "&nbsp;";
                        System.out.println(_sTextOK);

                        break;
                    case 'a':
                        _sTextOK += "<BR/>";
                        System.out.println(_sTextOK);

                        break;
                    default:
                        _sTextOK += _sText.charAt(i);
                }
            }

            jLabelText[index].setText("<HTML><BR>" + _sText + "</BR>" + _sTextOK + "</HTML>");

        }

        @Override
        public void keyPressed(KeyEvent e) {
        }

        @Override
        public void keyReleased(KeyEvent e) {
        }

    }

    //=======輸入文字時，同步變更Label上的字=======//
    class jTextAreaAdvertDocumentListener implements DocumentListener {

        @Override
        public void insertUpdate(DocumentEvent e) {
            jLabelAreaAdvert.setText(jTextAreaAdvert.getText());
        }

        @Override
        public void removeUpdate(DocumentEvent e) {
            jLabelAreaAdvert.setText(jTextAreaAdvert.getText());
        }

        @Override
        public void changedUpdate(DocumentEvent e) {
            jLabelAreaAdvert.setText(jTextAreaAdvert.getText());
        }
    }

    //=======插入文字時，同步檢查上面的字是否為0~9=======//
    class jTextFieldSizePanelKeyListener implements KeyListener {

        @Override
        public void keyTyped(KeyEvent e) {
            int _iKeyChar = e.getKeyChar();
            if (_iKeyChar >= KeyEvent.VK_0 && _iKeyChar <= KeyEvent.VK_9) {

            } else {
                e.consume(); //關掉輸入，過濾到非0~9的字元 
            }
        }

        @Override
        public void keyPressed(KeyEvent e) {
        }

        @Override
        public void keyReleased(KeyEvent e) {
        }
    }

    //=======滑鼠按下時，看點到哪一個文字輸入框=======//
    class jTextFieldMouseListener implements MouseListener {

        @Override
        public void mouseClicked(MouseEvent e) {
            index = frameProcess.JObjectWhichOne(e.getSource(), (Object[]) jTextField);
            System.out.println("mousePressed = " + index);
        }

        @Override
        public void mousePressed(MouseEvent e) {

        }

        @Override
        public void mouseReleased(MouseEvent e) {

        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        @Override
        public void mouseExited(MouseEvent e) {
        }

    }

    //=======滑鼠拖曳時，取得該Label的位置=======//
    class jLabelTextMouseMotionAdapter extends MouseMotionAdapter {

        //int _index = 0;
        @Override
        public void mouseDragged(MouseEvent e) {
            JLabel temp = (JLabel) e.getSource();

            index = frameProcess.JObjectWhichOne(e.getSource(), (Object[]) jLabelText); // 看拖到哪一個JLabel

            int x = jLabelText[index].getX() + e.getX() - x0;
            int y = jLabelText[index].getY() + e.getY() - y0;

            jLabelText[index].setLocation(x, y); // 算出移動的位置，將JLabel移動至此…

            iLocationJLabelText[index][1] = x - iLocationJPanel[1]; // 以JPanel的位置為原點(0，0)…
            iLocationJLabelText[index][2] = y - iLocationJPanel[2];

            System.out.println("X=" + x + " ,Y" + y);
        }
    }

    //=======滑鼠拖曳時，取得該Label的位置=======//
    class jLabelAreaAdvertMouseMotionAdapter extends MouseMotionAdapter {

        @Override
        public void mouseDragged(MouseEvent e) {
            JLabel temp = (JLabel) e.getSource();

            index = frameProcess.JObjectWhichOne(e.getSource(), jLabelAreaAdvert); // 看拖到哪一個JLabel

            int x = jLabelAreaAdvert.getX() + e.getX() - x0;
            int y = jLabelAreaAdvert.getY() + e.getY() - y0;

            jLabelAreaAdvert.setLocation(x, y); // 算出移動的位置，將JLabel移動至此…

//            iLocationJLabelText[index][1] = x - iLocationJPanel[1]; // 以JPanel的位置為原點(0，0)…
//            iLocationJLabelText[index][2] = y - iLocationJPanel[2];
            System.out.println("X=" + x + " ,Y" + y);
        }
    }

    //=======取得點擊該物件時的位置(x0, y0)=======//
    class jLabelTextMouseAdapter extends MouseAdapter {

        @Override
        public void mousePressed(MouseEvent e) {
            x0 = e.getX();
            y0 = e.getY();

            System.out.println("x0=" + x0 + " , y0=" + y0);
        }
    }
}
