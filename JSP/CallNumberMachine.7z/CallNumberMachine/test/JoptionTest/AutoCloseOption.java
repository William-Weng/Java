package JoptionTest;

import java.awt.Font;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JDialog;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.WindowConstants;

public class AutoCloseOption {

    public void AutoCloseAction(final int second) {
        final JLabel label = new JLabel("", SwingConstants.CENTER);
        int timerDelay = 1000; // 就是一秒鐘…

        Timer t = new Timer(timerDelay, new ActionListener() {
            int timeLeft = second;

            @Override
            public void actionPerformed(ActionEvent e) {
                if (timeLeft > 0) {
                    label.setFont(new Font("", Font.BOLD, 20));
                    label.setText(timeLeft + "");

                    timeLeft--;
                } else {
                    ((Timer) e.getSource()).stop();
                    Window win = SwingUtilities.getWindowAncestor(label);
                    win.dispose();
                }
            }
        });
        t.setInitialDelay(0);
        t.start();

        //URL imagePath = AutoCloseOptionDemo.class.getClassLoader().getResource("JoptionTest/image/Printer.png");
        String imagePath = "src/image/Printer.png"; // 對應jar檔的位置…
        //URL imagePath = AutoCloseOptionDemo.class.getResource("image/Printer.png"); // 對應classes檔的位置…

        ImageIcon aceOfDiamonds = new ImageIcon(imagePath);
        ImageIcon img = new ImageIcon(imagePath);
        label.setIcon(img);
        JOptionPane jOptionPane = new JOptionPane(label, JOptionPane.PLAIN_MESSAGE, JOptionPane.DEFAULT_OPTION);
        JDialog dialog = jOptionPane.createDialog(null, ".....列印中，請稍候.....");
        dialog.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        dialog.setVisible(true);
    }
}
