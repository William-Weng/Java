package com.lyx;

public class Main {

    public static void main(String[] args) {
        ArrayProcess arrayProcess = new ArrayProcess();

        arrayProcess.WriteFile("D:\\CSV\\Java20140728.txt");
        arrayProcess.WriteFile("Java20140728.txt");

//        arrayProcess.ReadFile("D:\\Java20140728.txt");
//        arrayProcess.ReadFile("data\\Java20140728.txt");
    }
}
