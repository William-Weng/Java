package com.lyx;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.URL;

public class UserDirDemo {

    public void loadCongfig(String fileName) {
        String line;
        try {
            BufferedReader reader = new BufferedReader(new FileReader(fileName));
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
            reader.close();
        } catch (Exception ex) {
            System.out.println("读取ini文件错误");
        }
    }

    public static void main(String[] args) {
        //  lyx.ini 这个文件和 调用类放在在同一包下  
        String mydir = "lyx.ini";
        URL url = UserDirDemo.class.getResource(mydir);
        UserDirDemo ud = new UserDirDemo();
        ud.loadCongfig(new File(url.getFile()).getAbsolutePath());
    }

}
