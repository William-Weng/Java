/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WavPlayer;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Yu-Pin
 */
public class MyClass {

    private final String wavFile[] = {
        "D:\\wav\\0.wav",
        "D:\\wav\\1.wav",
        "D:\\wav\\2.wav",
        "D:\\wav\\3.wav",
        "D:\\wav\\4.wav",
        "D:\\wav\\5.wav",
        "D:\\wav\\6.wav",
        "D:\\wav\\7.wav",
        "D:\\wav\\8.wav",
        "D:\\wav\\9.wav",
        "D:\\wav\\來賓.wav",
        "D:\\wav\\請.wav",
        "D:\\wav\\櫃台.wav"
    };

    public List<String> intToChar() {
        String str1 = "0005";
        List<String> list = new ArrayList();
        char[] arrayChar = str1.toCharArray();
        int index = 0;

        list.add(wavFile[10]);

        for (char charStr : arrayChar) {
            list.add(wavFile[Integer.parseInt(String.valueOf(charStr))]);
            System.out.println(charStr);
        }

        list.add(wavFile[11]);
        list.add(wavFile[12]);

        System.out.println(list);

        return list;
    }

    public static void main(String[] args) {
    }
}
