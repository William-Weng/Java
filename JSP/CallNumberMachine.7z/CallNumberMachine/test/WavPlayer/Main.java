package WavPlayer;

public class Main {

    public static void main(String[] args) {
        PlaySound playSound = new PlaySound();
        playSound.playWav(6666, 9);
    }
}
