// ======文數字處理====== //
package WavPlayer;

import java.util.ArrayList;
import java.util.List;

public class WordProcess {

    private final String wavFile[] = {
        "src/wav/0.wav",
        "src/wav/1.wav",
        "src/wav/2.wav",
        "src/wav/3.wav",
        "src/wav/4.wav",
        "src/wav/5.wav",
        "src/wav/6.wav",
        "src/wav/7.wav",
        "src/wav/8.wav",
        "src/wav/9.wav",
        "src/wav/來賓.wav",
        "src/wav/請.wav",
        "src/wav/櫃台.wav"
    };

    //-------------------------將10轉成0010------------------------//
    public String IntToString(int number) {
        String str = "";

        if (number / 10000 == 0) {
            str = "" + number;
        }

        if (number / 1000 == 0) {
            str = "0" + number;
        }

        if (number / 100 == 0) {
            str = "00" + number;
        }

        if (number / 10 == 0) {
            str = "000" + number;
        }

        return str;
    }

    //----------------------將0005轉成0005.wav-----------------------//
    public List<String> IntToWav(int number, int counter) {
        String str1 = this.IntToString(number);
        List<String> list = new ArrayList();
        char[] arrayChar = str1.toCharArray();
        int index = 0;

        list.add(wavFile[10]);

        for (char charStr : arrayChar) {
            list.add(wavFile[Integer.parseInt(String.valueOf(charStr))]); // 1→1.wav
            System.out.println(charStr);
        }

        list.add(wavFile[11]);
        list.add(wavFile[counter]);
        list.add(wavFile[12]);

        System.out.println(list);

        return list;
    }

}
