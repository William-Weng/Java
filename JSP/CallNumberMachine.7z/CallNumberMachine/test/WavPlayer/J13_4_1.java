package WavPlayer;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.applet.Applet;
import java.applet.AudioClip;
import java.net.MalformedURLException;
import java.util.logging.Level;
import java.util.logging.Logger;

class SoundFrame extends JFrame implements ActionListener {

    boolean flag = false;
    JButton btnPlay, btnLoop, btnStop;
    File file = new File("D:\\Wav\\1.wav");
    // 利用Applet的newAudioClip方法取得AudioClip物件
    AudioClip sound = Applet.newAudioClip(file.toURL());
    String soundFile[] = {
        "D:\\0~9\\0.wav",
        "D:\\0~9\\1.wav",
        "D:\\0~9\\2.wav",
        "D:\\0~9\\3.wav",
        "D:\\0~9\\4.wav",
        "D:\\0~9\\5.wav",
        "D:\\0~9\\6.wav",
        "D:\\0~9\\7.wav",
        "D:\\0~9\\8.wav",
        "D:\\0~9\\9.wav",};

    SoundFrame() throws Exception {
        btnPlay = new JButton("播放");
        btnPlay.addActionListener(this);
        add(btnPlay);
        btnLoop = new JButton("循環播放");
        btnLoop.addActionListener(this);
        add(btnLoop);
        btnStop = new JButton("停止");
        btnStop.addActionListener(this);
        btnStop.setEnabled(false);
        add(btnStop);

        setTitle("用new AudioClip()播放音樂");
        setLayout(new FlowLayout());
        setBounds(100, 100, 300, 100);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnPlay) {
            
            for (String soundFile1 : soundFile) {
                file = new File(soundFile1);
                sound.play();                    // 一次播放一遍
                try {
                    sound = Applet.newAudioClip(file.toURL());
                } catch (MalformedURLException ex) {
                    Logger.getLogger(SoundFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            
            
            btnPlay.setEnabled(false);
            btnStop.setEnabled(true);
        }
        if (e.getSource() == btnLoop) {
            sound.loop();                   // 循環播放
            btnLoop.setEnabled(false);
            btnPlay.setEnabled(false);
            btnStop.setEnabled(true);
        }
        if (e.getSource() == btnStop) {
            sound.stop();                   // 停止播放
            btnLoop.setEnabled(true);
            btnPlay.setEnabled(true);
            btnStop.setEnabled(false);
        }
    }
}

public class J13_4_1 {

    public static void main(String[] args) throws Exception {
    }
}
