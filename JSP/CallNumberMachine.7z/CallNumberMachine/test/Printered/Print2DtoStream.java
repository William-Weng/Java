package Printered;

import java.io.*;
import java.awt.*;
import java.awt.print.*;
import javax.print.*;
import javax.print.attribute.*;

/*
 * Use the Java(TM) Print Service API to locate a service which can export
 * 2D graphics to a stream as Postscript. This may be spooled to a
 * Postscript printer, or used in a postscript viewer.
 */
public class Print2DtoStream implements Printable {

    public Print2DtoStream() {

        /* Use the pre-defined flavor for a Printable from an InputStream */
        DocFlavor flavor = DocFlavor.SERVICE_FORMATTED.PRINTABLE;

        /* Specify the type of the output stream */
        String psMimeType = DocFlavor.BYTE_ARRAY.POSTSCRIPT.getMimeType();

        /* Locate factory which can export a GIF image stream as Postscript */
        StreamPrintServiceFactory[] factories
                = StreamPrintServiceFactory.lookupStreamPrintServiceFactories(
                        flavor, psMimeType);
        if (factories.length == 0) {
            System.err.println("No suitable factories");
            System.exit(0);
        }

        try {
            /* Create a file for the exported postscript */
            FileOutputStream fos = new FileOutputStream("out.ps");

            /* Create a Stream printer for Postscript */
            StreamPrintService sps = factories[0].getPrintService(fos);

            /* Create and call a Print Job */
            DocPrintJob pj = sps.createPrintJob();
            PrintRequestAttributeSet aset = new HashPrintRequestAttributeSet();

            Doc doc = new SimpleDoc(this, flavor, null);

            pj.print(doc, aset);
            fos.close();

        } catch (PrintException pe) {
            System.err.println(pe);
        } catch (IOException ie) {
            System.err.println(ie);
        }
    }

    public int print(Graphics g, PageFormat pf, int pageIndex) {

        if (pageIndex == 0) {
            Graphics2D g2d = (Graphics2D) g;
            g2d.translate(pf.getImageableX(), pf.getImageableY());
            g2d.setColor(Color.black);
            g2d.drawString("example string", 250, 250);
            g2d.fillRect(0, 0, 200, 200);
            return Printable.PAGE_EXISTS;
        } else {
            return Printable.NO_SUCH_PAGE;
        }
    }

    public static void main(String args[]) {
        Print2DtoStream sp = new Print2DtoStream();
    }
}
