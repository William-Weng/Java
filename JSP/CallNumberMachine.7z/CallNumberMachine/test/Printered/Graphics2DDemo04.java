package Printered;

import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Graphics2DDemo04 extends Canvas {

    Image image;

    public static void main(String[] args) {
        Frame frame = new Frame("AWTDemo");
        frame.setSize(510, 410);

        Graphics2DDemo04 canvas = new Graphics2DDemo04();
        frame.add(canvas, BorderLayout.CENTER);

        frame.setVisible(true);
    }

    @Override
    public void paint(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;

        try {
            image = ImageIO.read(new File("D:\\Image\\Logo.gif"));
        } catch (IOException ex) {
            System.out.println("No example.jpg!!");
        }

        g2.drawImage(image, 10, 10, null);
    }
}
