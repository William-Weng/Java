package Printered;

public class Main {

    public static void main(String[] args) {
//        try {
//            String path = null;
//            path = Main.class.getResource(path).getPath();
//            String pathNew = new String(path.getBytes("ISO-8859-1"), "UTF-8");
//            System.out.println(pathNew);
//        } catch (UnsupportedEncodingException ex) {
//            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
//        }
    }
}
