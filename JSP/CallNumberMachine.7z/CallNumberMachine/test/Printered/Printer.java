package Printered;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.print.PageFormat;
import java.awt.print.Paper;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.util.List;
import javax.print.PrintService;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import static java.awt.print.Printable.NO_SUCH_PAGE;
import static java.awt.print.Printable.PAGE_EXISTS;
import static java.awt.print.PrinterJob.lookupPrintServices;

public class Printer {

    final static double PaperSize[] = {0, 1000, 1000}; // 紙張大小…
    final static String PRINTERNAME = "PDF24 PDF"; // 印表機名稱…
    static String[] sTicketData = {"0000", "1911-01-01"};
    private int PrinterIndex;
    private final PrintService[] printService = lookupPrintServices();
    private final int[] iPicLocation = {0, 50, 50};

    public void print() { // 找尋印表機的位置…
        for (int i = 0; i < printService.length; i++) {
            if (printService[i].getName().equals(PRINTERNAME)) {
                PrinterIndex = i;
            }
        }

        PrinterJob printerJob = PrinterJob.getPrinterJob();

        PageFormat pageFormat = new PageFormat();
        Paper myPaper = new Paper();

        myPaper.setSize(PaperSize[1], PaperSize[2]);
        myPaper.setImageableArea(0, 0, PaperSize[2], PaperSize[2]);

        pageFormat.setPaper(myPaper);
        pageFormat.setOrientation(PageFormat.PORTRAIT); // 設定列印位置的方式…

        PrintPage printPage = new PrintPage();
        try {
            printerJob.setPrintService(printService[PrinterIndex]);
        } catch (PrinterException ex) {
            System.out.println(ex.getMessage());
        }

        printerJob.setPrintable(printPage, pageFormat);
        printerJob.setCopies(1); // 只印一張…

        try {
            printerJob.print();
        } catch (PrinterException ex) {
            System.out.println(ex.getMessage());
        }
    }

    class PrintPage implements Printable {

        @Override
        public int print(Graphics g, PageFormat pf, int pageIndex) {
            if (pageIndex > 0) {
                return NO_SUCH_PAGE;
            }

            List<String> list;
            ArrayProcess arrayProcess = new ArrayProcess();
            String path = "src/data/TicketBase.ini"; // 對應jar檔的位置…
            list = arrayProcess.ReadFile(path);
            System.out.println(path);
            String[] arrStr;
            arrStr = arrayProcess.ListToArray(list);
            int fontSize = 12;
            Image image = null;

            Graphics2D g2d = (Graphics2D) g;
            g2d.translate(pf.getImageableX(), pf.getImageableY());

            g.setFont(new Font("", Font.PLAIN, fontSize));
            int iMargins = 0;

            for (int i = 1; i < arrStr.length; i++) { // 第一行是註解列不印…

                String[] sTicketBaseTXT = arrStr[i].split("\t"); // 利用tab來分欄位… 文字_文字大小_左邊邊距

                switch (sTicketBaseTXT[0]) {
                    case "<號碼放這裡>":
                        sTicketBaseTXT[0] = sTicketData[0] + "號";
                        break;
                    case "<日期放這裡>":
                        sTicketBaseTXT[0] = sTicketData[1];
                        break;
                    case "<商標放這裡>":
                        sTicketBaseTXT[0] = " ";
                        iPicLocation[1] = Integer.parseInt(sTicketBaseTXT[1]);
                        iPicLocation[2] = Integer.parseInt(sTicketBaseTXT[2]);
                        System.out.println("<商標放這裡>" + sTicketBaseTXT[1]);
                        break;
                    default:
                        System.out.println("發生意外…");
                        break;
                }

                fontSize = Integer.parseInt(sTicketBaseTXT[1]);

                g.setFont(new Font("", Font.PLAIN, fontSize));
                System.out.println("iMargins=" + iMargins);
                g2d.drawString(sTicketBaseTXT[0], Integer.parseInt(sTicketBaseTXT[2]), Integer.parseInt(sTicketBaseTXT[3]));

                try {
                    image = ImageIO.read(new File("src/image/Logo.png"));
                } catch (IOException ex) {
                    System.out.println("No example.jpg!!");
                }

                g2d.drawImage(image, iPicLocation[1], iPicLocation[2], null);
            }
            return PAGE_EXISTS;
        }
    }

    public void PrintNumber(String strTemp, String strData) {
        sTicketData[0] = strTemp;
        sTicketData[1] = strData;
        this.print();
    }

    public static void main(String[] args) {
        Printer tp = new Printer();
        tp.PrintNumber("1234", "2014-07-07");
    }
}
