package test.printer;

import Tools.Utility.Printer;
import java.awt.print.*;
import java.awt.*;

public class PrintTest implements Printable {

    int curX = 0, curY = 0;

    public PrintTest() {

    }

    public static void main(String[] args) {

        PrinterJob pntJob = PrinterJob.getPrinterJob(); // new PrinterJob();
        Book book = new Book();
        book.append(new PrintTest(), new PageFormat());
        //  book.append(new AnotherPrintableObject, new PageFormat); //可以增加其他要印的頁次

        pntJob.setPageable(book);
        boolean doPrint;
        // doPrint = pntJob.printDialog(); // 開啟列印對話框
        doPrint = true;
        if (doPrint) {
            try {
                pntJob.print();
            } catch (PrinterException e) {
                System.out.println(e.getMessage());
            }
        }
        System.exit(0);
    }

    @Override
    public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) {

        Graphics2D g2d = (Graphics2D) graphics;
        g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());
        g2d.setPaint(Color.black);

        Font myFont = new Font("標楷體", Font.PLAIN, 12);

        g2d.setFont(myFont); //設定列印的字型
        curY = 20;
        curX = 0;
        nextLine("這是Testing第一行", g2d);

        myFont = new Font("細明體", Font.PLAIN, 16);

        g2d.setFont(myFont); //設定列印的字型
        curX = 50;
        nextLine("這是Testing第二行", g2d);
        sameLine(" 在同一行", g2d);

        return Printable.PAGE_EXISTS;
    }

    private void nextLine(String s, Graphics2D g2d) {
        FontMetrics fm = g2d.getFontMetrics();
        curY += fm.getHeight(); //取得字體高度(單位:Point)
        System.out.println("fm.getHeight()=" + fm.getHeight());
        g2d.drawString(s, curX, curY);
        curX += fm.stringWidth(s); //取得字串長度(單位:Point)
        System.out.println("fm.stringWidth(s)=" + fm.stringWidth(s));
    }

    private void sameLine(String s, Graphics2D g2d) {
        FontMetrics fm = g2d.getFontMetrics();
        g2d.drawString(s, curX, curY);
        curX += fm.stringWidth(s);
    }
}
