DROP TABLE IF EXISTS GetTicketMachine.StaffInfo; -- 刪除資料表

CREATE TABLE GetTicketMachine.StaffInfo(
    PrimaryKey INTEGER(4) AUTO_INCREMENT PRIMARY KEY NOT NULL, -- 主鍵值
    Sex INTEGER(2) DEFAULT 99, -- 性別
    Levels INTEGER(2) DEFAULT 99, -- 等級
    Status INTEGER(2) DEFAULT 99, -- 狀態
    Country VARCHAR(3) DEFAULT '----', -- 國別／地區代碼
    NameCht VARCHAR(20) DEFAULT '----', -- 中文名字
    NameEng VARCHAR(50) DEFAULT '----', -- 英文名字
    NameOthers VARCHAR(50) DEFAULT '----', -- 其它名字
    ID VARCHAR(4) DEFAULT '----', -- 員工編號
    InsertStaff VARCHAR(4) DEFAULT '----', -- 修改人員
    FirstDay_Date  DATE DEFAULT '1970-01-01', -- 就職日期
    FirstDay_Time TIME DEFAULT '00:00:00' -- 就職時間
    LastDay_Date  DATE DEFAULT '1970-01-01', -- 離職日期
    LastDay_Time TIME DEFAULT '00:00:00' -- 離職時間
    InsertDate DATE DEFAULT '1970-01-01', -- 修改日期
    InsertTime TIME DEFAULT '00:00:00' -- 修改時間
);

INSERT INTO GetTicketMachine.StaffInfo(PrimaryKey, ID, ButtonName, X, Y, Width, Height, FunctionCode) VALUES (1, 0, 'ButtonRun1', 50 ,115, 274, 537, 'A001');
