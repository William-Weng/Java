DROP TABLE IF EXISTS GetTicketMachine.SexInfo; -- 刪除資料表

CREATE TABLE GetTicketMachine.SexInfo(
    PrimaryKey INTEGER(2) AUTO_INCREMENT PRIMARY KEY NOT NULL, -- 主鍵值
    Code INTEGER(2) DEFAULT 99, -- 代碼
    NameEng VARCHAR(30) DEFAULT 99, -- 英文說明
    NameCht VARCHAR(10) DEFAULT 99, -- 中文說明
    InsertStaff VARCHAR(4) DEFAULT '----', -- 修改人員
    InsertDate DATE DEFAULT '1970-01-01', -- 修改日期
    InsertTime TIME DEFAULT '00:00:00' -- 修改時間
);

INSERT INTO GetTicketMachine.SexInfo(PrimaryKey, Code, NameEng, NameCht) VALUES (1, 0, 'Ｗoman', '女性');
INSERT INTO GetTicketMachine.SexInfo(PrimaryKey, Code, NameEng, NameCht) VALUES (2, 1, 'Man', '男性');
INSERT INTO GetTicketMachine.SexInfo(PrimaryKey, Code, NameEng, NameCht) VALUES (3, 2, 'Others', '其它');
