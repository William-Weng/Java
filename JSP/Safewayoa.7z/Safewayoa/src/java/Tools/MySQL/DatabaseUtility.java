// ======資料庫處理====== //
package Tools.MySQL;

import Model.SQLConnentInfo;
import Model.ProductInfo;
import Tools.Utility.TimeNow;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DatabaseUtility implements Serializable {

//----------------------------------------------------變數宣告-----------------------------------------------------//
    private Connection conn = null;
    private Statement stat = null;
    private ResultSet rs = null;
    private PreparedStatement pst = null;

//---------------------------------------------------初始化函數---------------------------------------------------//
    public DatabaseUtility() {

        SQLConnentInfo infoSQL = new SQLConnentInfo();
        String driver = infoSQL.getDriver();
        String url = infoSQL.getUrl();
        String user = infoSQL.getUser();
        String password = infoSQL.getPassword();

        try {

            Class.forName(driver);
            conn = DriverManager.getConnection(url, user, password);

            if (conn != null && !conn.isClosed()) {
                System.out.println("資料庫連線測試成功…");
            }

        } catch (ClassNotFoundException eNotFound) {
            System.out.println("DriverClassNotFound :" + eNotFound.toString());
            System.out.println("資料庫驅動程式出錯…");
        } catch (SQLException eSQL) {
            System.out.println("Exception :" + eSQL.toString());
            System.out.println("資料庫帳號、密碼錯誤…");
        }
    }

    //-------------------------------------------------資料庫連線關閉-----------------------------------------------//
    private void closeSQL() {
        try {

            if (rs != null) {
                rs.close();
                rs = null;
            }
            if (stat != null) {
                stat.close();
                stat = null;
            }
            if (pst != null) {
                pst.close();
                pst = null;
            }

            System.out.println("資料庫連線關閉成功…");

        } catch (SQLException e) {
            System.out.println("Close Exception :" + e.toString());
            System.out.println("資料庫連線關閉失敗…");
        }
    }

    //------------------------------------------------------新增數據----------------------------------------------------//
    public void insert(ProductInfo infoProduct, String tableName) {

        String insertdbSQL = "INSERT INTO " + tableName + " (ProductName, ProductID, ProductBrand, ProductPrice, ProductText, InsertDate, InsertTime) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try {

            pst = conn.prepareStatement(insertdbSQL);
            pst.setString(1, infoProduct.getProductName());
            pst.setString(2, infoProduct.getProductID());
            pst.setString(3, infoProduct.getProductBrand());
            pst.setInt(4, infoProduct.getProductPrice());
            pst.setString(5, infoProduct.getProductText());
            pst.setDate(6, new TimeNow().ToSqlDate());
            pst.setTime(7, new TimeNow().ToSqlTime());

            pst.executeUpdate();

            System.out.println("資料庫連線新增成功…");

        } catch (SQLException e) {
            System.out.println("InsertDB Exception :" + e.toString());
            System.out.println("資料庫尚未建立…");
        } finally {
            closeSQL();
        }
    }
//------------------------------------------------------新增數據----------------------------------------------------//

    public void insertTime() {

        String tableName = "Product.TimeNow";
        String insertdbSQL = "INSERT INTO " + tableName + " (SetupDate, SetupTime) VALUES (?, ?)";

        try {

            pst = conn.prepareStatement(insertdbSQL);
            pst.setDate(1, new TimeNow().ToSqlDate());
            pst.setTime(2, new TimeNow().ToSqlTime());

            pst.executeUpdate();

            System.out.println("資料庫連線新增成功…");

        } catch (SQLException e) {
            System.out.println("InsertDB Exception :" + e.toString());
            System.out.println("資料庫尚未建立…");
        } finally {
            closeSQL();
        }
    }

//----------------------------------------------------查詢資料表--------------------------------------------------//
    public ProductInfo select(int printerKey, String tableName) {

        ProductInfo _infoProduct = new ProductInfo();

        // String tableName = "Product.InfoPrinter";
        String selectSQL = "SELECT * FROM " + tableName + " WHERE ProductKey = ?";

        try {

            pst = conn.prepareStatement(selectSQL);
            pst.setInt(1, printerKey);
            rs = pst.executeQuery();

            System.out.println();

            while (rs.next()) {
                _infoProduct = new ProductInfo(); // 把Class資料清空

                _infoProduct.setProductName(rs.getString("ProductName"));
                _infoProduct.setProductID(rs.getString("ProductID"));
                _infoProduct.setProductBrand(rs.getString("ProductBrand"));
                _infoProduct.setProductPrice(rs.getInt("ProductPrice"));
                _infoProduct.setProductKey(rs.getInt("ProductKey"));
                _infoProduct.setProductText(rs.getString("ProductText"));

                System.out.println("_infoPrinter = " + _infoProduct);
            }

            System.out.println("_infoProduct = " + _infoProduct);

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _infoProduct;
    }

    //----------------------------------------------------查詢資料表--------------------------------------------------//
    public List<ProductInfo> select() {

        String tableName = "Product.InfoPrinter";
        String selectSQL = "SELECT * FROM " + tableName + " ORDER BY ProductKey DESC";

        List<ProductInfo> _list = null;
        ProductInfo _infoProduct = null;

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(selectSQL);
            ResultSetMetaData rm = rs.getMetaData();
            int colNumber = rm.getColumnCount();
            _list = new ArrayList();

            while (rs.next()) {
                _infoProduct = new ProductInfo(); // 把Class資料清空

                _infoProduct.setProductName(rs.getString("ProductName"));
                _infoProduct.setProductID(rs.getString("ProductID"));
                _infoProduct.setProductBrand(rs.getString("ProductBrand"));
                _infoProduct.setProductPrice(rs.getInt("ProductPrice"));
                _infoProduct.setProductKey(rs.getInt("ProductKey"));
                _infoProduct.setProductText(rs.getString("ProductText"));
                _infoProduct.setInsertDate(rs.getDate("InsertDate"));
                _infoProduct.setInsertTime(rs.getTime("InsertTime"));

                System.out.println("_list = " + _list);
                _list.add(_infoProduct);
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    //----------------------------------------------------查詢資料表--------------------------------------------------//
    public List<ProductInfo> select(int start, int pageCount, String tableName) {

        // String tableName = "Product.InfoPrinter";
        String selectSQL = "SELECT * FROM " + tableName + " ORDER BY ProductKey DESC, ProductBrand ASC";

        List<ProductInfo> _list = null;
        ProductInfo _infoProduct = null;

        try {
            _list = new ArrayList();

            stat = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY); // 設定此物件的指標可以前後移動
            rs = stat.executeQuery(selectSQL);
            rs.afterLast(); // 把rs指標移到最後一個，測試有無資料

            rs.absolute(start); // 設定rs開始的位置

            for (int i = 0; i < pageCount; i++) { // 只取該頁看得到的資料，節省時間

                _infoProduct = new ProductInfo(); // 把Class資料清空

                _infoProduct.setProductName(rs.getString("ProductName"));
                _infoProduct.setProductID(rs.getString("ProductID"));
                _infoProduct.setProductBrand(rs.getString("ProductBrand"));
                _infoProduct.setProductPrice(rs.getInt("ProductPrice"));
                _infoProduct.setProductKey(rs.getInt("ProductKey"));
                _infoProduct.setProductText(rs.getString("ProductText"));
                _infoProduct.setInsertDate(rs.getDate("InsertDate"));
                _infoProduct.setInsertTime(rs.getTime("InsertTime"));

                System.out.println("_list = " + _list);
                _list.add(_infoProduct);

                if (!rs.next()) { // 如果沒資料就跳出迴圈
                    break;
                }
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    //----------------------------------------------------查詢總筆數--------------------------------------------------//
    public int selectCounts(String tableName) {

        // tableName = "Product.InfoPrinter";
        String selectSQL = "SELECT COUNT(*) AS rowCount FROM " + tableName;
        int _counts = 0;

        try {
            stat = conn.createStatement();
            rs = stat.executeQuery(selectSQL);
            ResultSetMetaData rm = rs.getMetaData();

            rs.next();
            _counts = rs.getInt("rowCount");

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _counts;
    }

    //---------------------------------------------------刪除單筆資料------------------------------------------------//
    public void delete(int printerKey) {

        String tableName = "Product.InfoPrinter";
        String deletedbSQL = "DELETE FROM " + tableName + " WHERE ProductKey = ?";

        try {

            pst = conn.prepareStatement(deletedbSQL);
            pst.setInt(1, printerKey);
            pst.executeUpdate();
            System.out.println("資料刪除成功…");

        } catch (SQLException e) {
            System.out.println("DeleteDB Exception :" + e.toString());
            System.out.println("資料表沒有可刪除的資料…");
        } finally {
            closeSQL();
        }
    }

//---------------------------------------------------修改資料表---------------------------------------------------//
    public void update(int printerKey, ProductInfo infoPrinter) {

        String tableName = "Product.InfoPrinter";
        String updatedbSQL = "UPDATE " + tableName + " SET ProductName = ?, ProductID = ? ,ProductBrand = ?, ProductPrice = ?, ProductText = ?  WHERE ProductKey =  ?";

        try {

            pst = conn.prepareStatement(updatedbSQL);

            pst.setString(1, infoPrinter.getProductName());
            pst.setString(2, infoPrinter.getProductID());
            pst.setString(3, infoPrinter.getProductBrand());
            pst.setInt(4, infoPrinter.getProductPrice());
            pst.setString(5, infoPrinter.getProductText());
            pst.setInt(6, printerKey);

            pst.executeUpdate();
            System.out.println("資料表更新成功…");

        } catch (SQLException e) {
            System.out.println("UpdateDB Exception :" + e.toString());
            System.out.println("資料表更新失敗…");
        } finally {
            closeSQL();
        }
    }
//-----------------------------------------------------結束----------------------------------------------------------//
}
