package Tools.MySQL;

import Model.ProductInfo;
import Tools.Utility.TimeNow;
import java.util.List;

public class _MySQL_ {

    public static void main(String[] args) {
        DatabaseUtility utilDB = new DatabaseUtility();
        List<ProductInfo> bookList;
//        bookList = utilDB.select(10, 10);
//
//        for (int i = 0; i < bookList.size(); i++) {
//            System.out.println(bookList.get(i).getPrinterKey());
//        }

        ProductInfo _infoProduct = new ProductInfo();
        _infoProduct.setInsertDate(new TimeNow().ToSqlDate());
        _infoProduct.setInsertTime(new TimeNow().ToSqlTime());
        _infoProduct.setProductBrand("OSRAM");
        _infoProduct.setProductName("OSRAM-AM1400");
        _infoProduct.setProductPrice(10999);
        _infoProduct.setProductText("很貴…<br/>真的<br/>好貴");

        for (int i = 1; i <= 20; i++) {
            _infoProduct.setProductID("OSRAM-" + i);
            utilDB.insert(_infoProduct, "Product.InfoPrinter");
        }
//        System.out.println(utilDB.selectCounts("Product.InfoPrinter"));
    }

}
