// ======文數字處理====== //
package Tools.Utility;

import java.util.List;

public class ArrayProcess {

//--------------------將ArrayList轉成Array----------------------//
    public String[] ListToArray(List<String> list) {
        String[] arrayStr = null;

        if (!list.isEmpty()) { // ArrayList 轉 Array
            arrayStr = new String[list.size()];
            arrayStr = list.toArray(arrayStr);
        } else {
            arrayStr = new String[]{"0", "0000"};
        }
        return arrayStr;
    }
}
