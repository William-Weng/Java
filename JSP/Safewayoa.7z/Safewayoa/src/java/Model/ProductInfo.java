package Model;

import java.sql.Date;
import java.sql.Time;

public class ProductInfo {

    private int ProductKey; // 流水號：5
    private int ProductPrice; // 商品價格：NT.9999
    private String ProductName; // 商品名稱：EPSON AL-M1400
    private String ProductID; // 商品編號：AL-M1400
    private String ProductBrand; // 商品品牌：HP
    private String ProductText; // 商品說明：LED雷射印表機
    private String PrinterItem; // 商品分類：印表機 > 雷射印表機 > 彩色印表機
    private String PrinterAbility; // 商品特性：LED_黑白_A4_1200*1200dpi
    private String Manufacturers; // 進貨廠商：大鑫資訊
    private Date InsertDate; // 變動日期：2014-07-07
    private Time InsertTime; // 變動時間：14:05:51

    public int getProductKey() {
        return ProductKey;
    }

    public int getProductPrice() {
        return ProductPrice;
    }

    public String getProductName() {
        return ProductName;
    }

    public String getProductID() {
        return ProductID;
    }

    public String getProductBrand() {
        return ProductBrand;
    }

    public String getProductText() {
        return ProductText;
    }

    public String getPrinterItem() {
        return PrinterItem;
    }

    public String getPrinterAbility() {
        return PrinterAbility;
    }

    public String getManufacturers() {
        return Manufacturers;
    }

    public Date getInsertDate() {
        return InsertDate;
    }

    public Time getInsertTime() {
        return InsertTime;
    }

    public void setProductKey(int ProductKey) {
        this.ProductKey = ProductKey;
    }

    public void setProductPrice(int ProductPrice) {
        this.ProductPrice = ProductPrice;
    }

    public void setProductName(String ProductName) {
        this.ProductName = ProductName;
    }

    public void setProductID(String ProductID) {
        this.ProductID = ProductID;
    }

    public void setProductBrand(String ProductBrand) {
        this.ProductBrand = ProductBrand;
    }

    public void setProductText(String ProductText) {
        this.ProductText = ProductText;
    }

    public void setPrinterItem(String PrinterItem) {
        this.PrinterItem = PrinterItem;
    }

    public void setPrinterAbility(String PrinterAbility) {
        this.PrinterAbility = PrinterAbility;
    }

    public void setManufacturers(String Manufacturers) {
        this.Manufacturers = Manufacturers;
    }

    public void setInsertDate(Date InsertDate) {
        this.InsertDate = InsertDate;
    }

    public void setInsertTime(Time InsertTime) {
        this.InsertTime = InsertTime;
    }
}
