package Model;

public class PageInfo {

    private int pageTotal; // 總頁數
    private int pageStart; // 開始頁
    private int pageEnd; // 結束頁
    private int pageRun; // 所在頁
    private int pagingCounts; // 分頁數量：10頁
    private int productNumber; // 9個產品/頁
    private String pageDB; // 所在資料庫
    private String pageTable; // 所在資料表

    public int getPageTotal() {
        return pageTotal;
    }

    public int getPagingCounts() {
        return pagingCounts;
    }

    public int getPageStart() {
        return pageStart;
    }

    public int getPageEnd() {
        return pageEnd;
    }

    public int getPageRun() {
        return pageRun;
    }

    public int getProductNumber() {
        return productNumber;
    }

    public String getPageDB() {
        return pageDB;
    }

    public String getPageTable() {
        return pageTable;
    }

    public void setPageTotal(int pageTotal) {
        this.pageTotal = pageTotal;
    }

    public void setPagingCounts(int pagingCounts) {
        this.pagingCounts = pagingCounts;
    }

    public void setPageStart(int pageStart) {
        this.pageStart = pageStart;
    }

    public void setPageEnd(int pageEnd) {
        this.pageEnd = pageEnd;
    }

    public void setPageRun(int pageRun) {
        this.pageRun = pageRun;
    }

    public void setProductNumber(int productNumber) {
        this.productNumber = productNumber;
    }

    public void setPageDB(String pageDB) {
        this.pageDB = pageDB;
    }

    public void setPageTable(String pageTable) {
        this.pageTable = pageTable;
    }
}
