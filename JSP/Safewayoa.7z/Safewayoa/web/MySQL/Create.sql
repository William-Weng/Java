drop table Product.InfoPrinter;
drop table Product.InfoBulb;

CREATE TABLE Product.InfoPrinter(
    ProductKey INTEGER(3) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值(流水號)
    ProductName VARCHAR(255) NOT NULL, -- 商品名稱
    ProductID VARCHAR(25) NOT NULL UNIQUE, -- 商品代號
    ProductBrand VARCHAR(50) DEFAULT '----', -- 商品廠牌
    ProductPrice INTEGER(7) DEFAULT 9999999, -- 商品價格
    ProductText VARCHAR(1000) DEFAULT '----', -- 商品說明
    ProductItem VARCHAR(100) DEFAULT '----', -- 商品分類
    ProductAbility VARCHAR(100) DEFAULT '----', -- 商品特性
    Manufacturers VARCHAR(100) DEFAULT '----', -- 進貨廠商
    InsertDate date, -- 修改日期
    InsertTime time -- 修改時間
);

CREATE TABLE Product.InfoBulb(
    ProductKey INTEGER(3) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值(流水號)
    ProductName VARCHAR(255) NOT NULL, -- 商品名稱
    ProductID VARCHAR(25) NOT NULL UNIQUE, -- 商品代號
    ProductBrand VARCHAR(50) DEFAULT '----', -- 商品廠牌
    ProductPrice INTEGER(7) DEFAULT 9999999, -- 商品價格
    ProductText VARCHAR(1000) DEFAULT '----', -- 商品說明
    ProductItem VARCHAR(100) DEFAULT '----', -- 商品分類
    ProductAbility VARCHAR(100) DEFAULT '----', -- 商品特性
    Manufacturers VARCHAR(100) DEFAULT '----', -- 進貨廠商
    InsertDate date, -- 修改日期
    InsertTime time -- 修改時間
);
