drop table Product.TimeNow;

CREATE TABLE Product.TimeNow(
	ID INTEGER(4) AUTO_INCREMENT PRIMARY KEY,-- 主鍵值(流水號)
	InsertDate date,
	InsertTime time
);