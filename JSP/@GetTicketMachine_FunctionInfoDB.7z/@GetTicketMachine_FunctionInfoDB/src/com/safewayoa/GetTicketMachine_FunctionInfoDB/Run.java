package com.safewayoa.GetTicketMachine_FunctionInfoDB;

import com.safewayoa.GetTicketMachine_FunctionInfoDB.Data.Model.FunctionInfo;
import com.safewayoa.GetTicketMachine_FunctionInfoDB.Data.Model.LoggerInfo;
import com.safewayoa.Tools.MySQL.DatabaseUtility;
import com.safewayoa.Tools.Utility.ProcessArray;
import com.safewayoa.Tools.Utility.ProcessFrame;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.File;
import java.util.List;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class Run extends Application {

    boolean isConn;

    int widthAll, heightAll, gapChoiceBoxSetup, fontSizeLabelChoiceBoxSetup, nowID, nowRangeEnd;
    int[] gapAll;

    String[] labelSetupText;
    String[] choiceBoxID;
    String[] rangeEnds, businessTypes;
    String[][] items;

    Label labelBackground, labelChoiceBoxSetup, labelTextFieldInput, labelReadBackground;
    ChoiceBox choiceBoxSetup;
    TextField textFieldInput;
    Button[] buttonSetup;
    Label[] labelRead;

    FunctionInfo[] functionInfo;
    ProcessArray processArray;
    DatabaseUtility utilDB;

    List<String> _listString;
    List<FunctionInfo> _listFunctionInfo;

    Dimension screenSize; // 取得螢幕解晰度大小
    Group root; // 畫面的根
    Scene scene; // 底層

    @Override
    public void start(Stage primaryStage) {

        root = new Group();
        scene = new Scene(root);

        utilDB = new DatabaseUtility();
        isConn = utilDB.connSQL();

        LoggerInfo.loggerInfo.info("程式正常開啟");

        initNumber();
        initLabelBackground();
        initLabelReadBackground();

        if (isConn) {
            initTextFieldInput();
            initButtonSetup();
            initFunctionInfo();
            initFunctionInfo(_listFunctionInfo);
            initLabelRead(functionInfo);
        }

        primaryStage.setTitle("業務類型設定");
        primaryStage.setWidth(widthAll);
        primaryStage.setHeight(heightAll);
        primaryStage.setScene(scene);
        // primaryStage.setResizable(false);
        // primaryStage.setFullScreen(true);
        primaryStage.show();
    }

    //----------初始化數值----------//
    private void initNumber() {

        scene.setFill(Color.rgb(50, 200, 50, 0.5));
        screenSize = Toolkit.getDefaultToolkit().getScreenSize(); // 取得當前螢幕解析度
//        widthAll = screenSize.width * 2 / 3; // 1920 * 1080
//        heightAll = screenSize.height * 2 / 3;
        widthAll = 880; // 1920 * 1080
        heightAll = 440;

        gapAll = new int[]{50, 100, 50, 50}; // 上、左、下、右
        gapChoiceBoxSetup = 90;
        fontSizeLabelChoiceBoxSetup = 20;

        functionInfo = new FunctionInfo[9];
        LoggerInfo.loggerInfo.info("初始化數據成功…");
    }

    //----------初始化FunctionInfo----------//
    private void initFunctionInfo() {

        processArray = new ProcessArray();
        _listString = processArray.ReadFileStream("com/safewayoa/GetTicketMachine_FunctionInfoDB/Data/Text/INI/FunctionInfo_UTF8.ini");

        for (int i = 0; i < functionInfo.length; i++) {
            functionInfo[i] = setListToFunctionInfo(_listString.get(i));
        }

        _listFunctionInfo = utilDB.selectFunctionInfo(new FunctionInfo());
        LoggerInfo.loggerInfo.info("初始化數據成功…");

    }

    //----------更新FunctionInfo----------//
    private void initFunctionInfo(List<FunctionInfo> _functionInfo) {

        for (int i = 0; i < functionInfo.length; i++) {
            functionInfo[i] = _functionInfo.get(i);
            //System.out.println("functionInfo[i] = " + functionInfo[i]);
        }
        LoggerInfo.loggerInfo.info("更新數據成功…");
    }

    //----------初始化背景圖----------//
    private void initLabelBackground() {

        labelBackground = new Label();
        Image imageBackground;
        String imagePath = "Image/Setup/Background.jpg";

        File files = new File("src/" + imagePath); // 測試檔案是否存在

        if (files.exists()) {
            imageBackground = new Image("file:src/" + imagePath);
        } else {
            imageBackground = new Image(this.getClass().getResourceAsStream("Data/Image/Setup/Background.jpg"));
        }
//        img = new Image(imagePath);
//        imageBackground = new Image(this.getClass().getResourceAsStream("Data/Image/BusinessTypes/Background.jpg"));
        labelBackground.setGraphic(new ImageView(imageBackground));

        root.getChildren().add(labelBackground);
        LoggerInfo.loggerInfo.info("初始化圖形成功…");
    }

    //----------初始化輸入框----------//
    private void initTextFieldInput() {

        int[] sizesTextFieldInput = {200, 30};
        rangeEnds = new String[]{"100", "200", "300", "400", "500", "600", "700", "800", "900", "999", "1100", "1200", "1300", "1400", "1500", "1600", "1700", "1800", "1900", "2000"}; // 功能名稱

        Tooltip tooltip = new Tooltip("請輸入您想要的文字…");
        textFieldInput = new TextField("測試用…");
        textFieldInput.setLayoutX(gapAll[1]);
        textFieldInput.setLayoutY(gapAll[0]);
        textFieldInput.setPrefSize(sizesTextFieldInput[0], sizesTextFieldInput[1]);
        textFieldInput.setTooltip(tooltip);
        textFieldInput.setOnKeyReleased(new EventHandlerTextFieldInput_OnKeyReleased());

        labelTextFieldInput = new Label("業務名稱");
        labelTextFieldInput.setLayoutX(gapAll[1] - gapChoiceBoxSetup);
        labelTextFieldInput.setLayoutY(gapAll[0]);
        labelTextFieldInput.setFont(Font.font("Serif", FontWeight.BOLD, FontPosture.ITALIC, fontSizeLabelChoiceBoxSetup));

        choiceBoxSetup = new ChoiceBox(FXCollections.observableArrayList(rangeEnds));
        choiceBoxSetup.setId("RangeEnd");
        choiceBoxSetup.setLayoutX(gapAll[1]);
        choiceBoxSetup.setLayoutY(gapAll[0] * 2);
        choiceBoxSetup.setPrefSize(sizesTextFieldInput[0], sizesTextFieldInput[1]);
        choiceBoxSetup.addEventHandler(ActionEvent.ACTION, new EventHandlerChoiceBoxSetup_ACTION());

        labelChoiceBoxSetup = new Label("數字範圍");
        labelChoiceBoxSetup.setLayoutX(gapAll[1] - gapChoiceBoxSetup);
        labelChoiceBoxSetup.setLayoutY(gapAll[0] * 2);
        labelChoiceBoxSetup.setFont(Font.font("Serif", FontWeight.BOLD, FontPosture.ITALIC, fontSizeLabelChoiceBoxSetup));

        root.getChildren().add(textFieldInput);
        root.getChildren().add(labelTextFieldInput);
        root.getChildren().add(choiceBoxSetup);
        root.getChildren().add(labelChoiceBoxSetup);

        LoggerInfo.loggerInfo.info("初始化輸入框成功…");
    }

    //----------初始化按鈕----------//
    private void initButtonSetup() {

        buttonSetup = new Button[3];

        String[][] buttonSetupText = {{"Reset", "初始設定"}, {"Save", "設定完成"}, {"Exit", "離開程式"}};
        int[] sizesButtonSetup = {200, 60};
        int gapButtonSetup = 30;

        for (int i = 0; i < buttonSetup.length; i++) {
            buttonSetup[i] = new Button();
            buttonSetup[i].setPrefSize(sizesButtonSetup[0], sizesButtonSetup[1]); // 設定最佳大小
            buttonSetup[i].setId(buttonSetupText[i][0]);
            buttonSetup[i].setContentDisplay(ContentDisplay.TOP);
            buttonSetup[i].setAlignment(Pos.CENTER);
            buttonSetup[i].setText(buttonSetupText[i][1]);
            buttonSetup[i].setTextFill(Color.rgb(255, 0, 0, 0.8)); // 顏色(R,G,B,透明度)
            buttonSetup[i].setOpacity(0.7); // 透明度
            buttonSetup[i].setFont(Font.font("Verdana", 20)); // (字型, 大小)
            buttonSetup[i].setTranslateX(gapAll[1]);
            buttonSetup[i].setTranslateY(gapAll[0] * (3 + i) + gapButtonSetup * i);
            // buttonSetup[i].setEffect(new Reflection()); // 設定特效：反射

            buttonSetup[i].addEventHandler(ActionEvent.ACTION, new EventHandlerButtonSetup_ACTION());
            root.getChildren().add(buttonSetup[i]);
        }
        LoggerInfo.loggerInfo.info("初始化按鍵成功…");
    }

    private void initLabelReadBackground() {

        int[] coordinateLabelRead = {350, 50};
        int[] sizesLabelRead = {400, 30};
        String styleLabelRead = "-fx-background-color:rgba(0, 0, 0, 0.3);";
        Image imageError = new Image(this.getClass().getResourceAsStream("Data/Image/BusinessTypes/Error.png"));

        labelReadBackground = new Label();
        labelReadBackground.setFont(Font.font("Verdana", 26));
        labelReadBackground.setTextFill(Color.rgb(0, 0, 0, 1.0));
        labelReadBackground.setTextAlignment(TextAlignment.LEFT);
        labelReadBackground.setLayoutX(coordinateLabelRead[0] - 10);
        labelReadBackground.setLayoutY(coordinateLabelRead[1] - 10);
        labelReadBackground.setMinWidth(sizesLabelRead[0] + 100);
        labelReadBackground.setMinHeight(sizesLabelRead[1] * (functionInfo.length + 1) + 30);

        if (!isConn) {
            labelReadBackground.setGraphic(new ImageView(imageError));
        }

        labelReadBackground.setStyle(styleLabelRead);

        root.getChildren().add(labelReadBackground);

        LoggerInfo.loggerInfo.info("初始化標籤成功…");
    }

    //----------初始化labelRead----------//
    private void initLabelRead(FunctionInfo[] _functionInfo) {

        labelRead = new Label[functionInfo.length];

        int gapLabelRead = 35, fontSizes = 26;

        int[] coordinateLabelRead = {350, 50};
        int[] sizesLabelRead = {400, 30};

        for (int i = 0; i < labelRead.length; i++) {

            labelRead[i] = new Label();
            labelRead[i].setText(_functionInfo[i].getFunctionName() + "：" + _functionInfo[i].getRangeStart() + " ~ " + _functionInfo[i].getRangeEnd());
            labelRead[i].setFont(Font.font("Verdana", fontSizes));
            labelRead[i].setTextFill(Color.rgb(0, 0, 0, 1.0));
            labelRead[i].setTextAlignment(TextAlignment.LEFT);
            labelRead[i].setLayoutX(coordinateLabelRead[0]);
            labelRead[i].setLayoutY(coordinateLabelRead[1] + gapLabelRead * i);
            labelRead[i].setMinWidth(sizesLabelRead[0]);
            labelRead[i].setMinHeight(sizesLabelRead[1]);
            labelRead[i].addEventHandler(MouseEvent.MOUSE_PRESSED, new EventHandlerLabelRead_MOUSE_PRESSED());

            //labelRead[i].setStyle(styleLabelRead);
            root.getChildren().add(labelRead[i]);
        }
        LoggerInfo.loggerInfo.info("初始化標籤成功…");
    }

    //----------事件----------//
    public class EventHandlerLabelRead_MOUSE_PRESSED implements EventHandler<MouseEvent> {

        @Override
        public void handle(MouseEvent e) {
            nowID = ProcessFrame.JObjectWhichOne(e.getSource(), labelRead);
            textFieldInput.setText(functionInfo[nowID].getFunctionName());

            for (int i = 0; i < rangeEnds.length; i++) {
                if (Integer.parseInt(rangeEnds[i]) == functionInfo[nowID].getRangeEnd()) {
                    choiceBoxSetup.getSelectionModel().select(i);
                }
            }

            //System.out.println("nowID = " + nowID);
        }
    }

    public class EventHandlerButtonSetup_ACTION implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent e) {

            Button _buttonSetup = (Button) e.getSource();
            String buttonName = _buttonSetup.getId();

            switch (buttonName) { // 利用名字做分類

                case "Reset":
                    initFunctionInfo();
                    setLabelRead_Text();
                    //System.out.println("Reset");
                    break;

                case "Save":
                    saveFunctionInfo();
                    //System.out.println("Save");
                    break;

                case "Exit":
                    LoggerInfo.loggerInfo.info("程式正常關閉");
                    System.exit(0);
                    break;

                default:
                    break;
            }
        }
    }

    public class EventHandlerChoiceBoxSetup_ACTION implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent e) {

            ChoiceBox _choiceBoxSetup = (ChoiceBox) e.getSource();
            nowRangeEnd = Integer.parseInt(rangeEnds[_choiceBoxSetup.getSelectionModel().getSelectedIndex()]);

            checkRange(nowID, nowRangeEnd);
        }
    }

    public class EventHandlerTextFieldInput_OnKeyReleased implements EventHandler<KeyEvent> {

        @Override
        public void handle(KeyEvent e) {

            if (e.getCode() == KeyCode.ENTER) {
                if (textFieldInput.getText().isEmpty()) {
                    textFieldInput.setPromptText("Please enter your word.");
                }
            }

            functionInfo[nowID].setFunctionName(textFieldInput.getText());
            labelRead[nowID].setText(functionInfo[nowID].getFunctionName() + "：" + functionInfo[nowID].getRangeStart() + " ~ " + functionInfo[nowID].getRangeEnd());

        }
    }

    //----------小工具----------// 
    private FunctionInfo setListToFunctionInfo(String str) {

        String[] arrayStr = str.split("\t");
        FunctionInfo _functionInfo = new FunctionInfo();

        _functionInfo.setFunctionCode(arrayStr[0]);
        _functionInfo.setFunctionName(arrayStr[1]);
        _functionInfo.setRangeStart(Integer.parseInt(arrayStr[2]));
        _functionInfo.setRangeEnd(Integer.parseInt(arrayStr[3]));
        _functionInfo.setRunning(Integer.parseInt(arrayStr[4]));
        _functionInfo.setWaitting(Integer.parseInt(arrayStr[5]));

        //System.out.println("_functionInfo = " + _functionInfo);
        return _functionInfo;
    }

    private void setLabelRead_Text() {
        for (int i = 0; i < functionInfo.length; i++) {
            labelRead[i].setText(functionInfo[i].getFunctionName() + "：" + functionInfo[i].getRangeStart() + " ~ " + functionInfo[i].getRangeEnd());
        }
    }

    private void saveFunctionInfo() {
        utilDB.connSQL();
        for (FunctionInfo functionInfo1 : functionInfo) {
            functionInfo1.setRunning(functionInfo1.getRangeStart() - 1);
            functionInfo1.setWaitting(0);
            utilDB.updateFunctionInfo(functionInfo1);
        }
    }

    private void checkRange(int ID, int rangeEnd) {

        for (int i = ID; i < functionInfo.length; i++) {

            if (functionInfo[i].getRangeStart() > functionInfo[i].getRangeEnd()) { // 尾巴 > 開頭 的數字，沒有的話，就選一個比開頭大一點點的選項數字
                functionInfo[i].setRangeEnd(getRange(functionInfo[i].getRangeStart()));
                //System.out.println("functionInfo[i].getRangeEnd() = " + functionInfo[i].getRangeEnd());
            } else {
                if (i == ID) {
                    if (rangeEnd > functionInfo[i].getRangeStart()) { // 所選的選項數字 > 開頭 的數字，就OK
                        functionInfo[i].setRangeEnd(rangeEnd);
                        //System.out.println("functionInfo[i].getRangeEnd() = " + functionInfo[i].getRangeEnd());
                    }
                }
            }

            if (i < functionInfo.length - 1) { // 下一個的開頭數字 = 上一個的尾巴數字 + 1 (防溢位)
                if ((functionInfo[i].getRangeEnd() + 1) != functionInfo[i + 1].getRangeStart()) {
                    functionInfo[i + 1].setRangeStart(functionInfo[i].getRangeEnd() + 1);
                }
            }

            labelRead[i].setText(functionInfo[i].getFunctionName() + "：" + functionInfo[i].getRangeStart() + " ~ " + functionInfo[i].getRangeEnd());

        }
    }

    private int getRange(int start) {

        int end = Integer.parseInt(rangeEnds[rangeEnds.length - 1]); // 設定成選項最大值

        for (int i = 0; i < rangeEnds.length; i++) {
            if (Integer.parseInt(rangeEnds[i]) > start) {
                end = Integer.parseInt(rangeEnds[i]);
                //System.out.println("end = " + end);
                break;
            }
        }
        return end;
    }

    //----------結束----------//
    public static void main(String[] args) {
        launch(args);
    }
}
