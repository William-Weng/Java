package com.safewayoa.GetTicketMachine_FunctionInfoDB.Data.Model;

import java.sql.Date;
import java.sql.Time;

public class TicketInfo {

    private int primaryKey; // Ticket唯一編號
    private int numer; // 印表機印出的號碼
    private String functionCode; // 使用功能代碼
    private String tableName; // 使用資料表
    private String status; // 使用狀態
    private Date insertDate; // 新增日期
    private Time insertTime; // 新增時間

    public TicketInfo() {
        this.tableName = "GetTicketMachine.TicketInfo";
    }

    public TicketInfo(int printNumer, String functionCode) {
        this.numer = printNumer;
        this.functionCode = functionCode;
        this.tableName = "GetTicketMachine.TicketInfo";
    }

    public int getPrimaryKey() {
        return primaryKey;
    }

    public int getNumer() {
        return numer;
    }

    public String getFunctionCode() {
        return functionCode;
    }

    public String getTableName() {
        return tableName;
    }

    public String getStatus() {
        return status;
    }

    public Date getInsertDate() {
        return insertDate;
    }

    public Time getInsertTime() {
        return insertTime;
    }

    public void setPrimaryKey(int primaryKey) {
        this.primaryKey = primaryKey;
    }

    public void setNumer(int numer) {
        this.numer = numer;
    }

    public void setFunctionCode(String functionCode) {
        this.functionCode = functionCode;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setInsertDate(Date insertDate) {
        this.insertDate = insertDate;
    }

    public void setInsertTime(Time insertTime) {
        this.insertTime = insertTime;
    }
}
