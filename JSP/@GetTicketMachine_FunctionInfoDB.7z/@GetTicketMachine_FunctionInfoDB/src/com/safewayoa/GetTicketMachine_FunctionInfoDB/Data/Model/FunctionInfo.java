package com.safewayoa.GetTicketMachine_FunctionInfoDB.Data.Model;

import java.sql.Date;
import java.sql.Time;

public class FunctionInfo {

    private int primaryKey;
    private int rangeStart;
    private int rangeEnd;
    private int running;
    private int waitting;
    private String functionCode;
    private String functionName;
    private String tableName;
    private String imagesURL;
    private Date insertDate; // 新增日期
    private Time insertTime; // 新增時間

    public FunctionInfo() {
        this.tableName = "GetTicketMachine.FunctionInfo";
    }

    public int getPrimaryKey() {
        return primaryKey;
    }

    public int getRangeStart() {
        return rangeStart;
    }

    public int getRangeEnd() {
        return rangeEnd;
    }

    public int getRunning() {
        return running;
    }

    public int getWaitting() {
        return waitting;
    }

    public String getFunctionCode() {
        return functionCode;
    }

    public String getFunctionName() {
        return functionName;
    }

    public String getTableName() {
        return tableName;
    }

    public String getImagesURL() {
        return imagesURL;
    }

    public Date getInsertDate() {
        return insertDate;
    }

    public Time getInsertTime() {
        return insertTime;
    }

    public void setPrimaryKey(int primaryKey) {
        this.primaryKey = primaryKey;
    }

    public void setRangeStart(int rangeStart) {
        this.rangeStart = rangeStart;
    }

    public void setRangeEnd(int rangeEnd) {
        this.rangeEnd = rangeEnd;
    }

    public void setRunning(int running) {
        this.running = running;
    }

    public void setWaitting(int waitting) {
        this.waitting = waitting;
    }

    public void setFunctionCode(String functionCode) {
        this.functionCode = functionCode;
    }

    public void setFunctionName(String functionName) {
        this.functionName = functionName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public void setImagesURL(String imagesURL) {
        this.imagesURL = imagesURL;
    }

    public void setInsertDate(Date insertDate) {
        this.insertDate = insertDate;
    }

    public void setInsertTime(Time insertTime) {
        this.insertTime = insertTime;
    }
}
