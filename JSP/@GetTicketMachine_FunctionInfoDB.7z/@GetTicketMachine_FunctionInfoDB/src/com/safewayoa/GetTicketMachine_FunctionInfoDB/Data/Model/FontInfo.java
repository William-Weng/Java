package com.safewayoa.GetTicketMachine_FunctionInfoDB.Data.Model;

import java.sql.Date;
import java.sql.Time;

public class FontInfo {

    private int primaryKey; // Count唯一編號
    private String FontName;
    private String FontCode;
    private String property;
    private String tableName;
    private String insertStaff; // 修改人員
    private Date insertDate; // 新增的日期
    private Time insertTime; // 新增的時間

    public FontInfo() {
        this.tableName = "GetTicketMachine.FontInfo";
    }

    public int getPrimaryKey() {
        return primaryKey;
    }

    public String getFontName() {
        return FontName;
    }

    public String getFontCode() {
        return FontCode;
    }

    public String getProperty() {
        return property;
    }

    public String getTableName() {
        return tableName;
    }

    public String getInsertStaff() {
        return insertStaff;
    }

    public Date getInsertDate() {
        return insertDate;
    }

    public Time getInsertTime() {
        return insertTime;
    }

    public void setPrimaryKey(int primaryKey) {
        this.primaryKey = primaryKey;
    }

    public void setFontName(String FontName) {
        this.FontName = FontName;
    }

    public void setFontCode(String FontCode) {
        this.FontCode = FontCode;
    }

    public void setProperty(String property) {
        this.property = property;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public void setInsertStaff(String insertStaff) {
        this.insertStaff = insertStaff;
    }

    public void setInsertDate(Date insertDate) {
        this.insertDate = insertDate;
    }

    public void setInsertTime(Time insertTime) {
        this.insertTime = insertTime;
    }
}
