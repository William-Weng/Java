// ======資料庫處理====== //
package com.safewayoa.Tools.MySQL;

import com.safewayoa.GetTicketMachine_FunctionInfoDB.Data.Model.FunctionInfo;
import com.safewayoa.GetTicketMachine_FunctionInfoDB.Data.Model.LoggerInfo;
import com.safewayoa.GetTicketMachine_FunctionInfoDB.Data.Model.SQLConnentInfo;
import com.safewayoa.Tools.Utility.TimeNow;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DatabaseUtility implements Serializable {

//----------------------------------------------------變數宣告-----------------------------------------------------//
    private Connection conn = null;
    private Statement stat = null;
    private ResultSet rs = null;
    private PreparedStatement pst = null;

    //---------------------------------------------------連線函數---------------------------------------------------//
    public boolean connSQL() {

        SQLConnentInfo infoSQL = new SQLConnentInfo();
        String driver = infoSQL.getDriver();
        String url = infoSQL.getUrl();
        String user = infoSQL.getUser();
        String password = infoSQL.getPassword();

        boolean isConn = false;

        try {

            Class.forName(driver);
            conn = DriverManager.getConnection(url, user, password);

            if (conn != null && !conn.isClosed()) {
                //System.out.println("資料庫連線測試成功…");
                LoggerInfo.loggerInfo.info("資料庫連線測試成功…");
            }

            isConn = true;

        } catch (ClassNotFoundException eNotFound) {
//            System.out.println("DriverClassNotFound :" + eNotFound.toString());
//            System.out.println("資料庫驅動程式出錯…");
            LoggerInfo.loggerInfo.info("資料庫驅動程式出錯…");
        } catch (SQLException eSQL) {
//            System.out.println("Exception :" + eSQL.toString());
//            System.out.println("資料庫帳號、密碼錯誤…");
            LoggerInfo.loggerInfo.info("資料庫帳號、密碼錯誤…");
        }
        return isConn;
    }

    //-------------------------------------------------資料庫連線關閉-----------------------------------------------//
    public void closeSQL() {
        try {

            if (rs != null) {
                rs.close();
                rs = null;
            }
            if (stat != null) {
                stat.close();
                stat = null;
            }
            if (pst != null) {
                pst.close();
                pst = null;
            }

//            System.out.println("資料庫連線關閉成功…");
            LoggerInfo.loggerInfo.info("資料庫連線關閉成功…");

        } catch (SQLException e) {
//            System.out.println("Close Exception :" + e.toString());
//            System.out.println("資料庫連線關閉失敗…");
            LoggerInfo.loggerInfo.info("資料庫連線關閉失敗…");
        }
    }

    //----------初始化下拉式選單----------//
    public List<FunctionInfo> selectFunctionInfo(FunctionInfo functionInfo) {

        String selectSQL = "SELECT * FROM " + functionInfo.getTableName() + " Order By FunctionCode";
        List<FunctionInfo> _list = new ArrayList();

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                functionInfo = setFunctionInfo();
                _list.add(functionInfo);
            }
            LoggerInfo.loggerInfo.info("資料庫查詢成功…");

        } catch (SQLException e) {
//            System.out.println("SelectTable Exception :" + e.toString());
//            System.out.println("資料庫連線查詢失敗…");
            LoggerInfo.loggerInfo.info("資料庫查詢失敗…");

        } finally {
            closeSQL();
        }
        return _list;
    }

    //----------更新按鈕資訊----------//
    public void updateFunctionInfo(FunctionInfo functionInfo) {

        String updateSQL = "UPDATE " + functionInfo.getTableName() + " "
                + "SET FunctionName = ?, RangeStart = ?, RangeEnd = ?, Running = ?, Waitting = ?, InsertDate = ?, InsertTime = ? "
                + "WHERE FunctionCode = ? ";

        try {

            pst = conn.prepareStatement(updateSQL);

            pst.setString(1, functionInfo.getFunctionName());
            pst.setInt(2, functionInfo.getRangeStart());
            pst.setInt(3, functionInfo.getRangeEnd());
            pst.setInt(4, functionInfo.getRunning());
            pst.setInt(5, functionInfo.getWaitting());
            pst.setDate(6, TimeNow.ToSqlDate());
            pst.setTime(7, TimeNow.ToSqlTime());
            pst.setString(8, functionInfo.getFunctionCode());

            pst.executeUpdate();
//            System.out.println("資料表更新成功…");
            LoggerInfo.loggerInfo.info("資料表更新成功…");

        } catch (SQLException e) {
//            System.out.println("UpdateDB Exception :" + e.toString());
//            System.out.println("資料表更新失敗…");
            LoggerInfo.loggerInfo.info("資料庫查詢失敗…");

        } finally {
            closeSQL();
        }
    }

    //-----------小工具----------//
    public FunctionInfo setFunctionInfo() throws SQLException {

        FunctionInfo _functionInfo = new FunctionInfo(); // 把Class資料清空

        _functionInfo.setFunctionCode(rs.getString("FunctionCode"));
        _functionInfo.setFunctionName(rs.getString("FunctionName"));
        _functionInfo.setPrimaryKey(rs.getInt("PrimaryKey"));
        _functionInfo.setRangeEnd(rs.getInt("RangeEnd"));
        _functionInfo.setRangeStart(rs.getInt("RangeStart"));
        _functionInfo.setRunning(rs.getInt("Running"));
        _functionInfo.setTableName("GetTicketMachine.FunctionInfo");
        _functionInfo.setWaitting(rs.getInt("Waitting"));
        _functionInfo.setImagesURL(rs.getString("ImagesURL"));
        _functionInfo.setInsertDate(rs.getDate("InsertDate"));
        _functionInfo.setInsertTime(rs.getTime("InsertTime"));

        return _functionInfo;
    }
}
