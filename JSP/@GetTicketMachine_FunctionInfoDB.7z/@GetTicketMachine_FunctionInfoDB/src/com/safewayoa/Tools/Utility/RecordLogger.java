package com.safewayoa.Tools.Utility;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class RecordLogger {

    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    private static final String LOG_FOLDER_NAME = "LoggerFile";

    private static final String LOG_FILE_SUFFIX = ".log";

    private synchronized static String getLogFilePath(String jarName) {
        StringBuffer logFilePath = new StringBuffer();

        logFilePath.append(System.getProperty("user.home")); // 就是…我的文件夾
        logFilePath.append(File.separatorChar); // 系統的分隔字元 Linux'/' Windows'\'
        logFilePath.append(LOG_FOLDER_NAME);

        // D:\William-Weng\MyLoggerFile
        File file = new File(logFilePath.toString());
        if (!file.exists()) {
            file.mkdir(); // 產生資料夾
        }

        logFilePath.append(File.separatorChar);
        logFilePath.append(sdf.format(new Date()));
        logFilePath.append(jarName);
        logFilePath.append(LOG_FILE_SUFFIX);
        // D:\William-Weng\MyLoggerFile\2014-11-03.log

        return logFilePath.toString(); // 產生文件檔
    }

    public synchronized static Logger setLoggerHanlder(Logger logger, String jarName) {
        return setLoggerHanlder(logger, Level.ALL, jarName);
    }

    public synchronized static Logger setLoggerHanlder(Logger logger, Level level, String jarName) {

        FileHandler fileHandler = null;

        try {
            //文件日誌內容標記為可追加  
            fileHandler = new FileHandler(getLogFilePath("_" + jarName), true);

            //以文本的形式輸出  
            fileHandler.setEncoding("UTF-8"); // 編碼為：UTF-8
            fileHandler.setFormatter(new SimpleFormatter());

            logger.addHandler(fileHandler);
            logger.setLevel(level);

        } catch (SecurityException | IOException e) {
            logger.severe(populateExceptionStackTrace(e));
        }
        return logger;
    }

    private synchronized static String populateExceptionStackTrace(Exception e) {
        StringBuilder sb = new StringBuilder();
        sb.append(e.toString()).append("\n");
        for (StackTraceElement elem : e.getStackTrace()) {
            sb.append("\tat ").append(elem).append("\n");
        }
        return sb.toString();
    }
}
