package parsehtml;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class ParseHTML_2 {

    private static Document doc;
    private static HashMap hashMap;
    private static String url, primaryKey;

    public static void main(String[] args) throws IOException {

        ParseHTML_2 parseHTML;
        parseHTML = new ParseHTML_2();

        parseHTML.initURL();
        parseHTML.getHtml(".tender_table_tr_1");
        parseHTML.getHtml(".tender_table_tr_2");
        parseHTML.getHtml(".tender_table_tr_3");
        parseHTML.getHtml(".tender_table_tr_5");
        parseHTML.getHtml_test(".tender_table_tr_4");

        for (Object key : hashMap.keySet()) {
            System.out.println(key + " : " + hashMap.get(key));
        }
    }

    public void initURL() throws IOException {
        hashMap = new HashMap();
        url = "http://web.pcc.gov.tw/tps/tpam/main/tps/tpam/tpam_tender_detail.do?searchMode=common&scope=F&primaryKey=";
        primaryKey = "51512404";
        doc = Jsoup.connect(url + primaryKey).get();
    }

    public void getHtml(String className) { // 1,3
        Iterator iterator_TH, iterator_TD;
        Element element_TH, element_TD;

        iterator_TH = doc.select(className + " > th").iterator();
        iterator_TD = doc.select(className + " > td").iterator();

        iterator_TD.next(); // TD多一攔

        while (iterator_TH.hasNext()) {
            element_TH = (Element) iterator_TH.next();
            element_TD = (Element) iterator_TD.next();
            hashMap.put(element_TH.childNode(0).toString().trim(), element_TD.childNode(0).toString().trim());
        }
    }

    public void getHtml_test(String className) { // 1,3
        Iterator iterator_TH;
        Element element_TH;
        String[] str = {"截止投標", "開標時間"};

        int i = 0;
        iterator_TH = doc.select(className + " > td > span").iterator();

        while (iterator_TH.hasNext()) {
            element_TH = (Element) iterator_TH.next();
            hashMap.put(str[i], element_TH.childNode(0).toString().trim());
            i++;
        }
    }
}
