package parsehtml;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class ParseHTML_1 {

    private static Document doc;
    private static HashMap hashMap;
    private static String url, primaryKey;

    public static void main(String[] args) throws IOException {

        ParseHTML_1 parseHTML;
        parseHTML = new ParseHTML_1();

        parseHTML.initURL();
        parseHTML.getHtml_a("#print_area a[href^=../tpam/main/]");
        //parseHTML.getHtml_money("#print_area td[align=right]");
        //parseHTML.getHtml_Date("#print_area td[align=left]");
        //parseHTML.getHtml_name("#print_area a u");

        for (Object key : hashMap.keySet()) {
            System.out.println(key + " : " + hashMap.get(key));
        }
    }

    public void initURL() throws IOException {
        hashMap = new HashMap();
        url = "http://web.pcc.gov.tw/tps/pss/tender.do?searchMode=common&searchType=basic&method=search&isSpdt=&pageIndex=1";
        primaryKey = "";
        doc = Jsoup.connect(url + primaryKey).get();
    }

    public void getHtml_money(String className) { // 1,3
        Iterator iterator_TH, iterator_TD;
        Element element_TH, element_TD;
        int i = 0;
        iterator_TH = doc.select(className).iterator();
        //iterator_TH.next();
        while (iterator_TH.hasNext()) {
            i++;
            element_TH = (Element) iterator_TH.next();
            System.out.println(element_TH.childNode(0).toString().trim());
        }
        System.out.println("i=" + i);
    }

    public void getHtml_Date(String className) { // 1,3
        Iterator iterator_TH, iterator_TD;
        Element element_TH, element_TD;

        iterator_TH = doc.select(className).iterator();
        //iterator_TH.next();
        while (iterator_TH.hasNext()) {
            element_TH = (Element) iterator_TH.next();
            System.out.println(element_TH.childNode(0).toString().trim());
        }
    }

    public void getHtml_name(String className) { // 1,3
        Iterator iterator_TH, iterator_TD;
        Element element_TH, element_TD;

        iterator_TH = doc.select(className).iterator();
        //iterator_TH.next();
        while (iterator_TH.hasNext()) {
            element_TH = (Element) iterator_TH.next();
            System.out.println(element_TH.childNode(0).toString().trim());
        }
    }

    public void getHtml_a(String className) { // 1,3
        Iterator iterator_TH, iterator_TD;
        Element element_TH, element_TD;

        int i = 0, j = 0;
        iterator_TH = doc.select(className).iterator();
        //iterator_TH.next();
        while (iterator_TH.hasNext()) {
            i++;
            element_TH = (Element) iterator_TH.next();
            if (i % 2 == 0) {
                j++;
                System.out.println(element_TH.toString().trim());
            }
        }
        System.out.println("i=" + i + ",j=" + j);
    }
}
