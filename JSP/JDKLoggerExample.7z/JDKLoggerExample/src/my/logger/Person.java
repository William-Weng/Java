package my.logger;

public class Person {

    int x;
    int y;
}
