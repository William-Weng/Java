package my.logger;

import java.util.logging.Logger;

public class LoggerInfo {

    public static final Logger loggerInfo = RecordLogger.setLoggerHanlder(Logger.getLogger("com.safewayoa"), "TicketSetup");
}
