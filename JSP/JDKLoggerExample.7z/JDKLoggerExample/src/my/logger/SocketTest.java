package my.logger;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class SocketTest {

    public static void main(String[] args) {
        try {
            InetAddress addr = InetAddress.getByName("www.google.com.tw");
            Socket socket = new Socket(addr, 80);
            socket.close();
        } catch (UnknownHostException ex) {
            System.out.println(ex.getMessage());
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

}
