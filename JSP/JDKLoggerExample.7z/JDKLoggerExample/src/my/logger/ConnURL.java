package my.logger;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConnURL {

    public static void main(String[] args) {
        URL url;
        try {
            url = new URL("https://www.google.com.tw/");
            URLConnection connURL = url.openConnection();
            connURL.connect();
            try (InputStreamReader inputStreamReader = new InputStreamReader(connURL.getInputStream(), "Big5")) {
                String contentType = connURL.getContentType();
                String encoding = contentType.substring(contentType.lastIndexOf("=") + 1);

                System.out.println("contentType = " + contentType);
                System.out.println("encoding = " + encoding);

                int data = inputStreamReader.read();

                while (data != -1) {
                    System.out.print((char) data);
                    data = inputStreamReader.read();
                }
            }
        } catch (MalformedURLException ex) {
            Logger.getLogger(ConnURL.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ConnURL.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
