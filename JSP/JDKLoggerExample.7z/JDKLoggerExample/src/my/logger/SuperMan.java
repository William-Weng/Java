package my.logger;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SuperMan {

    public static void main(String[] args) {

        InetAddress[] inetAddress;
        Enumeration<NetworkInterface> networkInterface;

        try {
            System.out.println("x=" + InetAddress.getLocalHost());

            inetAddress = InetAddress.getAllByName("TP500LN");
            for (int i = 0; i < inetAddress.length; i++) {
                System.out.println("InetAddress = " + inetAddress[i]);
            }
        } catch (UnknownHostException ex) {
            Logger.getLogger(SuperMan.class.getName()).log(Level.SEVERE, null, ex);

        }
    }
}
