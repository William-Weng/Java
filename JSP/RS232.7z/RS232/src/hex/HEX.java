package hex;

public class HEX {

    public static void main(String[] args) {
        String strHex = "FE 00 18 F8 7E FE 78 66 E6 FE 00 98 80 00 60 78 00 00 00 FE FE 0D 0A 00";
        String[] str = strHex.split(" ");

        // System.out.println((char) (178));
        for (String str1 : str) {
            System.out.print((char) (Integer.parseInt(str1, 16)) + " ");
        }
    }

}
