// ======文數字處理====== //
package csv;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class ArrayProcess {

    //--------------------寫入檔案並讀出-------------------//
    public void WriteFile() {

        try (PrintWriter pw = new PrintWriter("D:\\CSV\\BOOK1.TXT");) { // 自動嘗試關閉資源…

            for (int i = 1; i <= 9; i++) {
                for (int j = 1; j <= 9; j++) {
                    pw.print(i + "*" + j + "=" + (i * j < 10 ? i * j + " " : i * j) + " ");
                }
                pw.println();
            }
            pw.flush();
            //pw.close();

            ReadFile("D:\\CSV\\1.TXT");
        } catch (IOException e) {
            System.out.println(e.toString());
        }
    }

    //--------------------讀取檔案並存成ArrayList-------------------//
    public List<String> ReadFile(String fileName) {

        List<String> _list = new ArrayList();
        int i = 0;
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF-8"));) {

            String _str;

            while ((_str = br.readLine()) != null) {
                //System.out.println(_str);
                _list.add(_str);
            }

            br.close();

        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        return _list;
    }
}
