package csv;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {

    public static void main(String[] args) {

        String fileName = "D:\\CSV\\~來源~.CSV";
        String fileName2 = "D:\\CSV\\~欄位~.TXT";
        List<String> listString, listKey;
        String[] strArray, keyArray;
        StringBuilder stringBuilder = new StringBuilder();
        ArrayProcess arrayProcess = new ArrayProcess();

        String keyWord;
        String keyField;
        String keyValue = "沒有數值";

        listString = arrayProcess.ReadFile(fileName);
        listKey = arrayProcess.ReadFile(fileName2);

        keyArray = listKey.get(0).split("，");

        keyWord = keyArray[0];
        keyField = keyArray[1];

        for (int j = 0; j < listString.size(); j++) {
            strArray = listString.get(j).split(",");

            if (strArray.length > 0) {
                if (strArray[0].trim().equals(keyWord) || strArray[0].trim().equals(keyField)) {

                    for (int i = 0; i < strArray.length; i++) {

                        if (strArray[i].trim().equals(keyWord)) {
                            stringBuilder.append("\r\n");
                        }

                        if (strArray.length == 1) {
                            stringBuilder.append(strArray[i].trim()).append(",").append(keyValue).append(",");
                        }
                        stringBuilder.append(strArray[i].trim()).append(",");
                    }
                }
            }
        }

        //System.out.println(stringBuilder);

        try {
            try (PrintWriter pw = new PrintWriter("D:\\CSV\\" + keyField + ".txt", "UTF-8")) {
                pw.println(stringBuilder.toString());
                pw.flush();
            }
        } catch (FileNotFoundException | UnsupportedEncodingException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
