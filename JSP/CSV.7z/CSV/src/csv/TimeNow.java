// ======時間處理====== //
package csv;

import java.util.*;
import java.text.SimpleDateFormat;

public class TimeNow {

//----------------------------------------------------變數宣告-----------------------------------------------------//
    private String sAllTime = ""; // 1911-01-01 12:00:00:000…
    private String sDate = ""; // 1911-01-01…
    private String sTime = ""; // 12:00:00:000…
    private String sYear = ""; // 年…
    private String sMonth = ""; // 月…
    private String sDay = ""; // 日…
    private String sHour = ""; // 時…
    private String sMinute = ""; // 分…
    private String sSecond = ""; // 秒…
    private String sMilliSecond = ""; // 毫秒…

//---------------------------------------------------初始化函數---------------------------------------------------//
    public TimeNow() {

        //SimpleDateFormat allTimeNow = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss:SSS"); // 設定時間格式…
        SimpleDateFormat allTimeNow = new SimpleDateFormat("yyyy-MM-dd kk:mm"); // 設定時間格式…
        SimpleDateFormat dateNow = new SimpleDateFormat("yyyy-MM-dd"); // 設定時間格式…
        SimpleDateFormat timeNow = new SimpleDateFormat("kk-mm-ss-SSS"); // 設定時間格式…
        SimpleDateFormat yearNow = new SimpleDateFormat("yyyy"); // 設定時間格式…
        SimpleDateFormat monthNow = new SimpleDateFormat("MM"); // 設定時間格式…
        SimpleDateFormat dayNow = new SimpleDateFormat("dd"); // 設定時間格式…
        SimpleDateFormat hourNow = new SimpleDateFormat("kk"); // 設定時間格式…
        SimpleDateFormat minuteNow = new SimpleDateFormat("mm"); // 設定時間格式…
        SimpleDateFormat secondNow = new SimpleDateFormat("ss"); // 設定時間格式…
        SimpleDateFormat milliSecondNow = new SimpleDateFormat("SSS"); // 設定時間格式…

        Date nowToday = new Date(); // 取得當前時間…
        this.sAllTime = allTimeNow.format(nowToday); // 依格式取得時間…
        this.sDate = dateNow.format(nowToday); // 依格式取得時間…
        this.sTime = timeNow.format(nowToday); // 依格式取得時間…
        this.sYear = yearNow.format(nowToday); // 依格式取得時間…
        this.sMonth = monthNow.format(nowToday); // 依格式取得時間…
        this.sDay = dayNow.format(nowToday); // 依格式取得時間…
        this.sHour = hourNow.format(nowToday); // 依格式取得時間…
        this.sMinute = minuteNow.format(nowToday); // 依格式取得時間…
        this.sSecond = secondNow.format(nowToday); // 依格式取得時間…
        this.sMilliSecond = milliSecondNow.format(nowToday); // 依格式取得時間…
    }

    public java.sql.Date ToSqlDate() {
        java.util.Date now = new java.util.Date();
        java.sql.Date sqlDate = new java.sql.Date(now.getTime());

//        System.out.println(now);
//        System.out.println(sqlDate);
        return sqlDate;
    }

    public java.sql.Time ToSqlTime() {
        java.util.Date now = new java.util.Date();
        java.sql.Time sqlTime = new java.sql.Time(now.getTime());

//        System.out.println(now);
//        System.out.println(sqlTime);
        return sqlTime;
    }

    public static long getSystemTimeMillis() {
        return System.currentTimeMillis();
    }
//-----------------------------------------------------建構函數----------------------------------------------------//

    public String getAllTime() {
        return sAllTime;
    }

    public void setAllTime(String sAllTime) {
        this.sAllTime = sAllTime;
    }

    public String getDate() {
        return sDate;
    }

    public void setDate(String sDate) {
        this.sDate = sDate;
    }

    public String getTime() {
        return sTime;
    }

    public void setTime(String sTime) {
        this.sTime = sTime;
    }

    public String getYear() {
        return sYear;
    }

    public void setYear(String sYear) {
        this.sYear = sYear;
    }

    public String getMonth() {
        return sMonth;
    }

    public void setMonth(String sMonth) {
        this.sMonth = sMonth;
    }

    public String getDay() {
        return sDay;
    }

    public void setDay(String sDay) {
        this.sDay = sDay;
    }

    public String getHour() {
        return sHour;
    }

    public void setHour(String sHour) {
        this.sHour = sHour;
    }

    public String getMinute() {
        return sMinute;
    }

    public void setMinute(String sMinute) {
        this.sMinute = sMinute;
    }

    public String getSecond() {
        return sSecond;
    }

    public void setSecond(String sSecond) {
        this.sSecond = sSecond;
    }

    public String getMilliSecond() {
        return sMilliSecond;
    }

    public void setMilliSecond(String sMilliSecond) {
        this.sMilliSecond = sMilliSecond;
    }
//-----------------------------------------------------結束----------------------------------------------------------//
}
