// ======文數字處理====== //
package com.safewayoa.Tools.Utility;

import com.safewayoa.GetTicketMachine_TicketSetup.Data.Model.LoggerInfo;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

public class ProcessArray {

//--------------------將ArrayList轉成Array----------------------//
    public String[] ListToArray(List<String> list) {
        String[] arrayStr = null;

        if (!list.isEmpty()) { // ArrayList 轉 Array
            arrayStr = new String[list.size()];
            arrayStr = list.toArray(arrayStr);
        } else {
            arrayStr = new String[]{"0", "0000"};
        }
        return arrayStr;
    }

    //--------------------寫入檔案並讀出-------------------//
    public void WriteFile() {

        try (PrintWriter pw = new PrintWriter("D:\\CSV\\1.TXT");) { // 自動嘗試關閉資源…

            for (int i = 1; i <= 9; i++) {
                for (int j = 1; j <= 9; j++) {
                    pw.print(i + "*" + j + "=" + (i * j < 10 ? i * j + " " : i * j) + " ");
                }
                pw.println();
            }
            pw.flush();
            //pw.close();

            ReadFile("D:\\CSV\\1.TXT");
        } catch (IOException e) {
            System.out.println(e.toString());
        }
    }

    //--------------------讀取檔案並存成ArrayList-------------------//
    public List<String> ReadFileStream(String path) {

        // path = "jar:file:" + Run.class.getResource("!/" + path).getPath();
        // List<String> list = new ProcessArray().ReadFile("com/safewayoa/GetTicketMachine_TicketSetup/Safewayoa.ini");
        try {
            path = URLDecoder.decode(path, "UTF-8");
        } catch (UnsupportedEncodingException ex) {
            System.out.println(ex.getMessage());
        }

        List<String> list = null;

        ClassLoader cl = this.getClass().getClassLoader();

        //InputStreamReader inr = new InputStreamReader(cl.getResourceAsStream(path),"UTF-8");
        //try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(path), "UTF-8"));) { // 自動嘗試關閉資源…
        try (BufferedReader br = new BufferedReader(new InputStreamReader(cl.getResourceAsStream(path), "UTF-8"));) { // 自動嘗試關閉資源…

            list = new ArrayList();
            br.readLine(); // 第一行標題不要讀

            String data;

            while ((data = br.readLine()) != null) {
                //System.out.println(data);

                // data = new String(data.getBytes("UTF-8"), "UTF-8");
                list.add(data);
            }

            LoggerInfo.loggerInfo.info("檔案串流讀取OK");

        } catch (IOException e) {
            //System.out.println(e.toString());
            LoggerInfo.loggerInfo.info("檔案串流讀取錯誤");
        }

        return list;
    }

    //--------------------讀取檔案並存成ArrayList-------------------//
    public List<String> ReadFile(String path) {

        //path = this.getClass().getResource(path).getPath();
        try {
            path = URLDecoder.decode(path, "UTF-8");
        } catch (UnsupportedEncodingException ex) {
            System.out.println(ex.getMessage());
        }

        //System.out.println(path);
        List<String> list = null;

        try (FileReader fr = new FileReader(path);
                BufferedReader br = new BufferedReader(fr);) { // 自動嘗試關閉資源…

            list = new ArrayList();
            br.readLine();
            String data;

            while ((data = br.readLine()) != null) {
                //System.out.println(data);
                list.add(data);
            }
            LoggerInfo.loggerInfo.info("檔案讀取OK");

        } catch (IOException e) {
            //System.out.println(e.toString());
            LoggerInfo.loggerInfo.info("檔案讀取OK");
        }
        return list;
    }

    public static String toUtf8(String str) throws UnsupportedEncodingException {
        return new String(str.getBytes("UTF-8"), "UTF-8");
    }
}
