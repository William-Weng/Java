// ======資料庫處理====== //
package com.safewayoa.Tools.MySQL;

import com.safewayoa.GetTicketMachine_TicketSetup.Data.Model.FontInfo;
import com.safewayoa.GetTicketMachine_TicketSetup.Data.Model.LoggerInfo;
import com.safewayoa.GetTicketMachine_TicketSetup.Data.Model.SQLConnentInfo;
import com.safewayoa.GetTicketMachine_TicketSetup.Data.Model.ViewFontInfo;
import com.safewayoa.GetTicketMachine_TicketSetup.Data.Model.ViewImageInfo;
import com.safewayoa.Tools.Utility.TimeNow;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DatabaseUtility implements Serializable {

//----------------------------------------------------變數宣告-----------------------------------------------------//
    private Connection conn = null;
    private Statement stat = null;
    private ResultSet rs = null;
    private PreparedStatement pst = null;

//---------------------------------------------------初始化函數---------------------------------------------------//
    public boolean connSQL() {

        SQLConnentInfo infoSQL = new SQLConnentInfo();
        String driver = infoSQL.getDriver();
        String url = infoSQL.getUrl();
        String user = infoSQL.getUser();
        String password = infoSQL.getPassword();

        boolean isConn = false;

        try {

            Class.forName(driver);
            conn = DriverManager.getConnection(url, user, password);

            if (conn != null && !conn.isClosed()) {
                //System.out.println("資料庫連線測試成功…");
                LoggerInfo.loggerInfo.info("資料庫連線測試成功…");
            }

            isConn = true;

        } catch (ClassNotFoundException eNotFound) {
            //System.out.println("DriverClassNotFound :" + eNotFound.toString());
            //System.out.println("資料庫驅動程式出錯…");
            LoggerInfo.loggerInfo.info("資料庫驅動程式出錯…");

        } catch (SQLException eSQL) {
//            System.out.println("Exception :" + eSQL.toString());
//            System.out.println("資料庫帳號、密碼錯誤…");
            LoggerInfo.loggerInfo.info("資料庫帳號、密碼錯誤…");
        }
        return isConn;
    }

    //-------------------------------------------------資料庫連線關閉-----------------------------------------------//
    public void closeSQL() {
        try {

            if (rs != null) {
                rs.close();
                rs = null;
            }
            if (stat != null) {
                stat.close();
                stat = null;
            }
            if (pst != null) {
                pst.close();
                pst = null;
            }

//            System.out.println("資料庫連線關閉成功…");
            LoggerInfo.loggerInfo.info("資料庫連線關閉成功…");

        } catch (SQLException e) {
//            System.out.println("Close Exception :" + e.toString());
//            System.out.println("資料庫連線關閉失敗…");
            LoggerInfo.loggerInfo.info("資料庫連線關閉失敗…");
        }
    }

    //----------FontInfo----------//
    public List<FontInfo> selectFontInfo(FontInfo fontInfo) {

        String selectSQL = "SELECT * FROM " + fontInfo.getTableName() + " Order By PrimaryKey ";
        List<FontInfo> _list = new ArrayList();

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                fontInfo = setFontInfo();
                _list.add(fontInfo);
            }

            LoggerInfo.loggerInfo.info("資料庫連線查詢OK…");

        } catch (SQLException e) {
//            System.out.println("SelectTable Exception :" + e.toString());
//            System.out.println("資料庫連線查詢失敗…");
            LoggerInfo.loggerInfo.info("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    //----------ViewFontInfo----------//
    public List<ViewFontInfo> selectViewFontInfo(ViewFontInfo fontViewInfo) {

        String selectSQL = "SELECT * FROM " + fontViewInfo.getTableName() + " Order By PrimaryKey ";
        List<ViewFontInfo> _list = new ArrayList();

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                fontViewInfo = setViewFontInfo();
                _list.add(fontViewInfo);
            }

            LoggerInfo.loggerInfo.info("資料庫連線查詢OK…");

        } catch (SQLException e) {
//            System.out.println("SelectTable Exception :" + e.toString());
//            System.out.println("資料庫連線查詢失敗…");
            LoggerInfo.loggerInfo.info("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    //----------ViewImageInfo----------//
    public List<ViewImageInfo> selectViewImageInfo(ViewImageInfo viewImageInfo) {

        String selectSQL = "SELECT * FROM " + viewImageInfo.getTableName() + " Order By PrimaryKey ";
        List<ViewImageInfo> _list = new ArrayList();

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                viewImageInfo = setViewImageInfo();
                _list.add(viewImageInfo);
            }

            LoggerInfo.loggerInfo.info("資料庫連線查詢OK…");

        } catch (SQLException e) {
//            System.out.println("SelectTable Exception :" + e.toString());
//            System.out.println("資料庫連線查詢失敗…");
            LoggerInfo.loggerInfo.info("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    //----------更新資訊----------//
    public void updateViewFontInfo(ViewFontInfo viewFontInfo) {

        String updateSQL = "UPDATE " + viewFontInfo.getTableName() + " "
                + "SET Sizes = ?, TypeCode = ?, X = ?, Y = ?, BackgroundColorRGB = ?, ColorRGB = ?, FontName = ?, Texts = ?, InsertDate = ?, InsertTime = ? "
                + "WHERE ViewFontName = ?";

        try {

            pst = conn.prepareStatement(updateSQL);

            pst.setInt(1, viewFontInfo.getSizes());
            pst.setInt(2, viewFontInfo.getTypeCode());
            pst.setInt(3, viewFontInfo.getX());
            pst.setInt(4, viewFontInfo.getY());
            pst.setString(5, viewFontInfo.getBackgroundColorRGB());
            pst.setString(6, viewFontInfo.getColorRGB());
            pst.setString(7, viewFontInfo.getFontName());
            pst.setString(8, viewFontInfo.getTexts());
            pst.setDate(9, TimeNow.ToSqlDate());
            pst.setTime(10, TimeNow.ToSqlTime());

            pst.setString(11, viewFontInfo.getViewFontName());

            pst.executeUpdate();
            //System.out.println("資料表更新成功…");
            LoggerInfo.loggerInfo.info("資料庫更新OK…");

        } catch (SQLException e) {
//            System.out.println("UpdateDB Exception :" + e.toString());
//            System.out.println("資料表更新失敗…");
            LoggerInfo.loggerInfo.info("資料表更新失敗…");
        } finally {
            closeSQL();
        }
    }

    //----------更新資訊----------//
    public void updateViewImageInfo(ViewImageInfo viewImageInfo) {

        String updateSQL = "UPDATE " + viewImageInfo.getTableName() + " "
                + "SET X = ?, Y = ?, InsertDate = ?, InsertTime = ? "
                + "WHERE ViewImageName = ?";

        try {

            pst = conn.prepareStatement(updateSQL);

            pst.setInt(1, viewImageInfo.getX());
            pst.setInt(2, viewImageInfo.getY());
            pst.setDate(3, TimeNow.ToSqlDate());
            pst.setTime(4, TimeNow.ToSqlTime());

            pst.setString(5, viewImageInfo.getViewImageName());

            pst.executeUpdate();
            //System.out.println("資料表更新成功…");
            LoggerInfo.loggerInfo.info("資料庫更新OK…");

        } catch (SQLException e) {
//            System.out.println("UpdateDB Exception :" + e.toString());
//            System.out.println("資料表更新失敗…");
            LoggerInfo.loggerInfo.info("資料表更新失敗…");
        } finally {
            closeSQL();
        }
    }

    //----------小工具----------//
    public FontInfo setFontInfo() throws SQLException {

        FontInfo _fontInfo = new FontInfo(); // 把Class資料清空

        _fontInfo.setFontCode(rs.getString("FontCode"));
        _fontInfo.setFontName(rs.getString("FontName"));
        _fontInfo.setInsertDate(rs.getDate("InsertDate"));
        _fontInfo.setInsertStaff(rs.getString("InsertStaff"));
        _fontInfo.setInsertTime(rs.getTime("InsertTime"));
        _fontInfo.setPrimaryKey(rs.getInt("PrimaryKey"));
        _fontInfo.setProperty(rs.getString("Property"));
        _fontInfo.setTableName(rs.getString("TableName"));

        return _fontInfo;
    }

    public ViewFontInfo setViewFontInfo() throws SQLException {

        ViewFontInfo _viewFontInfo = new ViewFontInfo(); // 把Class資料清空

        _viewFontInfo.setBackgroundColorRGB(rs.getString("BackgroundColorRGB"));
        _viewFontInfo.setColorRGB(rs.getString("ColorRGB"));
        _viewFontInfo.setFontName(rs.getString("FontName"));
        _viewFontInfo.setInsertDate(rs.getDate("InsertDate"));
        _viewFontInfo.setInsertStaff(rs.getString("InsertStaff"));
        _viewFontInfo.setInsertTime(rs.getTime("InsertTime"));
        _viewFontInfo.setPrimaryKey(rs.getInt("PrimaryKey"));
        _viewFontInfo.setSizes(rs.getInt("Sizes"));
        _viewFontInfo.setTableName(rs.getString("TableName"));
        _viewFontInfo.setTexts(rs.getString("Texts"));
        _viewFontInfo.setTypeCode(rs.getInt("TypeCode"));
        _viewFontInfo.setViewFontName(rs.getString("ViewFontName"));
        _viewFontInfo.setX(rs.getInt("X"));
        _viewFontInfo.setY(rs.getInt("Y"));
        _viewFontInfo.setProperty(rs.getString("Property"));

        return _viewFontInfo;
    }

    public ViewImageInfo setViewImageInfo() throws SQLException {

        ViewImageInfo _viewImageInfo = new ViewImageInfo(); // 把Class資料清空

        _viewImageInfo.setInsertDate(rs.getDate("InsertDate"));
        _viewImageInfo.setInsertStaff(rs.getString("InsertStaff"));
        _viewImageInfo.setInsertTime(rs.getTime("InsertTime"));
        _viewImageInfo.setPaths(rs.getString("Paths"));
        _viewImageInfo.setPrimaryKey(rs.getInt("PrimaryKey"));
        _viewImageInfo.setProperty(rs.getString("Property"));
        _viewImageInfo.setViewImageName(rs.getString("ViewImageName"));
        _viewImageInfo.setX(rs.getInt("X"));
        _viewImageInfo.setY(rs.getInt("Y"));

        return _viewImageInfo;
    }

    // print
    public void printFontInfo(FontInfo fontInfo) {
        // System.out.println("PrimaryKey" + "\t" + "FontCode" + "\t" + "FontName" + "\t" + "Property" + "\t" + "TableName" + "\t" + "InsertStaff" + "\t" + "InsertDate" + "InsertTime");

        System.out.print(fontInfo.getPrimaryKey() + "\t");
        System.out.print(fontInfo.getFontCode() + "\t");
        System.out.print(fontInfo.getFontName() + "\t");
        System.out.print(fontInfo.getProperty() + "\t");
        System.out.print(fontInfo.getTableName() + "\t");
        System.out.print(fontInfo.getInsertStaff() + "\t");
        System.out.print(fontInfo.getInsertDate() + "\t");
        System.out.print(fontInfo.getInsertTime() + "\n");
    }

    public void printViewFontInfo(ViewFontInfo viewFontInfo) {
        //System.out.println("PrimaryKey" + "\t" + "Texts" + "\t" + "X" + "\t" + "Y" + "\t" + "Fonts" + "\t" + "Sizes" + "\t" + "Types" + "\t" + "ColorRGB" + "\t" + "BackgroundColorRGB" + "\t" + "InsertStaff" + "\t" + "InsertDate" + "\t" + "InsertTime" + "\t" + "TableName");

        System.out.print(viewFontInfo.getPrimaryKey() + "\t");
        System.out.print(viewFontInfo.getTexts() + "\t");
        System.out.print(viewFontInfo.getX() + "\t");
        System.out.print(viewFontInfo.getY() + "\t");
        System.out.print(viewFontInfo.getFontName() + "\t");
        System.out.print(viewFontInfo.getSizes() + "\t");
        System.out.print(viewFontInfo.getTypeCode() + "\t");
        System.out.print(viewFontInfo.getColorRGB() + "\t");
        System.out.print(viewFontInfo.getBackgroundColorRGB() + "\t");
        System.out.print(viewFontInfo.getInsertStaff() + "\t");
        System.out.print(viewFontInfo.getInsertDate() + "\t");
        System.out.print(viewFontInfo.getInsertTime() + "\t");
        System.out.print(viewFontInfo.getProperty() + "\t");
        System.out.print(viewFontInfo.getViewFontName() + "\t");
        System.out.print(viewFontInfo.getTableName() + "\n");
    }

    public void printViewImageInfo(ViewImageInfo viewImageInfo) {
        //System.out.println("PrimaryKey" + "\t" + "X" + "\t" + "Y" + "\t" + "Paths" + "\t" + "Property" + "\t" + "TableName" + "\t" + "InsertStaff" + "\t" + "InsertDate" + "\t" + "InsertTime");

        System.out.print(viewImageInfo.getPrimaryKey() + "\t");
        System.out.print(viewImageInfo.getX() + "\t");
        System.out.print(viewImageInfo.getY() + "\t");
        System.out.print(viewImageInfo.getPaths() + "\t");
        System.out.print(viewImageInfo.getProperty() + "\t");
        System.out.print(viewImageInfo.getTableName() + "\t");
        System.out.print(viewImageInfo.getViewImageName() + "\t");
        System.out.print(viewImageInfo.getInsertStaff() + "\t");
        System.out.print(viewImageInfo.getInsertDate() + "\t");
        System.out.print(viewImageInfo.getInsertTime() + "\n");
    }
}
