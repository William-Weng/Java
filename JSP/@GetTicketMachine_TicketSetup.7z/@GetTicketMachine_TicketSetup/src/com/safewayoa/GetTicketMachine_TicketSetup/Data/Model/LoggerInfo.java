package com.safewayoa.GetTicketMachine_TicketSetup.Data.Model;

import com.safewayoa.Tools.Utility.RecordLogger;
import java.util.logging.Logger;

public class LoggerInfo {

    public static final Logger loggerInfo = RecordLogger.setLoggerHanlder(Logger.getLogger("com.safewayoa"), "TicketSetup");
}
