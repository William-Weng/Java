package com.safewayoa.GetTicketMachine_TicketSetup.Data.Model;

import java.sql.Date;
import java.sql.Time;

public class ViewImageInfo {

    private int primaryKey;
    private int x;
    private int y;
    private String paths;
    private String tableName;
    private String property;
    private String viewImageName;
    private String insertStaff;
    private Date insertDate;
    private Time insertTime;

    public ViewImageInfo() {
        this.tableName = "GetTicketMachine.ViewImageInfo";
    }

    public int getPrimaryKey() {
        return primaryKey;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public String getPaths() {
        return paths;
    }

    public String getTableName() {
        return tableName;
    }

    public String getProperty() {
        return property;
    }

    public String getViewImageName() {
        return viewImageName;
    }

    public String getInsertStaff() {
        return insertStaff;
    }

    public Date getInsertDate() {
        return insertDate;
    }

    public Time getInsertTime() {
        return insertTime;
    }

    public void setPrimaryKey(int primaryKey) {
        this.primaryKey = primaryKey;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void setPaths(String paths) {
        this.paths = paths;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public void setProperty(String property) {
        this.property = property;
    }

    public void setViewImageName(String viewImageName) {
        this.viewImageName = viewImageName;
    }

    public void setInsertStaff(String insertStaff) {
        this.insertStaff = insertStaff;
    }

    public void setInsertDate(Date insertDate) {
        this.insertDate = insertDate;
    }

    public void setInsertTime(Time insertTime) {
        this.insertTime = insertTime;
    }

}
