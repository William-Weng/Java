package com.safewayoa.GetTicketMachine_TicketSetup.Data.Model;

import java.sql.Date;
import java.sql.Time;

public class ViewFontInfo {

    private int primaryKey;
    private int x;
    private int y;
    private int sizes;
    private int typeCode;
    private String texts;
    private String fontName;
    private String colorRGB;
    private String backgroundColorRGB;
    private String tableName;
    private String insertStaff;
    private String property;
    private String viewFontName;
    private Date insertDate;
    private Time insertTime;

    public ViewFontInfo() {
        this.tableName = "GetTicketMachine.ViewFontInfo";
    }

    public int getPrimaryKey() {
        return primaryKey;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getSizes() {
        return sizes;
    }

    public int getTypeCode() {
        return typeCode;
    }

    public String getTexts() {
        return texts;
    }

    public String getFontName() {
        return fontName;
    }

    public String getColorRGB() {
        return colorRGB;
    }

    public String getBackgroundColorRGB() {
        return backgroundColorRGB;
    }

    public String getTableName() {
        return tableName;
    }

    public String getInsertStaff() {
        return insertStaff;
    }

    public String getProperty() {
        return property;
    }

    public String getViewFontName() {
        return viewFontName;
    }

    public Date getInsertDate() {
        return insertDate;
    }

    public Time getInsertTime() {
        return insertTime;
    }

    public void setPrimaryKey(int primaryKey) {
        this.primaryKey = primaryKey;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void setSizes(int sizes) {
        this.sizes = sizes;
    }

    public void setTypeCode(int typeCode) {
        this.typeCode = typeCode;
    }

    public void setTexts(String texts) {
        this.texts = texts;
    }

    public void setFontName(String fontName) {
        this.fontName = fontName;
    }

    public void setColorRGB(String colorRGB) {
        this.colorRGB = colorRGB;
    }

    public void setBackgroundColorRGB(String backgroundColorRGB) {
        this.backgroundColorRGB = backgroundColorRGB;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public void setInsertStaff(String insertStaff) {
        this.insertStaff = insertStaff;
    }

    public void setProperty(String property) {
        this.property = property;
    }

    public void setViewFontName(String viewFontName) {
        this.viewFontName = viewFontName;
    }

    public void setInsertDate(Date insertDate) {
        this.insertDate = insertDate;
    }

    public void setInsertTime(Time insertTime) {
        this.insertTime = insertTime;
    }

}
