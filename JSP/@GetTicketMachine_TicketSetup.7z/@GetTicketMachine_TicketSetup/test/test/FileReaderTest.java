package test;

import java.io.*;

public class FileReaderTest {

    public static void main(String[] args) {
        FileReader fin;
        
        try {
            fin = new FileReader(FileReaderTest.class.getResource("1.ini").getFile());
            int word;
            while (fin.ready()) {
                word = fin.read();
                System.out.print((char) word);
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
