package test;

public class _Main_ {

    public static void main(String[] args) {
//        DatabaseUtility utilDB = new DatabaseUtility();
//        List<ViewImageInfo> _list;
//
//        utilDB.connSQL();
//        _list = utilDB.selectViewImageInfo(new ViewImageInfo());
//
//        for (int i = 0; i < _list.size(); i++) {
//            utilDB.printViewImageInfo(_list.get(i));
//        }
//
//        _list.get(2).setX(123);
//        _list.get(2).setY(123);
//        utilDB.updateViewImageInfo(_list.get(2));
//
//        ButtonFunctionInfo buttonFunctionInfo = new ButtonFunctionInfo();
//        ButtonInfo buttonInfo = new ButtonInfo();
//
//        buttonInfo.setFunctionCode("C001");
//        buttonInfo.setButtonName("ButtonRun3");
//        
//        utilDB = new DatabaseUtility();
//
//        buttonFunctionInfo = utilDB.selectButtonFunctionInfoOne(buttonInfo);
//
//        utilDB.printButtonFunctionInfo(buttonFunctionInfo);
//        PrintTicket_2 PrintTicket_2 = new PrintTicket_2();
//        PrintTicket_2.printTicket(1234);
    }
}
