/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tools.Utility;

/**
 *
 * @author William-Weng
 */
public class Word {

    public static boolean isNumeric(String string) {
        for (int i = string.length(); --i >= 0;) {
            int chr = string.charAt(i);
            if (chr < '0' || chr > '9') {
                return false;
            }
        }
        return true;
    }
}
