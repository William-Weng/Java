package Tools.MySQL;

import Data.Model.RegisterIDInfo;
import Data.Model.SQLConnentInfo;
import Tools.Utility.TimeNow;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DatabaseUtility implements Serializable {

    private Connection conn;
    private Statement stat;
    private ResultSet rs;
    private PreparedStatement pst;

    //--------------------[開啟資料庫連線]--------------------//
    public DatabaseUtility() {

        setAllNull();

        SQLConnentInfo infoSQL = new SQLConnentInfo();

        try {

            Class.forName(infoSQL.getDriver());
            conn = DriverManager.getConnection(infoSQL.getUrl(), infoSQL.getUser(), infoSQL.getPassword());

            if (conn != null && !conn.isClosed()) {
                System.out.println("資料庫連線測試成功…");
            }

        } catch (ClassNotFoundException eNotFound) {
            System.out.println("DriverClassNotFound :" + eNotFound.toString());
            System.out.println("資料庫驅動程式出錯…");
        } catch (SQLException eSQL) {
            System.out.println("Exception :" + eSQL.toString());
            System.out.println("資料庫帳號、密碼錯誤…");
        }
    }

    //--------------------[關閉資料庫連線]--------------------//
    private void closeSQL() {
        try {

            if (rs != null) {
                rs.close();
                rs = null;
            }
            if (stat != null) {
                stat.close();
                stat = null;
            }
            if (pst != null) {
                pst.close();
                pst = null;
            }

            System.out.println("資料庫連線關閉成功…");

        } catch (SQLException e) {
            System.out.println("Close Exception :" + e.toString());
            System.out.println("資料庫連線關閉失敗…");
        }
    }

    //--------------------[清空資料庫連線]--------------------//
    private void setAllNull() {
        conn = null;
        stat = null;
        rs = null;
        pst = null;
    }

    //--------------------[寫入註冊資訊]--------------------//
    public void insert(RegisterIDInfo registerIDInfo) {

        String _insertSQL = "INSERT INTO " + registerIDInfo.getTableName() + " (RegID, UpdateTime, UserName, Password) VALUES (?, ?, ?, ?)";

        try {

            pst = conn.prepareStatement(_insertSQL);

            pst.setString(1, registerIDInfo.getRegID());
            pst.setString(2, registerIDInfo.getUpdateTime());
            pst.setString(3, registerIDInfo.getUserName());
            pst.setString(4, registerIDInfo.getPassword());

            pst.executeUpdate();

            System.out.println("資料庫連線新增成功…");

        } catch (SQLException e) {
            System.out.println("InsertDB Exception :" + e.toString());
            System.out.println("資料庫尚未建立…");
        } finally {
            closeSQL();
        }
    }

    //--------------------[查詢所有註冊資訊]--------------------//
    public List<RegisterIDInfo> select(RegisterIDInfo registerIDInfo) {

        registerIDInfo = new RegisterIDInfo();
        String _selectSQL = "SELECT * FROM " + registerIDInfo.getTableName() + " ORDER BY UpdateTime DESC";
        List<RegisterIDInfo> _list = null;

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(_selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                registerIDInfo = new RegisterIDInfo(); // 把Class資料清空

                registerIDInfo.setID(rs.getInt("ID"));
                registerIDInfo.setUserName(rs.getString("UserName"));
                registerIDInfo.setPassword(rs.getString("Password"));
                registerIDInfo.setCreateTime(rs.getString("CreateTime"));
                registerIDInfo.setUpdateTime(rs.getString("UpdateTime"));
                registerIDInfo.setPushTime(rs.getString("PushTime"));
                registerIDInfo.setTimes(rs.getInt("Times"));
                registerIDInfo.setTableName(rs.getString("TableName"));
                registerIDInfo.setCode(rs.getString("Code"));
                registerIDInfo.setRegID(rs.getString("RegID"));

                _list.add(registerIDInfo);
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    //--------------------[查詢有沒有該筆使用者名稱]--------------------//
    public boolean selectUserName(RegisterIDInfo registerIDInfo) {

        boolean isRegisteredID = false;
        String _selectSQL = "SELECT * FROM " + registerIDInfo.getTableName() + " WHERE UserName = '" + registerIDInfo.getUserName() + "'";

        System.out.println(_selectSQL);

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(_selectSQL);

            while (rs.next()) {
                isRegisteredID = true;
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }

        System.out.println("isRegisteredID=" + isRegisteredID);
        return isRegisteredID;
    }

    //--------------------[查詢總筆數]--------------------//
    public int selectCount(String tableName) {

        // SELECT COUNT(*) AS rowCount FROM gcm.registeridinfo WHERE PushTime >= '1991-01-01 09:00:00';
        String _selectSQL = "SELECT COUNT(*) AS rowCount FROM " + tableName;

        int _count = 0;

        try {
            stat = conn.createStatement();
            rs = stat.executeQuery(_selectSQL);

            rs.next();
            _count = rs.getInt("rowCount");

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _count;
    }

    //--------------------[查詢總筆數]--------------------//
    public int selectCount(String tableName, RegisterIDInfo registerIDInfo) {

        // 未到結標日期，而且，到上一次看的日期之間
        // SELECT * FROM Money7988.PurchaseInfo WHERE EndTime >= '2015-02-02' AND UpdateTime >= '2015-02-02 11:11:00'
        String _selectSQL = "SELECT COUNT(*) AS rowCount FROM " + tableName + " WHERE EndTime >= '" + new TimeNow().getDate() + "' AND UpdateTime >= '" + registerIDInfo.getPushTime() + "'";

        System.out.println("_selectSQL =" + _selectSQL);

        int _count = 0;

        try {
            stat = conn.createStatement();
            rs = stat.executeQuery(_selectSQL);

            rs.next();
            _count = rs.getInt("rowCount");

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _count;
    }

    //--------------------[更新流水號資訊]--------------------//
    public void update(RegisterIDInfo registerIDInfo) {

        String updateSQL = "UPDATE " + registerIDInfo.getTableName() + " SET RegID = ?, UpdateTime = ? WHERE UserName = ?";

        try {

            pst = conn.prepareStatement(updateSQL);

            pst.setString(1, registerIDInfo.getRegID());
            pst.setString(2, registerIDInfo.getUpdateTime());
            pst.setString(3, registerIDInfo.getUserName());

            pst.executeUpdate();
            System.out.println("資料表更新成功…");

        } catch (SQLException e) {
            System.out.println("UpdateDB Exception :" + e.toString());
            System.out.println("資料表更新失敗…");
        } finally {
            closeSQL();
        }
    }

    //--------------------[更新流水號資訊]--------------------//
    public void updateGCM(RegisterIDInfo registerIDInfo) {

        String updateSQL = "UPDATE " + registerIDInfo.getTableName() + " SET PushTime = ? WHERE UserName = ?";

        try {

            pst = conn.prepareStatement(updateSQL);

            pst.setString(1, new TimeNow().getAllTime());
            pst.setString(2, registerIDInfo.getUserName());

            pst.executeUpdate();
            System.out.println("資料表更新成功…");

        } catch (SQLException e) {
            System.out.println("UpdateDB Exception :" + e.toString());
            System.out.println("資料表更新失敗…");
        } finally {
            closeSQL();
        }
    }

    //--------------------[刪除該資訊]--------------------//
    public void delete(String tableName, String userName, String password) {

        String deleteSQL = "DELETE FROM " + tableName + " WHERE UserName = ? AND Password = ?";

        try {

            pst = conn.prepareStatement(deleteSQL);
            pst.setString(1, userName);
            pst.setString(2, password);
            pst.executeUpdate();
            System.out.println("資料刪除成功…");

        } catch (SQLException e) {
            System.out.println("DeleteDB Exception :" + e.toString());
            System.out.println("資料表沒有可刪除的資料…");
        } finally {
            closeSQL();
        }
    }
}
