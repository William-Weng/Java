package Java.Serlet;

import Data.Model.RegisterIDInfo;
import Tools.MySQL.DatabaseUtility;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.android.gcm.server.Message;
import com.google.android.gcm.server.Result;
import com.google.android.gcm.server.Sender;
import java.util.List;

@WebServlet("/GCM_I_Send")
public class GCM_I_Send extends HttpServlet {

    private static final long serialVersionUID = 1L;

    // Put your Google API Server Key here
    private static final String GOOGLE_SERVER_KEY = "AIzaSyCRDKTR9NjVzx6Nza_i-JlYFy8h070HbEk";
    static final String MESSAGE_KEY = "message";

    public GCM_I_Send() {
        super();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        DatabaseUtility utilDB = new DatabaseUtility();
        List<RegisterIDInfo> registerIDInfo;

        Result result = null;

        String userMessage = request.getParameter("message");

        // userMessage = new String(userMessage.getBytes("UTF-8"), "UTF-8");

        registerIDInfo = utilDB.select(new RegisterIDInfo());

        String regId = "";

        // GCM RedgId of Android device to send push notification
        for (int i = 0; i < registerIDInfo.size(); i++) {
            regId = registerIDInfo.get(i).getRegID();

            Sender sender = new Sender(GOOGLE_SERVER_KEY);
            Message message = new Message.Builder().timeToLive(30).delayWhileIdle(true).addData(MESSAGE_KEY, userMessage).build();

            System.out.println("regId: " + regId);
            result = sender.send(message, regId, 1);
            request.setAttribute("pushStatus", result.toString());
        }
        request.getRequestDispatcher("GCM_I_Send.jsp").forward(request, response);
    }
}
