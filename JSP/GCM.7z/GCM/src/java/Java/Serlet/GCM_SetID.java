package Java.Serlet;

import Data.Model.RegisterIDInfo;
import Tools.MySQL.DatabaseUtility;
import Tools.Utility.TimeNow;
import java.io.IOException;
import java.io.Serializable;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// http://192.168.0.117:8080/GCM?username=winni&password=810725&regid=iwueuriewuosoiu)
@WebServlet(urlPatterns = {"/GCM.setID"})

public class GCM_SetID extends HttpServlet implements Serializable {

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");

        DatabaseUtility utilDB = new DatabaseUtility();
        RegisterIDInfo registerIDInfo = new RegisterIDInfo(request.getParameter("username"), request.getParameter("password"), request.getParameter("regid"), new TimeNow().getAllTime());

        if (utilDB.selectUserName(registerIDInfo)) { // 沒有沒註冊該名字
            utilDB.update(registerIDInfo); // 有就更新
        } else {
            utilDB.insert(registerIDInfo); // 沒有就新增
        }

        response.setStatus(HttpServletResponse.SC_OK);
        System.out.println(response.getStatus());
    }
}
