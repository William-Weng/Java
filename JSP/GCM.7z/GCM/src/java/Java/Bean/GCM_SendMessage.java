package Java.Bean;

import Data.Model.RegisterIDInfo;
import Tools.MySQL.DatabaseUtility;
import com.google.android.gcm.server.Message;
import com.google.android.gcm.server.Result;
import com.google.android.gcm.server.Sender;
import java.io.IOException;
import java.io.Serializable;
import java.util.List;

public class GCM_SendMessage implements Serializable {

    private static final String GOOGLE_SERVER_KEY = "AIzaSyCRDKTR9NjVzx6Nza_i-JlYFy8h070HbEk";
    static final String MESSAGE_KEY = "message";
    DatabaseUtility utilDB;

    public GCM_SendMessage() {
        utilDB = new DatabaseUtility();
    }

    public void sendMessage() {

        List<RegisterIDInfo> registerIDInfo;

        Result result = null;

        registerIDInfo = utilDB.select(new RegisterIDInfo());

        String regId = "";

        Sender sender = new Sender(GOOGLE_SERVER_KEY);

        int count = utilDB.selectCount(new RegisterIDInfo().getTableName());
        
        String userMessage = "共有" + count + "筆新的採購資訊";
        Message message = new Message.Builder().timeToLive(30).delayWhileIdle(true).addData(MESSAGE_KEY, userMessage).build();

        for (int i = 0; i < registerIDInfo.size(); i++) {
            regId = registerIDInfo.get(i).getRegID();

            try {
                result = sender.send(message, regId, 1);
                //System.out.println("OOOooo...");
            } catch (IOException ex) {
                System.out.println("IOException error");
            }
        }
    }

    public int getCount() {
        int count = utilDB.selectCount(new RegisterIDInfo().getTableName());
        return count;
    }
}
