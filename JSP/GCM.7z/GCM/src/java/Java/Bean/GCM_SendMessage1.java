package Java.Bean;

import Data.Model.RegisterIDInfo;
import Tools.MySQL.DatabaseUtility;
import com.google.android.gcm.server.Message;
import com.google.android.gcm.server.Result;
import com.google.android.gcm.server.Sender;
import java.io.IOException;
import java.io.Serializable;
import java.util.List;

public class GCM_SendMessage1 implements Serializable {

    private static final String GOOGLE_SERVER_KEY = "AIzaSyCRDKTR9NjVzx6Nza_i-JlYFy8h070HbEk";
    static final String MESSAGE_KEY = "message";
    DatabaseUtility utilDB;
    private int count;

    public GCM_SendMessage1() {
        utilDB = new DatabaseUtility();
    }

    public void sendMessage() {

        List<RegisterIDInfo> registerIDInfo;
        Result result = null;
        String regId = "";
        Sender sender;
        String userMessage;
        Message message;

        registerIDInfo = utilDB.select(new RegisterIDInfo());
        sender = new Sender(GOOGLE_SERVER_KEY);

        for (int i = 0; i < registerIDInfo.size(); i++) {

            count = utilDB.selectCount("Money7988.PurchaseInfo", registerIDInfo.get(i));

            regId = registerIDInfo.get(i).getRegID();

            if (count > 0) { // 有資料的話才推播
                userMessage = "共有" + count + "筆新的採購資訊";
                message = new Message.Builder().timeToLive(30).delayWhileIdle(true).addData(MESSAGE_KEY, userMessage).build();
                utilDB.updateGCM(registerIDInfo.get(i));

                try {
                    result = sender.send(message, regId, 1);
                } catch (IOException ex) {
                    System.out.println("IOException error");
                }
            }
        }
    }

    public int getCount() {
        return count;
    }
}
