package Data.Model;

public class RegisterIDInfo {

    private int id; // 流水編號
    private int times; // 登入次數
    private String userName; // 使用者名稱
    private String password; // 使用者密碼
    private String regID; // 手機ID
    private String createTime; // 建立時間
    private String updateTime; // 更新時間
    private String pushTime; // 推播時間
    private String tableName; // 資料表名
    private String code; // 其它功能

    //--------------------[初始化變數]--------------------//
    public RegisterIDInfo() {
        this.tableName = "GCM.RegisterIDInfo";
    }

    public RegisterIDInfo(String userName, String password, String regID, String updateTime) {
        this();
        this.userName = userName;
        this.password = password;
        this.regID = regID;
        this.updateTime = updateTime;
    }

    //--------------------[自定義輸出格式]--------------------//
    @Override
    public String toString() {
        String _tab = "\t";
        String _str = this.getID() + _tab + this.getUserName() + _tab + this.getPassword() + _tab + this.getRegID() + _tab + this.getTimes() + _tab + this.getCreateTime() + _tab + this.getUpdateTime() + _tab + this.getPushTime() + _tab + this.getTableName() + _tab + this.getCode();
        return _str;
    }

    //--------------------[設定、取值]--------------------//
    public int getID() {
        return id;
    }

    public int getTimes() {
        return times;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }

    public String getRegID() {
        return regID;
    }

    public String getCreateTime() {
        return createTime;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public String getTableName() {
        return tableName;
    }

    public String getCode() {
        return code;
    }

    public void setID(int id) {
        this.id = id;
    }

    public void setTimes(int times) {
        this.times = times;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setRegID(String regID) {
        this.regID = regID;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public void setCode(String code) {
        this.code = code;
    }
    //--------------------[結束]--------------------//

    public String getPushTime() {
        return pushTime;
    }

    public void setPushTime(String pushTime) {
        this.pushTime = pushTime;
    }
}
