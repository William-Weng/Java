package Data.Model;

public class GCM_Model {

    private String Authorization;
    private String API_KEY;
    private String GCM_URL;
    private String REG_ID;

    public GCM_Model() {
        this.Authorization = "57b0dad2f5b0c2c017a4a2842cff4a489265d2b4";
        this.API_KEY = "AIzaSyCRDKTR9NjVzx6Nza_i-JlYFy8h070HbEk";
        this.GCM_URL = "https://android.googleapis.com/gcm/send";
        this.REG_ID = "APA91bHNRclXa4GVFwP0bW1HG-vexO4x3a3wbfbXJcDIQK281dqIDtuBLk5XeuApZegTxt0P9KTG24_kQsmMIruNBXHHTHYDxaWL_CkWODn7Feg8n6DBfb8S1U1f-JMLa5KVvC4M_2qN8ujLz1xrGJ5RwN2cujoviA";
    }

    public String getAuthorization() {
        return Authorization;
    }

    public String getAPI_KEY() {
        return API_KEY;
    }

    public String getGCM_URL() {
        return GCM_URL;
    }

    public String getREG_ID() {
        return REG_ID;
    }

    public void setAuthorization(String Authorization) {
        this.Authorization = Authorization;
    }

    public void setAPI_KEY(String API_KEY) {
        this.API_KEY = API_KEY;
    }

    public void setGCM_URL(String GCM_URL) {
        this.GCM_URL = GCM_URL;
    }

    public void setREG_ID(String REG_ID) {
        this.REG_ID = REG_ID;
    }

}
