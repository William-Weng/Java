package Test;

import Data.Model.RegisterIDInfo;
import Tools.MySQL.DatabaseUtility;

public class Main {

    public static void main(String[] args) {
        DatabaseUtility utilDB = new DatabaseUtility();
        // utilDB.delete("gcm.registeridinfo", "william", "19790609");

        RegisterIDInfo registerIDInfo = new RegisterIDInfo();

        registerIDInfo.setPushTime("2015-01-01 00:00:00");
        int count = utilDB.selectCount("Money7988.PurchaseInfo", registerIDInfo);
        System.out.println("Count = " + count);
    }
}
