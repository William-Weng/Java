package test;

import com.safewayoa.GetTicketMachine.Data.Model.ViewFontInfo;
import com.safewayoa.GetTicketMachine.Data.Model.ViewImageInfo;
import com.safewayoa.GetTicketMachine.Run;
import com.safewayoa.Tools.MySQL.DatabaseUtility;
import com.safewayoa.Tools.Utility.TimeNow;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import static java.awt.print.Printable.NO_SUCH_PAGE;
import static java.awt.print.Printable.PAGE_EXISTS;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.IOException;
import java.util.List;
import javax.imageio.ImageIO;

public class PrintTicketTest implements Printable {

    private int ticketInfoNumer;
    Image image;

    //--- Private instances declarations
    public void printTicket(int ticketInfoNumer) {

        this.ticketInfoNumer = ticketInfoNumer;

        PrinterJob printJob = PrinterJob.getPrinterJob();
        printJob.setPrintable(this);

        // boolean OK = printJob.printDialog();
        boolean OK = true;

        if (OK) {
            try {
                printJob.print();
            } catch (PrinterException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    @Override
    public int print(Graphics g, PageFormat pageFormat, int page) {

        Graphics2D g2d;
        DatabaseUtility utilDB;

        //--- Validate the page number, we only print the first page
        if (page == 0) {  //--- Create a graphic2D object a set the default parameters
            utilDB = new DatabaseUtility();
            utilDB.connSQL();
            g2d = (Graphics2D) g;
            g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY()); // 設定到(0,0)

            List<ViewFontInfo> _listViewFontInfo = utilDB.selectViewFontInfo(new ViewFontInfo());
            List<ViewImageInfo> _listViewImageInfo = utilDB.selectViewImageInfo(new ViewImageInfo());

            for (int i = 0; i < _listViewFontInfo.size(); i++) {

                ViewFontInfo viewFontInfo = _listViewFontInfo.get(i);

                switch (viewFontInfo.getProperty()) {
                    case "Number": // 印數字
                        viewFontInfo.setTexts(String.valueOf(ticketInfoNumer));
                        break;
                    case "Time": // 印時間
                        viewFontInfo.setTexts(String.valueOf(TimeNow.ToSqlDate() + " " + TimeNow.ToSqlTime()));
                        break;
                    default:
                        break;
                }

                viewFontInfo.setX(10 + i * 20);
                viewFontInfo.setY(10 + i * 20);
                printString(g2d, viewFontInfo);
            }

            for (int i = 0; i < 1; i++) {

                ViewImageInfo viewImageInfo = _listViewImageInfo.get(i);

                viewImageInfo.setX(10 + i * 20);
                viewImageInfo.setY(10 + i * 20);
                // System.out.println("viewImageInfo.getPaths() = " + viewImageInfo.getPaths());
                printImage(g2d, viewImageInfo);
            }

            return (PAGE_EXISTS);
        } else {
            return (NO_SUCH_PAGE);
        }
    }

    //----------小工具----------//
    private int[] getGRB(String colors) { // 將(25,25,25)切開
        String[] _colors = colors.split(",");
        int[] textColor = {Integer.parseInt(_colors[0]), Integer.parseInt(_colors[1]), Integer.parseInt(_colors[2])};
        return textColor;
    }

    private void printString(Graphics2D g2d, ViewFontInfo fontViewInfo) {
        int[] textColor = getGRB(fontViewInfo.getColorRGB());
        int[] textBackgroundColor = getGRB(fontViewInfo.getBackgroundColorRGB());

        g2d.setFont(new Font("", Font.BOLD, 36));
        g2d.setColor(new Color(textBackgroundColor[0], textBackgroundColor[1], textBackgroundColor[2])); // 文字底色

        if (!fontViewInfo.getBackgroundColorRGB().equals("255,255,255")) { // 底色白色就變透明
            g2d.fillRect(fontViewInfo.getX(), fontViewInfo.getY(), g2d.getFontMetrics().stringWidth(fontViewInfo.getTexts()), g2d.getFontMetrics().getHeight()); // 取得文字的寬、高
        }

        g2d.setColor(new Color(textColor[0], textColor[1], textColor[2]));// 文字顏色，正常顯示字符串，剛好在底色框內
        g2d.drawString(fontViewInfo.getTexts(), fontViewInfo.getX(), fontViewInfo.getY() + g2d.getFontMetrics().getAscent());
    }

    private void printImage(Graphics2D g2d, ViewImageInfo viewImageInfo) {

        // picPath = "Data/Image/TicketInfo/Logo.gif";
        try {
            // image = ImageIO.read(new File(picPath));
            image = ImageIO.read(Run.class.getResourceAsStream(viewImageInfo.getPaths()));

        } catch (IOException ex) {
            System.out.println("No example.jpg!!");
        }

        g2d.drawImage(image, viewImageInfo.getX(), viewImageInfo.getY(), null);
    }

    public int getTicketInfoNumer() {
        return ticketInfoNumer;
    }

    public void setTicketInfoNumer(int ticketInfoNumer) {
        this.ticketInfoNumer = ticketInfoNumer;
    }
}
