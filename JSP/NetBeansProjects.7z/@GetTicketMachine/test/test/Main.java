package test;

import java.util.ArrayList;
import java.util.List;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {

        List<String> list = new ArrayList();
        list.add("A");
        list.add("B");
        list.add("C");
        list.add("D");
        list.add("E");
        Label label = new Label("測試用");

        ChoiceBox choiceBox = new ChoiceBox(FXCollections.observableArrayList(list));
        ChoiceBox choiceBox2 = new ChoiceBox(FXCollections.observableArrayList(list));
        choiceBox.getSelectionModel().selectedIndexProperty().addListener(new changeListener());
        choiceBox2.getSelectionModel().selectedIndexProperty().addListener(new changeListener());

        choiceBox.setPrefSize(20, 20);
        choiceBox2.setPrefSize(20, 20);
        choiceBox2.setLayoutX(100);
        choiceBox2.setLayoutY(100);
        choiceBox2.setPrefSize(20, 20);
        Group root = new Group();

        root.getChildren().add(label);
        root.getChildren().add(choiceBox);
        root.getChildren().add(choiceBox2);

        Scene scene = new Scene(root, 300, 250);

        primaryStage.setTitle("Hello World!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public class changeListener implements ChangeListener<Number> {

        @Override
        public void changed(ObservableValue observable, Number oldValue, Number newValue) {
            System.out.println(newValue.intValue());
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

}
