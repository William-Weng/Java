// 加強一下
package com.safewayoa.GetTicketMachine;

import com.safewayoa.GetTicketMachine.Data.Model.ButtonFunctionInfo;
import com.safewayoa.Tools.Utility.PrintTicket;
import com.safewayoa.GetTicketMachine.Data.Model.ButtonInfo;
import com.safewayoa.GetTicketMachine.Data.Model.ButtonRunCoordinate;
import com.safewayoa.GetTicketMachine.Data.Model.ButtonRunSetupInfo;
import com.safewayoa.GetTicketMachine.Data.Model.ButtonRunSize;
import com.safewayoa.GetTicketMachine.Data.Model.CountInfo;
import com.safewayoa.GetTicketMachine.Data.Model.FunctionInfo;
import com.safewayoa.GetTicketMachine.Data.Model.TicketInfo;
import com.safewayoa.Tools.MySQL.DatabaseUtility;
import com.safewayoa.Tools.Utility.ProcessFrame;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import javafx.scene.effect.DropShadow;
import javafx.scene.Group;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.RotateEvent;
import javafx.scene.input.ZoomEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;

public class Run extends Application {

    int widthAll, heightAll, nowID, nowWidths, nowHeights, nowCounts; // 外形的寬、高、選到的按鈕、選單上當前所選的寬、選單上當前所選的高、選單上當前所選的按鈕數目
    int delayTime, nowTicketNumber, numberLabel;
    double orgSceneX, orgSceneY; // 點在按鈕上的(x,y)
    double orgTranslateX, orgTranslateY; // 移動按鈕時的(x,y)
    double zoomfactor; // 放大的比例
    boolean isDrag, isConn; // 功能設定開關、資料庫連線測試

    String password = ""; // 四角關閉按鍵的密碼
    String nowFunctionCodes = ""; // 選單上當前所選的功能
    String basePath, extension; // 圖示基本路徑、副檔名
    String[] widthSetup; // 功能選單：寬
    String[] heightSetup; // 功能選單：高
    String[] functionSetup, _functionSetup; // 功能選單：功能、代碼
    String[] countSetup; // 功能選單：按鍵數量
    String[][] items; // 功能選單的總合

    Dimension screenSize; // 取得螢幕解晰度大小
    Group root; // 畫面的根
    Scene scene; // 底層

    Label labelBackground; // 最底部的圖
    Image imageError; // 按鈕上的錯誤訊息
    Image[] imageRun; // 按鈕上的圖示
    Button[] buttonClose, buttonRun, buttonSetup; // 四角關閉按鍵、內容中動作按鍵、設定功能鍵
    ChoiceBox[] choiceBoxSetup; // 設定選項
    Label[] labelSetup; // 設定選項提示

    CountInfo counts; // 設定的按鈕數目
    PrintTicket printTicket; // 列印號碼牌
    ButtonInfo[] buttonInfoRun; // 儲存功能鈕的資訊
    ButtonInfo[] buttonInfoClose; // 儲存四角按鈕的資訊
    DatabaseUtility utilDB; // 使用資料庫功能
    List<FunctionInfo> functionInfo_List; // 讀取按鈕功能選項

    public Run() {
        this.isDrag = false;
        this.isConn = false;
    }

    @Override

    public void start(Stage primaryStage) {

        root = new Group();
        scene = new Scene(root);
        scene.setFill(Color.rgb(50, 200, 50, 0.8));

        screenSize = Toolkit.getDefaultToolkit().getScreenSize(); // 取得當前螢幕解析度
        zoomfactor = 1.0; // 比率：1.0
        widthAll = screenSize.width / 3 * 2; // 1920 * 1080
        heightAll = screenSize.height / 3 * 2;

        utilDB = new DatabaseUtility();
        isConn = utilDB.connSQL();

        delayTime = 100; // 100ms

        System.out.println("isConn = " + isConn);
        System.out.println("");

        initLabelBackground();
        initButtonRun();
        initButtonClose();

        primaryStage.setTitle("大鑫資訊");
        primaryStage.setWidth(widthAll);
        primaryStage.setHeight(heightAll);
        primaryStage.setScene(scene);
        primaryStage.setResizable(true);
        //primaryStage.setFullScreen(true);
        primaryStage.show();
    }

    //----------初始化底圖----------//
    private void initLabelBackground() {

        labelBackground = new Label();
        Image imageBackground;
        String imagePath = "Image/BusinessTypes/Background.jpg";

        File files = new File("src/" + imagePath); // 測試檔案是否存在

        System.out.println("files.exists ? " + files.exists());

        if (files.exists()) {
            imageBackground = new Image(imagePath);
        } else {
            imageBackground = new Image(this.getClass().getResourceAsStream("Data/Image/BusinessTypes/Background.jpg"));
        }
//        img = new Image(imagePath);
//        imageBackground = new Image(this.getClass().getResourceAsStream("Data/Image/BusinessTypes/Background.jpg"));
        labelBackground.setGraphic(new ImageView(imageBackground));

        root.getChildren().add(labelBackground);
    }

//----------四角關閉按鈕初始化----------//
    private void initButtonClose() {

        int width = 50;
        int height = 50;
        int[][] coordinate = {{0, 0}, {widthAll - width, 0}, {widthAll - width, heightAll - height}, {0, heightAll - height}};
        double opacity = 0.5;

        buttonClose = new Button[4];
        buttonInfoClose = new ButtonInfo[buttonClose.length];

        for (int i = 0; i < buttonClose.length; i++) {

            buttonInfoClose[i] = new ButtonInfo(coordinate[i][0], coordinate[i][1], width, height, opacity);

            buttonClose[i] = new Button();
            buttonClose[i].setPrefSize(buttonInfoClose[i].getWidth(), buttonInfoClose[i].getHeight()); // 設定最佳大小
            buttonClose[i].setTranslateX(buttonInfoClose[i].getX());
            buttonClose[i].setTranslateY(buttonInfoClose[i].getY());
            buttonClose[i].setOpacity(buttonInfoClose[i].getOpacity());
            buttonClose[i].addEventHandler(ActionEvent.ACTION, new EventHandlerClose_ACTION());

            root.getChildren().add(buttonClose[i]);
        }
    }

    //----------功能按鈕初始化----------//
    private void initButtonRun() {

        int gap = 50;

        if (isConn) {
            counts = utilDB.selectCountInfoOne(new CountInfo("Counts"));
        } else {
            counts = new CountInfo();
            imageError = new Image(this.getClass().getResourceAsStream("Data/Image/BusinessTypes/Error.png"));
        }

        initImageRun();

        buttonRun = new Button[counts.getCounts()];
        buttonInfoRun = new ButtonInfo[buttonRun.length];
        ButtonRunSize sizes = new ButtonRunSize(buttonRun.length, widthAll, heightAll, gap); // 建立初始值

        for (int i = 0; i < buttonRun.length; i++) {

            ButtonRunCoordinate coordinate = new ButtonRunCoordinate(i + 1, sizes); // 從1開始數

            buttonRun[i] = new Button();
            buttonRun[i].setPrefSize(sizes.getWidth(), sizes.getHeight()); // 設定最佳大小
            buttonRun[i].setId("ButtonRun" + (i + 1));
            buttonRun[i].setContentDisplay(ContentDisplay.TOP);
            buttonRun[i].setAlignment(Pos.CENTER);
            buttonRun[i].setText("等待人數：0人");
            // buttonRun.getStylesheets().add("com/safewayoa/GetTicketMachine/Run.css");
            buttonRun[i].setTextFill(Color.rgb(255, 0, 0, 0.8)); // 顏色(R,G,B,透明度)
            buttonRun[i].setOpacity(0.5); // 透明度
            buttonRun[i].setFont(Font.font("Verdana", 20)); // (字型, 大小)
            buttonRun[i].setTranslateX(coordinate.getX());
            buttonRun[i].setTranslateY(coordinate.getY());

            if (isConn) {
                buttonRun[i].setGraphic(new ImageView(imageRun[i]));
            } else {
                buttonRun[i].setGraphic(new ImageView(imageError));
            }

            buttonRun[i].setOnZoomStarted(new EventHandler_OnZoomStarted());
            buttonRun[i].setOnZoom(new EventHandler_OnZoom());
            buttonRun[i].setOnZoomFinished(new EventHandler_ZoomFinished());

            buttonRun[i].setOnRotationStarted(new EventHandler_OnRotationStarted());
            buttonRun[i].setOnRotate(new EventHandler_OnRotate());
            buttonRun[i].setOnRotationFinished(new EventHandler_OnRotationFinished());

            buttonRun[i].addEventHandler(MouseEvent.MOUSE_DRAGGED, new EventHandler_MOUSE_DRAGGED());
            buttonRun[i].addEventHandler(MouseEvent.MOUSE_PRESSED, new EventHandler_MOUSE_PRESSED());

            buttonRun[i].addEventHandler(ActionEvent.ACTION, new EventHandler_ACTION());

            buttonInfoRun[i] = new ButtonInfo(coordinate.getX(), coordinate.getY(), sizes.getWidth(), sizes.getHeight(), buttonRun[i].getOpacity(), buttonRun[i].getId());
            buttonInfoRun[i].setFunctionCode("A001");

            root.getChildren().add(buttonRun[i]);
        }
    }

    //----------設定按鈕初始化----------//
    private void initButtonSetup() {

        buttonSetup = new Button[5];

        String[][] buttonSetupText = {{"Submit", "送出"}, {"Count", "設定"}, {"Reset", "初始設定"}, {"Save", "設定完成"}, {"Read", "讀取設定"}};
        int[][] size = {{100, 36}, {100, 36}, {200, 100}, {200, 100}, {200, 100}};
        int[][] coordinate = {{750, 10}, {1120, 10}, {widthAll / 2 - size[3][0] / 2 - size[2][0], heightAll - size[2][1]}, {widthAll / 2 - size[3][0] / 2, heightAll - size[3][1]}, {widthAll / 2 + size[3][0] / 2, heightAll - size[4][1]}}; // 將下方設定的按鈕置

        for (int i = 0; i < buttonSetup.length; i++) {
            buttonSetup[i] = new Button();
            buttonSetup[i].setPrefSize(size[i][0], size[i][1]); // 設定最佳大小
            buttonSetup[i].setId(buttonSetupText[i][0]);
            buttonSetup[i].setContentDisplay(ContentDisplay.TOP);
            buttonSetup[i].setAlignment(Pos.CENTER);
            buttonSetup[i].setText(buttonSetupText[i][1]);
            // buttonRun.getStylesheets().add("com/safewayoa/GetTicketMachine/Run.css");
            buttonSetup[i].setTextFill(Color.rgb(255, 0, 0, 0.8)); // 顏色(R,G,B,透明度)
            buttonSetup[i].setOpacity(0.7); // 透明度
            buttonSetup[i].setFont(Font.font("Verdana", 20)); // (字型, 大小)
            buttonSetup[i].setTranslateX(coordinate[i][0]);
            buttonSetup[i].setTranslateY(coordinate[i][1]);
            buttonSetup[i].addEventHandler(ActionEvent.ACTION, new EventHandlerSetup_ACTION());

            root.getChildren().add(buttonSetup[i]);
        }
    }

    //----------下拉選單初始化----------//
    private void initChoiceBoxSetup() {

        int gapTop = 10;
        int[] gapLabel = {100, 400, 560, 900};
        int[] gapChoiceBox = {270, 450, 640, 1000};
        int[] sizes = {100, 36};

        widthSetup = new String[]{"100", "200", "300", "400", "500", "600", "700", "800", "900", "1000"};
        heightSetup = new String[]{"100", "200", "300", "400", "500", "600", "700", "800", "900", "1000"};
        countSetup = new String[]{"1", "2", "3", "4", "5", "6", "7", "8", "9"};

        //functionSetup = new String[]{"L01", "M01", "N01"};
        functionInfo_List = new ArrayList();
        List<String> _listName = new ArrayList();
        List<String> _listCode = new ArrayList();

        functionInfo_List = utilDB.selectFunctionInfo(new FunctionInfo());

        for (int i = 0; i < functionInfo_List.size(); i++) {
            _listName.add(functionInfo_List.get(i).getFunctionName());
            _listCode.add(functionInfo_List.get(i).getFunctionCode());
        } // 加強一下

        functionSetup = (String[]) _listName.toArray(new String[0]); // 功能名稱
        _functionSetup = (String[]) _listCode.toArray(new String[0]); // 功能代碼

        items = new String[][]{widthSetup, heightSetup, functionSetup, countSetup};

        String[] labelSetupText = {"按鍵1 → 寬：", "高：", "功能：", "按鈕數："};
        String[] choiceBoxID = {"widths", "heights", "functions", "counts"};

        choiceBoxSetup = new ChoiceBox[4];
        labelSetup = new Label[4];

        for (int i = 0; i < labelSetup.length; i++) {
            labelSetup[i] = new Label();
            labelSetup[i].setText(labelSetupText[i]);
            labelSetup[i].setFont(Font.font("Verdana", 26));
            labelSetup[i].setTextFill(Color.rgb(0, 0, 0, 1.0));
            labelSetup[i].setTextAlignment(TextAlignment.LEFT);
            labelSetup[i].setLayoutX(gapLabel[i]);
            labelSetup[i].setLayoutY(gapTop);
            labelSetup[i].setWrapText(true);
            root.getChildren().add(labelSetup[i]);
        }

        for (int i = 0; i < choiceBoxSetup.length; i++) {
            choiceBoxSetup[i] = new ChoiceBox(FXCollections.observableArrayList(items[i]));
            choiceBoxSetup[i].setId(choiceBoxID[i]);
            choiceBoxSetup[i].setLayoutX(gapChoiceBox[i]);
            choiceBoxSetup[i].setLayoutY(gapTop);
            choiceBoxSetup[i].setPrefSize(sizes[0], sizes[1]);
            choiceBoxSetup[i].addEventHandler(ActionEvent.ACTION, new EventHandlerChoiceBoxSetup_ACTION());
            root.getChildren().add(choiceBoxSetup[i]);
        }
    }

    //----------更新按鈕初始化----------//
    private void initButtonRun(List<ButtonInfo> buttonInfo) {

        counts = utilDB.selectCountInfoOne(new CountInfo("Counts"));
        buttonRun = new Button[counts.getCounts()];
        initImageRun(buttonInfo); // 讀取檔案名稱
        FunctionInfo _functionInfo;

        for (int i = 0; i < counts.getCounts(); i++) {

            buttonInfoRun[i] = (ButtonInfo) buttonInfo.get(i); // 把值存回 buttonInfoRun

            buttonRun[i] = new Button();

            buttonRun[i].setTranslateX(buttonInfo.get(i).getX());
            buttonRun[i].setTranslateY(buttonInfo.get(i).getY());
            buttonRun[i].setPrefSize(buttonInfo.get(i).getWidth(), buttonInfo.get(i).getHeight()); // 設定最佳大小
            buttonRun[i].setId(buttonInfo.get(i).getButtonName());
            buttonRun[i].setRotate(buttonInfo.get(i).getAngle());
            buttonRun[i].setScaleX(buttonInfo.get(i).getZoomFactor());
            buttonRun[i].setScaleY(buttonInfo.get(i).getZoomFactor());
            buttonRun[i].setOpacity(buttonInfo.get(i).getOpacity()); // 透明度
            buttonRun[i].setGraphic(new ImageView(imageRun[i]));

            buttonRun[i].setContentDisplay(ContentDisplay.TOP);
            buttonRun[i].setAlignment(Pos.CENTER);

            _functionInfo = utilDB.selectFunctionInfoOne(buttonInfoRun[i]); // 找出等待人數

            if (_functionInfo.getPrimaryKey() > 1) {
                buttonRun[i].setGraphic(new ImageView(imageRun[_functionInfo.getPrimaryKey() - 1]));
            } else {
                buttonRun[i].setGraphic(new ImageView(imageRun[0]));
            } // 加強一下

            buttonRun[i].setText("等待人數：" + _functionInfo.getWaitting() + "人");
            buttonRun[i].setTextFill(Color.rgb(255, 0, 0, 0.8)); // 顏色(R,G,B,透明度)
            buttonRun[i].setFont(Font.font("Verdana", 20)); // (字型, 大小)

            buttonRun[i].setOnZoomStarted(new EventHandler_OnZoomStarted());
            buttonRun[i].setOnZoom(new EventHandler_OnZoom());
            buttonRun[i].setOnZoomFinished(new EventHandler_ZoomFinished());

            buttonRun[i].setOnRotationStarted(new EventHandler_OnRotationStarted());
            buttonRun[i].setOnRotate(new EventHandler_OnRotate());
            buttonRun[i].setOnRotationFinished(new EventHandler_OnRotationFinished());

            buttonRun[i].addEventHandler(MouseEvent.MOUSE_DRAGGED, new EventHandler_MOUSE_DRAGGED());
            buttonRun[i].addEventHandler(MouseEvent.MOUSE_PRESSED, new EventHandler_MOUSE_PRESSED());

            buttonRun[i].addEventHandler(ActionEvent.ACTION, new EventHandler_ACTION());

            root.getChildren().add(buttonRun[i]);

        }
    }

    // 放大縮小…
    public class EventHandler_OnZoomStarted implements EventHandler<ZoomEvent> {

        @Override
        public void handle(ZoomEvent e) {

            if (isDrag == true) { // 按鈕拖曳設定功能開啟時
                Button _button = (Button) e.getSource();

                zoomfactor = _button.getScaleX();
                _button.setEffect(new DropShadow());
                e.consume();
            }
        }
    }

    public class EventHandler_OnZoom implements EventHandler<ZoomEvent> {

        @Override
        public void handle(ZoomEvent e) {

            if (isDrag == true) { // 按鈕拖曳設定功能開啟時

                Button _button = (Button) e.getSource();
                int ID = ProcessFrame.JObjectWhichOne(e.getSource(), buttonRun);

                _button.setScaleX(e.getTotalZoomFactor() * zoomfactor);
                _button.setScaleY(e.getTotalZoomFactor() * zoomfactor);
                System.out.println("zoomfactor = " + zoomfactor);
                System.out.println("e.getTotalZoomFactor() = " + e.getTotalZoomFactor());

                buttonInfoRun[ID].setZoomFactor(_button.getScaleX());
                e.consume();
            }
        }
    }

    public class EventHandler_ZoomFinished implements EventHandler<ZoomEvent> {

        @Override
        public void handle(ZoomEvent e) {

            if (isDrag == true) { // 按鈕拖曳設定功能開啟時

                Button _button = (Button) e.getSource();

                _button.setEffect(null);
                e.consume();
            }
        }
    }

// 旋轉
    public class EventHandler_OnRotationStarted implements EventHandler<RotateEvent> {

        @Override
        public void handle(RotateEvent e) {

            if (isDrag == true) { // 按鈕拖曳設定功能開啟時

                Button _button = (Button) e.getSource();
                _button.setEffect(new DropShadow());
                e.consume();
            }
        }
    }

    public class EventHandler_OnRotate implements EventHandler<RotateEvent> {

        @Override
        public void handle(RotateEvent e) {

            if (isDrag == true) { // 按鈕拖曳設定功能開啟時

                int ID = ProcessFrame.JObjectWhichOne(e.getSource(), buttonRun);

                Button _button = (Button) e.getSource();
                System.out.println("ID = " + ID);
                _button.setRotate(_button.getRotate() + e.getAngle());

                buttonInfoRun[ID].setAngle(_button.getRotate() + e.getAngle());
                e.consume();
            }
        }
    }

    public class EventHandler_OnRotationFinished implements EventHandler<RotateEvent> {

        @Override
        public void handle(RotateEvent e) {

            if (isDrag == true) { // 按鈕拖曳設定功能開啟時

                Button _button = (Button) e.getSource();

                _button.setEffect(null);
                e.consume();
            }
        }
    }

    // 拖曳
    public class EventHandler_MOUSE_PRESSED implements EventHandler<MouseEvent> {

        @Override
        public void handle(MouseEvent e) {

            if (isDrag == true) { // 按鈕拖曳設定功能開啟時

                orgSceneX = e.getSceneX();
                orgSceneY = e.getSceneY();
                orgTranslateX = ((Button) (e.getSource())).getTranslateX();
                orgTranslateY = ((Button) (e.getSource())).getTranslateY();

                System.out.println("orgTranslateX = " + orgTranslateX);
                System.out.println("orgTranslateY = " + orgTranslateY);
            }
        }
    }

    public class EventHandler_MOUSE_DRAGGED implements EventHandler<MouseEvent> {

        @Override
        public void handle(MouseEvent e) {

            if (isDrag == true) { // 按鈕拖曳設定功能開啟時

                int ID = ProcessFrame.JObjectWhichOne(e.getSource(), buttonRun);

                double offsetX = e.getSceneX() - orgSceneX;
                double offsetY = e.getSceneY() - orgSceneY;
                double newTranslateX = orgTranslateX + offsetX;
                double newTranslateY = orgTranslateY + offsetY;

                ((Button) (e.getSource())).setTranslateX(newTranslateX);
                ((Button) (e.getSource())).setTranslateY(newTranslateY);
                System.out.println("newTranslateX = " + (int) newTranslateX);

                buttonInfoRun[ID].setX((int) newTranslateX);
                buttonInfoRun[ID].setY((int) newTranslateY);

                System.out.println("ID = " + ID);
            }
        }
    }

    // 按鍵動作
    public class EventHandler_ACTION implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent e) {

            FunctionInfo _functionInfo;
            TicketInfo ticketInfo;

            int ID = ProcessFrame.JObjectWhichOne(e.getSource(), buttonRun); // 看按到哪個按鈕…
            System.out.println("ID = " + buttonRun[ID].getId());
            nowID = ID;

            if (isConn) { // 資料庫可連線時
                if (isDrag == true) { // 按鈕拖曳設定功能開啟時
                    labelSetup[0].setText("按鍵" + (nowID + 1) + " → 寬：");
                } else {

                    _functionInfo = utilDB.selectFunctionInfoOne(buttonInfoRun[nowID]);
                    utilDB.printFunctionInfo(_functionInfo);

                    System.out.println("_functionInfo.getRangeStart() = " + _functionInfo.getRangeStart());
                    System.out.println("_functionInfo.getRangeEnd() = " + _functionInfo.getRangeEnd());
                    System.out.println("_functionInfo.getRunning() = " + _functionInfo.getRunning());

                    if (_functionInfo.getRunning() >= _functionInfo.getRangeEnd()) {
                        _functionInfo.setRunning(_functionInfo.getRangeStart());
                    } else {
                        _functionInfo.setRunning(_functionInfo.getRunning() + 1); // 號碼+1
                    }

                    _functionInfo.setWaitting(_functionInfo.getWaitting() + 1); // 等待人數+1

                    ticketInfo = new TicketInfo(_functionInfo.getRunning(), _functionInfo.getFunctionCode());

                    utilDB.updateFunctionInfo(_functionInfo);
                    System.out.println("-----------------");
                    utilDB.insertTicketInfo(ticketInfo);

                    buttonRun[nowID].setText("等待人數：" + _functionInfo.getWaitting() + "人");

                    nowTicketNumber = _functionInfo.getRunning();

                    ThreadprintTicket ThreadprintTicket = new ThreadprintTicket("Thread PrintTicket");
                    // printTicket = new PrintTicket();
                    // printTicket.printTicket(_functionInfo.getRunning());
                    System.out.println("_functionInfo.getRunning()= " + _functionInfo.getRunning());
                }
            }
        }
    }

    public class EventHandlerClose_ACTION implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent e) {
            int ID = ProcessFrame.JObjectWhichOne(e.getSource(), buttonClose); // 看按到哪個按鈕…
            System.out.println("ID = " + ID);

            password += ID;

            System.out.println("password = " + password);
            System.out.println("Password.length = " + password.length());

            switch (password) {

                case "0123": // password = 0123，就結束程式…
                    utilDB.closeSQL();
                    System.exit(0);
                    break;

                case "0321": // password = 0321，開閉功能按鍵移動…
                    isDrag = !isDrag;

                    if (isConn) { // 如果資料庫連線成功時
                        if (isDrag == true) { // 按鈕拖曳設定功能開啟時
                            initButtonSetup();
                            initChoiceBoxSetup();
                        } else {
                            buttonSetup_Remove();
                            choiceBoxSetup_Remove();
                        }
                    }

                    System.out.println("isDrag = " + isDrag);
                    break;

                default:
                    System.out.println("Hello!!!");
            }

            if (password.length() >= 4) { // sPassword只能有四個字
                System.out.println(password.substring(1, 4));
                password = password.substring(1, 4); // 把第一個字去除，只留下後三個字…
            }
        }
    }

    public class EventHandlerSetup_ACTION implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent e) {

            Button _buttonSetup = (Button) e.getSource();
            String buttonName = _buttonSetup.getId();
            ButtonRunSetupInfo nowInfo = new ButtonRunSetupInfo(nowID, nowWidths, nowHeights, nowFunctionCodes);

            switch (buttonName) { // 利用名字做分類

                case "Submit":
                    System.out.println("Submit");
                    utilDB.updateButtonInfo(nowInfo.getID(), nowInfo.getWidths(), nowInfo.getHeights(), nowInfo.getFunctionCodes());
                    break;

                case "Reset":
                    System.out.println("Reset");
                    buttonRun_Remove();
                    choiceBoxSetup_Remove();
                    initButtonRun();
                    initChoiceBoxSetup();
                    break;

                case "Save":
                    System.out.println("Save");
                    buttonInfoRun_Save();
                    break;

                case "Read":
                    System.out.println("Read");
                    buttonRun_Remove();
                    List<ButtonInfo> _list;
                    _list = utilDB.selectButtonInfo(new ButtonInfo());
                    initButtonRun(_list);
                    break;

                case "Count":
                    System.out.println("Count");
                    buttonRun_Remove();
                    buttonRun_Count(nowCounts); // 測試用
                    initButtonRun();
                    break;

                default:
                    break;
            }
        }
    }

    public class EventHandlerChoiceBoxSetup_ACTION implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent e) {

            ChoiceBox _choiceBoxSetup = (ChoiceBox) e.getSource();
            String choiceBoxName = _choiceBoxSetup.getId();
            int ID = choiceBoxSetup_WhichOne(choiceBoxName);
            System.out.println("ID = " + ID);

            switch (choiceBoxName) { // 利用名字做分類

                case "widths":
                    nowWidths = Integer.parseInt(items[ID][_choiceBoxSetup.getSelectionModel().getSelectedIndex()]);
                    System.out.println("nowWidths = " + nowWidths);
                    break;

                case "heights":
                    nowHeights = Integer.parseInt(items[ID][_choiceBoxSetup.getSelectionModel().getSelectedIndex()]);
                    System.out.println("nowHeights = " + nowHeights);
                    break;

                case "functions":
                    //nowFunctionCodes = items[ID][_choiceBoxSetup.getSelectionModel().getSelectedIndex()];
                    nowFunctionCodes = _functionSetup[_choiceBoxSetup.getSelectionModel().getSelectedIndex()];
                    System.out.println("nowFunctionCodes = " + nowFunctionCodes);
                    break;

                case "counts":
                    System.out.println("數值：" + items[ID][_choiceBoxSetup.getSelectionModel().getSelectedIndex()]);
                    nowCounts = Integer.parseInt(items[ID][_choiceBoxSetup.getSelectionModel().getSelectedIndex()]);
                    System.out.println("nowCounts = " + nowCounts);
                    break;

                default:
                    break;
            }
        }
    }

    public class ThreadprintTicket implements Runnable {

        String name;             //設定執行緒的名稱
        Thread t;

        ThreadprintTicket(String name) {
            this.name = name;
            t = new Thread(this, name);
            t.start();
        }

        @Override
        public void run() {
            printTicket = new PrintTicket();

            try {
                Thread.sleep(delayTime);
                printTicket.printTicket(nowTicketNumber);

            } catch (InterruptedException e) {
                System.out.println(e.toString());
            }
        }
    }

//----------小工具----------//
    private void buttonRun_Remove() {
        for (Button buttonRun1 : buttonRun) {
            root.getChildren().remove(buttonRun1);
        }
    }

    private void choiceBoxSetup_Remove() {
        for (ChoiceBox choiceBoxSetup1 : choiceBoxSetup) {
            root.getChildren().remove(choiceBoxSetup1);
        }
        for (Label labelSetup1 : labelSetup) {
            root.getChildren().remove(labelSetup1);
        }
    }

    private void buttonSetup_Remove() {
        for (Button buttonSetup1 : buttonSetup) {
            root.getChildren().remove(buttonSetup1);
        }
    }

    private void buttonRun_Count(int counts) {

        CountInfo countInfo = new CountInfo("Counts", counts);
        utilDB.updateCounts(countInfo);
    }

    private void buttonInfoRun_Save() {
        for (ButtonInfo buttonInfoRun1 : buttonInfoRun) {
            utilDB.updateButtonInfo(buttonInfoRun1);
        }
    }

    private int choiceBoxSetup_WhichOne(String choiceBoxID) {

        int ID = 0;

        for (int i = 0; i < choiceBoxSetup.length; i++) {
            if (choiceBoxSetup[i].getId().equals(choiceBoxID)) {
                ID = i;
            }
        }
        return ID;
    }

    private void initImageRun() {
        basePath = "Data/Image/BusinessTypes/";
        extension = ".png";
        imageRun = new Image[9];

        InputStream imagePath;

        for (int i = 0; i < imageRun.length; i++) {

            imagePath = this.getClass().getResourceAsStream(basePath + (i + 1) + extension);

            if (imagePath == null) {
                imagePath = this.getClass().getResourceAsStream("Data/Image/TicketInfo/No-Image.png"); // 如果檔案讀不到就用預設值
            }

            imageRun[i] = new Image(imagePath);
        }
    }

    private void initImageRun(List<ButtonInfo> buttonInfo) {

        imageRun = new Image[buttonInfo.size()];

        String imagePath;
        InputStream _imagePath;

        for (int i = 0; i < buttonInfo.size(); i++) {

            ButtonFunctionInfo buttonFunctionInfo = utilDB.selectButtonFunctionInfoOne(buttonInfo.get(i));

            imagePath = buttonFunctionInfo.getImagesURL();
            File files = new File("src/" + imagePath); // 測試檔案是否存在
            System.out.println("files.canRead() = " + files.exists());

            if (files.exists()) {
                imageRun[i] = new Image(imagePath);
            } else {
                _imagePath = this.getClass().getResourceAsStream("Data/Image/TicketInfo/No-Image.png"); // 如果檔案讀不到就用預設值
                imageRun[i] = new Image(_imagePath);
            }
        }
    }

    //----------main----------//
    public static void main(String[] args) {
        launch(args);
    }
}
