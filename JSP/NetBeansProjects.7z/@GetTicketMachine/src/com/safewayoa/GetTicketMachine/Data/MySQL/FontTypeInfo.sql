DROP TABLE IF EXISTS GetTicketMachine.FontTypeInfo; -- 刪除資料表

CREATE TABLE GetTicketMachine.FontTypeInfo(
    PrimaryKey INTEGER(1) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
    FontTypeCode INTEGER(1) DEFAULT 0, -- 字型代碼
    FontTypeName VARCHAR(3) DEFAULT '一般', -- 字型名稱
    TableName VARCHAR(32) DEFAULT 'GetTicketMachine.FontTypeInfo', -- 功能識別碼
    InsertStaff VARCHAR(4) DEFAULT '----', -- 修改人員
    InsertDate DATE DEFAULT '1970-01-01', -- 修改日期
    InsertTime TIME DEFAULT '00:00:00' -- 修改時間
);

INSERT INTO GetTicketMachine.FontTypeInfo (PrimaryKey, FontTypeCode, FontTypeName) VALUES (1, 0, '一般');
INSERT INTO GetTicketMachine.FontTypeInfo (PrimaryKey, FontTypeCode, FontTypeName) VALUES (2, 1, '粗體');
INSERT INTO GetTicketMachine.FontTypeInfo (PrimaryKey, FontTypeCode, FontTypeName) VALUES (3, 2, '斜體');
INSERT INTO GetTicketMachine.FontTypeInfo (PrimaryKey, FontTypeCode, FontTypeName) VALUES (4, 3, '粗斜體');
