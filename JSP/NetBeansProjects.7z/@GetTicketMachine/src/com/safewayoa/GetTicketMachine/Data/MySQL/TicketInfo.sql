DROP TABLE IF EXISTS GetTicketMachine.TicketInfo; -- 刪除資料表

CREATE TABLE GetTicketMachine.TicketInfo(
    PrimaryKey INTEGER(5) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
    Numer INTEGER(5) NOT NULL, -- 號碼牌印出號碼
    Status VARCHAR(4) NOT NULL DEFAULT '----', -- 號碼牌的狀態
    TableName VARCHAR(32) DEFAULT 'GetTicketMachine.TicketInfo', -- 功能識別碼
    FunctionCode VARCHAR(4) DEFAULT '----', -- 功能代碼(L001)
    InsertDate DATE DEFAULT '1970-01-01', -- 修改日期
    InsertTime TIME DEFAULT '00:00:00' -- 修改時間
);