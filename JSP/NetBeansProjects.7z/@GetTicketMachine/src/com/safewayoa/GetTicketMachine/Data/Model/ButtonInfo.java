package com.safewayoa.GetTicketMachine.Data.Model;

import java.sql.Date;
import java.sql.Time;

public class ButtonInfo {

    private int primaryKey; // Button唯一編號
    private int id; // Button唯一編號
    private int width; // 寬
    private int height; // 高
    private int x; // X坐標
    private int y; // Y坐標
    private double opacity; // 透明度：0~1
    private double angle; // 旋轉角度：0~360
    private double zoomFactor; // 放大倍數
    private String buttonName; // 按鍵名稱
    private String tableName; // 使用的資料表
    private String functionCode; // 使用功能代碼
    private String InsertStaff; // 修改人員
    private Date insertDate; // 新增日期
    private Time insertTime; // 新增時間

    public ButtonInfo() {
        this.opacity = 1.0;
        this.zoomFactor = 1.0;
        this.tableName = "GetTicketMachine.ButtonInfo";
    }

    public ButtonInfo(int x, int y, int width, int height, double opacity) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.opacity = opacity;
        this.zoomFactor = 1.0;
    }

    public ButtonInfo(int x, int y, int width, int height, double opacity, String buttonName) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.opacity = opacity;
        this.angle = 0;
        this.zoomFactor = 1.0;
        this.buttonName = buttonName;
        this.functionCode = "----";
        this.tableName = "GetTicketMachine.ButtonInfo";
    }

    public int getPrimaryKey() {
        return primaryKey;
    }

    public int getID() {
        return id;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public double getOpacity() {
        return opacity;
    }

    public double getAngle() {
        return angle;
    }

    public double getZoomFactor() {
        return zoomFactor;
    }

    public String getButtonName() {
        return buttonName;
    }

    public String getTableName() {
        return tableName;
    }

    public String getFunctionCode() {
        return functionCode;
    }

    public String getInsertStaff() {
        return InsertStaff;
    }

    public Date getInsertDate() {
        return insertDate;
    }

    public Time getInsertTime() {
        return insertTime;
    }

    public void setPrimaryKey(int primaryKey) {
        this.primaryKey = primaryKey;
    }

    public void setID(int id) {
        this.id = id;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void setOpacity(double opacity) {
        this.opacity = opacity;
    }

    public void setAngle(double angle) {
        this.angle = angle;
    }

    public void setZoomFactor(double zoomFactor) {
        this.zoomFactor = zoomFactor;
    }

    public void setButtonName(String buttonName) {
        this.buttonName = buttonName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public void setFunctionCode(String functionCode) {
        this.functionCode = functionCode;
    }

    public void setInsertStaff(String InsertStaff) {
        this.InsertStaff = InsertStaff;
    }

    public void setInsertDate(Date insertDate) {
        this.insertDate = insertDate;
    }

    public void setInsertTime(Time insertTime) {
        this.insertTime = insertTime;
    }
}
