DROP TABLE IF EXISTS GetTicketMachine.ViewFontInfo; -- 刪除資料表

CREATE TABLE GetTicketMachine.ViewFontInfo(
    PrimaryKey INTEGER(2) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
    X INTEGER(4) DEFAULT 0, -- X坐標
    Y INTEGER(4) DEFAULT 0, -- Y坐標
    Sizes INTEGER(2) DEFAULT 12, -- 字體大小
    TypeCode INTEGER(1) DEFAULT 0, -- 粗體、斜體(0~3)
    Texts VARCHAR(255) DEFAULT '----', -- 文字內容
    FontName VARCHAR(255) DEFAULT '----', -- 字體名稱(新細明體)
    ColorRGB VARCHAR(12) DEFAULT '0,0,0', -- 字體前景色
    BackgroundColorRGB VARCHAR(12) DEFAULT '255,255,255', -- 字體背景色
    TableName VARCHAR(32) DEFAULT 'GetTicketMachine.ViewFontInfo', -- 資料表名稱
    Property VARCHAR(10) DEFAULT '----', -- 文字特性
    ViewFontName VARCHAR(10) UNIQUE DEFAULT '----', -- 文字特性
    InsertStaff VARCHAR(4) DEFAULT '----', -- 修改人員
    InsertDate DATE DEFAULT '1970-01-01', -- 修改日期
    InsertTime TIME DEFAULT '00:00:00' -- 修改時間
);

INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName) VALUES (1, '0000', 'Number', 'ViewFont1');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName) VALUES (2, '1991-01-01 00:00:00', 'Time', 'ViewFont2');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName) VALUES (3, '--3--', '----', 'ViewFont3');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName) VALUES (4, '--4--', '----', 'ViewFont4');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName) VALUES (5, '--5--', '----', 'ViewFont5');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName) VALUES (6, '--6--', '----', 'ViewFont6');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName) VALUES (7, '--7--', '----', 'ViewFont7');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName) VALUES (8, '--8--', '----', 'ViewFont8');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName) VALUES (9, '--9--', '----', 'ViewFont9');
