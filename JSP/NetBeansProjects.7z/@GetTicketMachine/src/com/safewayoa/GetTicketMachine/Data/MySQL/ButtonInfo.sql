DROP TABLE IF EXISTS GetTicketMachine.ButtonInfo; -- 刪除資料表

CREATE TABLE GetTicketMachine.ButtonInfo(
    PrimaryKey INTEGER(3) AUTO_INCREMENT PRIMARY KEY NOT NULL, -- 主鍵值
    ID INTEGER(5) DEFAULT 0, -- Button編號
    Width INTEGER(4) DEFAULT 250, -- 寬
    Height INTEGER(4) DEFAULT 500, -- 高
    X INTEGER(4) DEFAULT 0, -- X坐標
    Y INTEGER(4) DEFAULT 0, -- Y坐標
    Opacity DOUBLE  DEFAULT 1.0,-- 透明度
    Angle DOUBLE  DEFAULT 0.0,-- 旋轉角度
    ZoomFactor DOUBLE   DEFAULT 1.0,-- 放大倍率
    ButtonName VARCHAR(32) UNIQUE DEFAULT '----', -- Button名稱
    TableName VARCHAR(32) DEFAULT 'GetTicketMachine.ButtonInfo', -- 功能識別碼
    FunctionCode VARCHAR(4) DEFAULT '----', -- 功能識別碼
    InsertStaff VARCHAR(4) DEFAULT '----', -- 修改人員
    InsertDate DATE DEFAULT '1970-01-01', -- 修改日期
    InsertTime TIME DEFAULT '00:00:00' -- 修改時間
);

INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, FunctionCode) VALUES (1, 0, 'ButtonRun1', 'A001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, FunctionCode) VALUES (2, 1, 'ButtonRun2', 'B001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, FunctionCode) VALUES (3, 2, 'ButtonRun3', 'C001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, FunctionCode) VALUES (4, 3, 'ButtonRun4', 'D001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, FunctionCode) VALUES (5, 4, 'ButtonRun5', 'E001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, FunctionCode) VALUES (6, 5, 'ButtonRun6', 'F001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, FunctionCode) VALUES (7, 6, 'ButtonRun7', 'G001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, FunctionCode) VALUES (8, 7, 'ButtonRun8', 'H001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, FunctionCode) VALUES (9, 8, 'ButtonRun9', 'I001');