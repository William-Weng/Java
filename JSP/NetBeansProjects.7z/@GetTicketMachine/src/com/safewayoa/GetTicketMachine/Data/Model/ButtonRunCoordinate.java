package com.safewayoa.GetTicketMachine.Data.Model;

public class ButtonRunCoordinate {

    private int x; // X坐標
    private int y; // X坐標
    private int whichOne; // 第幾個

    public ButtonRunCoordinate() {
    }

    public ButtonRunCoordinate(int whichOne, ButtonRunSize sizes) {
        this.x = sizes.getGap() * whichOne + sizes.getWidth() * (whichOne - 1);
        this.y = (sizes.getHeightAll() - sizes.getHeight()) / 2;
        // this.y_Axis = (int) (sizes.getHeightAll() * 0.1);
        this.whichOne = whichOne;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getWhichOne() {
        return whichOne;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void setWhichOne(int whichOne) {
        this.whichOne = whichOne;
    }
}
