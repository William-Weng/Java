DROP TABLE IF EXISTS GetTicketMachine.FontInfo; -- 刪除資料表

CREATE TABLE GetTicketMachine.FontInfo(
    PrimaryKey INTEGER(1) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
    FontName VARCHAR(56) DEFAULT 'Times New Roman', -- 字型名稱
    FontCode VARCHAR(4) DEFAULT 'E001', -- 字型代碼
    Property VARCHAR(10) DEFAULT '----', -- 圖形特性
    TableName VARCHAR(32) DEFAULT 'GetTicketMachine.FontInfo', -- 功能識別碼
    InsertStaff VARCHAR(4) DEFAULT '----', -- 修改人員
    InsertDate DATE DEFAULT '1970-01-01', -- 修改日期
    InsertTime TIME DEFAULT '00:00:00' -- 修改時間
);

INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (1, 'E001', 'Consolas');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (2, 'E002', 'Segoe Print');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (3, 'E003', 'Segoe Script');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (4, 'E004', 'Serif');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (5, 'E005', 'Times New Roman');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (6, 'C001', '細明體');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (7, 'C002', '新細明體');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (8, 'C003', '標楷體');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (9, 'C004', '微軟正黑體');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (10, 'C005', '文泉驛微米黑');
