DROP DATABASE IF EXISTS GetTicketMachine; -- 刪除資料庫

CREATE DATABASE GetTicketMachine;