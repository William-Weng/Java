package com.safewayoa.GetTicketMachine.Data.Model;

public class ButtonFunctionInfo {

    private int primaryKey;
    private String buttonName;
    private String functionCode;
    private String functionName;
    private String imagesURL;

    public int getPrimaryKey() {
        return primaryKey;
    }

    public String getButtonName() {
        return buttonName;
    }

    public String getFunctionCode() {
        return functionCode;
    }

    public String getFunctionName() {
        return functionName;
    }

    public String getImagesURL() {
        return imagesURL;
    }

    public void setPrimaryKey(int primaryKey) {
        this.primaryKey = primaryKey;
    }

    public void setButtonName(String buttonName) {
        this.buttonName = buttonName;
    }

    public void setFunctionCode(String functionCode) {
        this.functionCode = functionCode;
    }

    public void setFunctionName(String functionName) {
        this.functionName = functionName;
    }

    public void setImagesURL(String imagesURL) {
        this.imagesURL = imagesURL;
    }
}
