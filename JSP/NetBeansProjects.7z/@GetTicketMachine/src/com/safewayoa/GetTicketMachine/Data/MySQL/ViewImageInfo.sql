DROP TABLE IF EXISTS GetTicketMachine.ViewImageInfo; -- 刪除資料表

CREATE TABLE GetTicketMachine.ViewImageInfo(
    PrimaryKey INTEGER(2) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
    X INTEGER(4) DEFAULT 0, -- X坐標
    Y INTEGER(4) DEFAULT 0, -- Y坐標
    Paths VARCHAR(255) DEFAULT '----.gif',
    TableName VARCHAR(32) DEFAULT 'GetTicketMachine.ViewImageInfo', -- 資料表名稱
    Property VARCHAR(10) DEFAULT '----', -- 圖形特性
    ViewImageName VARCHAR(15) UNIQUE DEFAULT '----', -- 圖形特性
    InsertStaff VARCHAR(4) DEFAULT '----', -- 修改人員
    InsertDate DATE DEFAULT '1970-01-01', -- 修改日期
    InsertTime TIME DEFAULT '00:00:00' -- 修改時間
);

INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (1, 'Image/TicketInfo/1.png', 75, 295, 'Logo', 'ViewImage1');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (2, 'Image/TicketInfo/2.png', 75, 330, 'Advertise', 'ViewImage2');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (3, 'Image/TicketInfo/3.png', 75, 365, 'QR-Code', 'ViewImage3');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (4, 'Image/TicketInfo/4.png', 110, 295, '----', 'ViewImage4');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (5, 'Image/TicketInfo/5.png', 110, 330, '----', 'ViewImage5');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (6, 'Image/TicketInfo/6.png', 110, 365, '----', 'ViewImage6');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (7, 'Image/TicketInfo/7.png', 145, 295, '----', 'ViewImage7');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (8, 'Image/TicketInfo/8.png', 145, 330, '----', 'ViewImage8');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (9, 'Image/TicketInfo/9.png', 145, 365, '----', 'ViewImage9');
