package com.safewayoa.GetTicketMachine.Data.Model;

public class ButtonRunSetupInfo {

    private int id;
    private int widths;
    private int heights;
    private String functionCodes;

    public ButtonRunSetupInfo(int ID, int widths, int heights, String functionCodes) {
        if (ID < 0) {
            ID = 0;
        }
        if (widths < 100) {
            widths = 250;
        }
        if (heights < 100) {
            heights = 500;
        }
        if (functionCodes.isEmpty()) {
            functionCodes = "----";
        }

        this.widths = widths;
        this.heights = heights;
        this.id = ID;
        this.functionCodes = functionCodes;
    }

    public int getID() {
        return id;
    }

    public int getWidths() {
        return widths;
    }

    public int getHeights() {
        return heights;
    }

    public String getFunctionCodes() {
        return functionCodes;
    }

    public void setID(int id) {
        this.id = id;
    }

    public void setWidths(int widths) {
        this.widths = widths;
    }

    public void setHeights(int heights) {
        this.heights = heights;
    }

    public void setFunctionCodes(String functionCodes) {
        this.functionCodes = functionCodes;
    }
}
