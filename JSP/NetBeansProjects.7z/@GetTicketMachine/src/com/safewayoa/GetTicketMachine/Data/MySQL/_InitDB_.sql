DROP DATABASE IF EXISTS GetTicketMachine; -- 刪除資料庫

CREATE DATABASE GetTicketMachine;

DROP TABLE IF EXISTS GetTicketMachine.ButtonInfo; -- 刪除資料表

CREATE TABLE GetTicketMachine.ButtonInfo(
    PrimaryKey INTEGER(3) AUTO_INCREMENT PRIMARY KEY NOT NULL, -- 主鍵值
    ID INTEGER(5) DEFAULT 0, -- Button編號
    Width INTEGER(4) DEFAULT 250, -- 寬
    Height INTEGER(4) DEFAULT 500, -- 高
    X INTEGER(4) DEFAULT 0, -- X坐標
    Y INTEGER(4) DEFAULT 0, -- Y坐標
    Opacity DOUBLE  DEFAULT 1.0,-- 透明度
    Angle DOUBLE  DEFAULT 0.0,-- 旋轉角度
    ZoomFactor DOUBLE   DEFAULT 1.0,-- 放大倍率
    ButtonName VARCHAR(32) UNIQUE DEFAULT '----', -- Button名稱
    TableName VARCHAR(32) DEFAULT 'GetTicketMachine.ButtonInfo', -- 功能識別碼
    FunctionCode VARCHAR(4) DEFAULT '----', -- 功能識別碼
    InsertStaff VARCHAR(4) DEFAULT '----', -- 修改人員
    InsertDate DATE DEFAULT '1970-01-01', -- 修改日期
    InsertTime TIME DEFAULT '00:00:00' -- 修改時間
);

INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, FunctionCode) VALUES (1, 0, 'ButtonRun1', 'A001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, FunctionCode) VALUES (2, 1, 'ButtonRun2', 'B001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, FunctionCode) VALUES (3, 2, 'ButtonRun3', 'C001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, FunctionCode) VALUES (4, 3, 'ButtonRun4', 'D001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, FunctionCode) VALUES (5, 4, 'ButtonRun5', 'E001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, FunctionCode) VALUES (6, 5, 'ButtonRun6', 'F001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, FunctionCode) VALUES (7, 6, 'ButtonRun7', 'G001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, FunctionCode) VALUES (8, 7, 'ButtonRun8', 'H001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, FunctionCode) VALUES (9, 8, 'ButtonRun9', 'I001');

DROP TABLE IF EXISTS GetTicketMachine.CountInfo; -- 刪除資料表

CREATE TABLE GetTicketMachine.CountInfo(
    PrimaryKey INTEGER(1) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
    Counts INTEGER(2) DEFAULT 3, -- 按鍵的數量
    Property VARCHAR(10) DEFAULT '----', -- 圖形特性
    TableName VARCHAR(32) DEFAULT 'GetTicketMachine.CountInfo', -- 功能識別碼
    InsertStaff VARCHAR(4) DEFAULT '----', -- 修改人員
    InsertDate DATE DEFAULT '1970-01-01', -- 修改日期
    InsertTime TIME DEFAULT '00:00:00' -- 修改時間
);

INSERT INTO GetTicketMachine.CountInfo (PrimaryKey, Counts, Property) VALUES (1, 3, 'Counts');
INSERT INTO GetTicketMachine.CountInfo (PrimaryKey, Counts, Property) VALUES (2, 2, 'ViewFont');
INSERT INTO GetTicketMachine.CountInfo (PrimaryKey, Counts, Property) VALUES (3, 1, 'ViewImage');

DROP TABLE IF EXISTS GetTicketMachine.FontInfo; -- 刪除資料表

CREATE TABLE GetTicketMachine.FontInfo(
    PrimaryKey INTEGER(1) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
    FontName VARCHAR(56) DEFAULT 'Times New Roman', -- 字型名稱
    FontCode VARCHAR(4) DEFAULT 'E001', -- 字型代碼
    Property VARCHAR(10) DEFAULT '----', -- 圖形特性
    TableName VARCHAR(32) DEFAULT 'GetTicketMachine.FontInfo', -- 功能識別碼
    InsertStaff VARCHAR(4) DEFAULT '----', -- 修改人員
    InsertDate DATE DEFAULT '1970-01-01', -- 修改日期
    InsertTime TIME DEFAULT '00:00:00' -- 修改時間
);

INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (1, 'E001', 'Consolas');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (2, 'E002', 'Segoe Print');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (3, 'E003', 'Segoe Script');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (4, 'E004', 'Serif');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (5, 'E005', 'Times New Roman');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (6, 'C001', '細明體');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (7, 'C002', '新細明體');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (8, 'C003', '標楷體');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (9, 'C004', '微軟正黑體');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (10, 'C005', '文泉驛微米黑');

DROP TABLE IF EXISTS GetTicketMachine.FontTypeInfo; -- 刪除資料表

CREATE TABLE GetTicketMachine.FontTypeInfo(
    PrimaryKey INTEGER(1) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
    FontTypeCode INTEGER(1) DEFAULT 0, -- 字型代碼
    FontTypeName VARCHAR(3) DEFAULT '一般', -- 字型名稱
    TableName VARCHAR(32) DEFAULT 'GetTicketMachine.FontTypeInfo', -- 功能識別碼
    InsertStaff VARCHAR(4) DEFAULT '----', -- 修改人員
    InsertDate DATE DEFAULT '1970-01-01', -- 修改日期
    InsertTime TIME DEFAULT '00:00:00' -- 修改時間
);

INSERT INTO GetTicketMachine.FontTypeInfo (PrimaryKey, FontTypeCode, FontTypeName) VALUES (1, 0, '一般');
INSERT INTO GetTicketMachine.FontTypeInfo (PrimaryKey, FontTypeCode, FontTypeName) VALUES (2, 1, '粗體');
INSERT INTO GetTicketMachine.FontTypeInfo (PrimaryKey, FontTypeCode, FontTypeName) VALUES (3, 2, '斜體');
INSERT INTO GetTicketMachine.FontTypeInfo (PrimaryKey, FontTypeCode, FontTypeName) VALUES (4, 3, '粗斜體');

DROP TABLE IF EXISTS GetTicketMachine.FunctionInfo; -- 刪除資料表

CREATE TABLE GetTicketMachine.FunctionInfo(
    PrimaryKey INTEGER(1) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
    FunctionCode VARCHAR(4) UNIQUE DEFAULT '----', -- 功能代碼(L001)
    FunctionName VARCHAR(255) DEFAULT '----', -- 功能名稱(一般業務)
    RangeStart INTEGER(4) UNIQUE DEFAULT 0, -- 功能開始號碼
    RangeEnd INTEGER(4) UNIQUE DEFAULT 0, -- 功能結束號碼
    Running INTEGER(4) DEFAULT 0, -- 最後印出的號碼
    Waitting INTEGER(4) DEFAULT 0, -- 等待人數
    ImagesURL VARCHAR(255)  DEFAULT '1.png',
    InsertStaff VARCHAR(4) DEFAULT '----', -- 修改人員
    InsertDate DATE DEFAULT '1970-01-01', -- 修改日期
    InsertTime TIME DEFAULT '00:00:00' -- 修改時間
);

INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (1, 'A001', '業務類型1', 1, 700, 0, 'Image/BusinessTypes/1.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (2, 'B001', '業務類型2', 701, 800, 700, 'Image/BusinessTypes/2.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (3, 'C001', '業務類型3', 801, 999, 800, 'Image/BusinessTypes/3.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (4, 'D001', '業務類型4', 1000, 1100, 999, 'Image/BusinessTypes/4.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (5, 'E001', '業務類型5', 1101, 1200, 1100, 'Image/BusinessTypes/5.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (6, 'F001', '業務類型6', 1201, 1300, 1200, 'Image/BusinessTypes/6.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (7, 'G001', '業務類型7', 1301, 1400, 1300, 'Image/BusinessTypes/7.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (8, 'H001', '業務類型8', 1401, 1500, 1400, 'Image/BusinessTypes/8.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (9, 'I001', '業務類型9', 1501, 1600, 1500, 'Image/BusinessTypes/9.png');

DROP TABLE IF EXISTS GetTicketMachine.StatusInfo; -- 刪除資料表

CREATE TABLE GetTicketMachine.StatusInfo(
    PrimaryKey INTEGER(1) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
    StatusCode VARCHAR(10) NOT NULL, -- 按鍵的數量
    StatusName VARCHAR(32) NOT NULL, -- 功能識別碼
    InsertStaff VARCHAR(4) DEFAULT '----', -- 修改人員
    InsertDate DATE DEFAULT '1970-01-01', -- 修改日期
    InsertTime TIME DEFAULT '00:00:00' -- 修改時間
);

INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (1, 'OK', '處理完畢');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (2, 'Doing', '處理中');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (3, '----', '未處理');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (4, 'Transfer', '轉櫃');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (5, 'Others', '其它');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (6, '----', '----');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (7, '----', '----');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (8, '----', '----');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (9, '----', '----');

DROP TABLE IF EXISTS GetTicketMachine.TicketInfo; -- 刪除資料表

CREATE TABLE GetTicketMachine.TicketInfo(
    PrimaryKey INTEGER(5) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
    Numer INTEGER(5) NOT NULL, -- 號碼牌印出號碼
    Status VARCHAR(4) NOT NULL DEFAULT '----', -- 號碼牌的狀態
    TableName VARCHAR(32) DEFAULT 'GetTicketMachine.TicketInfo', -- 功能識別碼
    FunctionCode VARCHAR(4) DEFAULT '----', -- 功能代碼(L001)
    InsertDate DATE DEFAULT '1970-01-01', -- 修改日期
    InsertTime TIME DEFAULT '00:00:00' -- 修改時間
);

DROP TABLE IF EXISTS GetTicketMachine.ViewFontInfo; -- 刪除資料表

CREATE TABLE GetTicketMachine.ViewFontInfo(
    PrimaryKey INTEGER(2) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
    X INTEGER(4) DEFAULT 0, -- X坐標
    Y INTEGER(4) DEFAULT 0, -- Y坐標
    Sizes INTEGER(2) DEFAULT 12, -- 字體大小
    TypeCode INTEGER(1) DEFAULT 0, -- 粗體、斜體(0~3)
    Texts VARCHAR(255) DEFAULT '----', -- 文字內容
    FontName VARCHAR(255) DEFAULT '----', -- 字體名稱(新細明體)
    ColorRGB VARCHAR(12) DEFAULT '0,0,0', -- 字體前景色
    BackgroundColorRGB VARCHAR(12) DEFAULT '255,255,255', -- 字體背景色
    TableName VARCHAR(32) DEFAULT 'GetTicketMachine.ViewFontInfo', -- 資料表名稱
    Property VARCHAR(10) DEFAULT '----', -- 文字特性
    ViewFontName VARCHAR(10) UNIQUE DEFAULT '----', -- 文字特性
    InsertStaff VARCHAR(4) DEFAULT '----', -- 修改人員
    InsertDate DATE DEFAULT '1970-01-01', -- 修改日期
    InsertTime TIME DEFAULT '00:00:00' -- 修改時間
);

INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName) VALUES (1, '0000', 'Number', 'ViewFont1');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName) VALUES (2, '1991-01-01 00:00:00', 'Time', 'ViewFont2');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName) VALUES (3, '--3--', '----', 'ViewFont3');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName) VALUES (4, '--4--', '----', 'ViewFont4');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName) VALUES (5, '--5--', '----', 'ViewFont5');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName) VALUES (6, '--6--', '----', 'ViewFont6');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName) VALUES (7, '--7--', '----', 'ViewFont7');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName) VALUES (8, '--8--', '----', 'ViewFont8');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName) VALUES (9, '--9--', '----', 'ViewFont9');

DROP TABLE IF EXISTS GetTicketMachine.ViewImageInfo; -- 刪除資料表

CREATE TABLE GetTicketMachine.ViewImageInfo(
    PrimaryKey INTEGER(2) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
    X INTEGER(4) DEFAULT 0, -- X坐標
    Y INTEGER(4) DEFAULT 0, -- Y坐標
    Paths VARCHAR(255) DEFAULT '----.gif',
    TableName VARCHAR(32) DEFAULT 'GetTicketMachine.ViewImageInfo', -- 資料表名稱
    Property VARCHAR(10) DEFAULT '----', -- 圖形特性
    ViewImageName VARCHAR(15) UNIQUE DEFAULT '----', -- 圖形特性
    InsertStaff VARCHAR(4) DEFAULT '----', -- 修改人員
    InsertDate DATE DEFAULT '1970-01-01', -- 修改日期
    InsertTime TIME DEFAULT '00:00:00' -- 修改時間
);

INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, Property, ViewImageName) VALUES (1, 'Data/Image/TicketInfo/Logo.gif', 'Logo', 'ViewImage1');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, Property, ViewImageName) VALUES (2, 'Data/Image/TicketInfo/Advertise.png', 'Advertise', 'ViewImage2');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, Property, ViewImageName) VALUES (3, 'Data/Image/TicketInfo/QR-Code.gif', 'QR-Code', 'ViewImage3');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, Property, ViewImageName) VALUES (4, 'Data/Image/TicketInfo/No-Image.png', '----', 'ViewImage4');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, Property, ViewImageName) VALUES (5, 'Data/Image/TicketInfo/No-Image.png', '----', 'ViewImage5');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, Property, ViewImageName) VALUES (6, 'Data/Image/TicketInfo/No-Image.png', '----', 'ViewImage6');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, Property, ViewImageName) VALUES (7, 'Data/Image/TicketInfo/No-Image.png', '----', 'ViewImage7');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, Property, ViewImageName) VALUES (8, 'Data/Image/TicketInfo/No-Image.png', '----', 'ViewImage8');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, Property, ViewImageName) VALUES (9, 'Data/Image/TicketInfo/No-Image.png', '----', 'ViewImage9');
