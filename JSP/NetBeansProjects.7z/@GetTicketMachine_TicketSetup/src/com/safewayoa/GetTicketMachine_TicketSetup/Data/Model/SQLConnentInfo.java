// =====資料庫連接相關數據===== //
package com.safewayoa.GetTicketMachine_TicketSetup.Data.Model;

public class SQLConnentInfo {

//------------------------------變數宣告----------------------------------------//
    private String port = "localhost:3306"; // 資料庫連接的網路位置跟埠…
    private String databaseName = "GetTicketMachine"; // 連接的資料庫名稱…
    private String user = "william"; // 帳號…
    private String password = "19790609"; // 密碼…
    private String driver = "com.mysql.jdbc.Driver"; // 驅動程式…
    private String url = "jdbc:mysql://" + port + "/" + databaseName + "?useUnicode=true&characterEncoding=UTF8"; // 連接語法、編碼…

//---------------------------------取得變數方法----------------------------------//
    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getdatabaseName() {
        return databaseName;
    }

    public void setTableName(String databaseName) {
        this.databaseName = databaseName;
    }

    public String getUser() {
        return user;
    }

    public String setUser(String user) {
        return this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDriver() {
        return driver;
    }

    public void setDriver(String driver) {
        this.driver = driver;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
//-----------------------------------------------------結束----------------------------------------------------------//
}
