package com.safewayoa.GetTicketMachine_TicketSetup.Data.Model;

import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

public class FontTypeFX2 {

    private FontWeight fontWeight;
    private FontPosture fontPosture;

    public FontTypeFX2() {
        this.fontWeight = FontWeight.NORMAL;
        this.fontPosture = FontPosture.REGULAR;
    }

    public FontWeight getFontWeight() {
        return fontWeight;
    }

    public FontPosture getFontPosture() {
        return fontPosture;
    }

    public void setFontWeight(FontWeight fontWeight) {
        this.fontWeight = fontWeight;
    }

    public void setFontPosture(FontPosture fontPosture) {
        this.fontPosture = fontPosture;
    }
}
