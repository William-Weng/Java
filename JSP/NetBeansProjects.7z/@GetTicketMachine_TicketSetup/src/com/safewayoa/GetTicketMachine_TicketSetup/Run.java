package com.safewayoa.GetTicketMachine_TicketSetup;

import com.safewayoa.GetTicketMachine_TicketSetup.Data.Model.ColorRGB;
import com.safewayoa.GetTicketMachine_TicketSetup.Data.Model.FontInfo;
import com.safewayoa.GetTicketMachine_TicketSetup.Data.Model.FontTypeFX2;
import com.safewayoa.GetTicketMachine_TicketSetup.Data.Model.ViewFontInfo;
import com.safewayoa.GetTicketMachine_TicketSetup.Data.Model.ViewImageInfo;
import com.safewayoa.Tools.MySQL.DatabaseUtility;
import com.safewayoa.Tools.Utility.ProcessArray;
import com.safewayoa.Tools.Utility.ProcessFrame;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.print.PageFormat;
import java.awt.print.PrinterJob;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Run extends Application {

    boolean isConn;

    int widthAll, heightAll, widthLabel, heightLabel, gapChoiceBoxSetup, fontSizeLabelChoiceBoxSetup;
    int nowID_LabelInputText, nowX_LabelInputText, nowY_LabelInputText, nowType_LabelInputTextFont;
    int nowID_LabelInputImage, nowX_LabelInputImage, nowY_LabelInputImage;
    int initCountsLabelInputText, initCountsInputImage;
    int[] gapAll, sizes, colorRGB, sizeLabelPaperCoordinate, _fontType;

    double sceneX_LabelInputText, sceneY_LabelInputText, sceneX_LabelInputImage, sceneY_LabelInputImage; // 點在按鈕上的(x,y)
    double translateX_LabelInputText, translateY_LabelInputText, translateX_LabelInputImage, translateY_LabelInputImage; // 移動按鈕時的(x,y)

    String nowFont_LabelInputText, nowFont_LabelInputTextSize_LabelInputText, nowColorRGB_LabelInputText;
    String[] fontName, _fontName; // 功能選單：功能、代碼
    String[][] items;
    String[] fontSize;
    String[] fontType;
    String[] nameLabel;
    String[] nameChoiceBox;

    TextField textFieldInput;
    Button buttonSubmit;
    Label labelPaper, labelTextFieldInput, labelSliderFontRGB, labelBackground;
    Text textID, imageID;
    ChoiceBox[] choiceBoxSetup;
    Label[] labelChoiceBoxSetup, labelInputText, labelInputImage;
    Slider[] sliderFontRGB;
    Button[] buttonSetup;

    Dimension screenSize; // 取得螢幕解晰度大小
    Group root; // 畫面的根
    Scene scene; // 底層

    Image[] inputImage;
    FontWeight nowFont_LabelInputTextWeight;
    FontPosture nowFont_LabelInputTextPosture;

    DatabaseUtility utilDB;
    ViewFontInfo[] viewFontInfo;
    ViewImageInfo[] viewImageInfo;

    @Override
    public void start(Stage primaryStage) {

        root = new Group();
        scene = new Scene(root);

        initLabelBackground();
        initNumber();
        initPriterSize();
        initLabelPaper();
        initInputImage();

        initTextFieldInput();
        initTextID();
        initImageID();
        initButtonSetup();
        initChoiceBoxSetup();
        initSliderFontRGB();
        initLabelInputText();
        initLabelInputImage();

        primaryStage.setTitle("大鑫資訊");
        primaryStage.setWidth(widthAll);
        primaryStage.setHeight(heightAll);
        primaryStage.setScene(scene);
        primaryStage.setResizable(true);
        // primaryStage.setFullScreen(true);
        primaryStage.show();
    }

    private void initNumber() {

        scene.setFill(Color.rgb(50, 200, 50, 0.5));
        screenSize = Toolkit.getDefaultToolkit().getScreenSize(); // 取得當前螢幕解析度
        widthAll = screenSize.width * 2 / 3; // 1920 * 1080
        heightAll = screenSize.height * 2 / 3;

        gapChoiceBoxSetup = 60;
        fontSizeLabelChoiceBoxSetup = 20;

        initCountsLabelInputText = 9;
        initCountsInputImage = initCountsLabelInputText;

        nowID_LabelInputText = 0;
        nowFont_LabelInputText = "Serif";
        nowFont_LabelInputTextSize_LabelInputText = "12";
        nowType_LabelInputTextFont = java.awt.Font.PLAIN;
        nowColorRGB_LabelInputText = "0,0,0";

        gapAll = new int[]{50, 100, 50, 50}; // 上、左、下、右
        sizes = new int[]{200, 30};
        colorRGB = new int[]{0, 0, 0};
        sizeLabelPaperCoordinate = new int[]{350, 25};

        nowFont_LabelInputTextWeight = FontWeight.NORMAL;
        nowFont_LabelInputTextPosture = FontPosture.REGULAR;

        utilDB = new DatabaseUtility();
        isConn = utilDB.connSQL();
    }

    private void initLabelBackground() {

        labelBackground = new Label();

        Image image = new Image(this.getClass().getResourceAsStream("Data/Image/BusinessTypes/Background.jpg"));
        labelBackground.setPrefSize(widthAll, heightAll);
        labelBackground.setGraphic(new ImageView(image));

        root.getChildren().add(labelBackground);
    }

    private void initPriterSize() {
        PrinterJob printerJob = PrinterJob.getPrinterJob();
        PageFormat pageFormat = printerJob.defaultPage();

        widthLabel = (int) pageFormat.getWidth() + 1;
        heightLabel = (int) pageFormat.getHeight() + 1;

        System.out.println("heightLabel = " + heightLabel);
        System.out.println("widthLabel = " + widthLabel);
    }

    private void initButtonSetup() {

        if (isConn) {
            String[][] buttonSetupText = {{"Reset", "初始設定"}, {"Save", "設定完成"}, {"Read", "讀取設定"}};
            int[][] size = {{sizes[0], 36}, {sizes[0], 36}, {sizes[0], 36}};
            int[][] coordinate = {{gapAll[1], 500}, {gapAll[1], 540}, {gapAll[1], 580}}; // 將下方設定的按鈕置

            buttonSetup = new Button[3];

            for (int i = 0; i < buttonSetup.length; i++) {

                buttonSetup[i] = new Button();
                buttonSetup[i].setPrefSize(size[i][0], size[i][1]); // 設定最佳大小
                buttonSetup[i].setId(buttonSetupText[i][0]);
                buttonSetup[i].setContentDisplay(ContentDisplay.TOP);
                buttonSetup[i].setAlignment(Pos.CENTER);
                buttonSetup[i].setText(buttonSetupText[i][1]);
                buttonSetup[i].setTextFill(Color.rgb(255, 0, 0, 0.8)); // 顏色(R,G,B,透明度)
                buttonSetup[i].setOpacity(0.7); // 透明度
                buttonSetup[i].setFont(Font.font("Verdana", 20)); // (字型, 大小)
                buttonSetup[i].setTranslateX(coordinate[i][0]);
                buttonSetup[i].setTranslateY(coordinate[i][1]);
                buttonSetup[i].addEventHandler(ActionEvent.ACTION, new EventHandlerLabelInputText_ACTION());

                root.getChildren().add(buttonSetup[i]);
            }
        }
    }

    private void initTextID() {
        if (isConn) {
            textID = new Text("文字：1");
            textID.setLayoutX(gapAll[1]);
            textID.setLayoutY(gapAll[0] * 1.5);
            textID.setFont(Font.font(null, nowFont_LabelInputTextWeight, nowFont_LabelInputTextPosture, 20));

            root.getChildren().add(textID);
        }
    }

    private void initImageID() {
        if (isConn) {
            imageID = new Text("圖形：1");
            imageID.setLayoutX(gapAll[1] * 2);
            imageID.setLayoutY(gapAll[0] * 1.5);
            imageID.setFont(Font.font(null, nowFont_LabelInputTextWeight, nowFont_LabelInputTextPosture, 20));

            root.getChildren().add(imageID);
        }
    }

    private void initTextFieldInput() {
        if (isConn) {
            textFieldInput = new TextField("測試用…");
            textFieldInput.setLayoutX(gapAll[1]);
            textFieldInput.setLayoutY(gapAll[0] * 2);
            textFieldInput.setPrefSize(sizes[0], sizes[1]);
            textFieldInput.setOnKeyReleased(new EventHandlerTextFieldInput_OnKeyReleased());

            labelTextFieldInput = new Label("文字");
            labelTextFieldInput.setLayoutX(gapAll[1] - gapChoiceBoxSetup);
            labelTextFieldInput.setLayoutY(gapAll[0] * 2);
            labelTextFieldInput.setFont(Font.font("Serif", FontWeight.BOLD, FontPosture.ITALIC, fontSizeLabelChoiceBoxSetup));

            root.getChildren().add(textFieldInput);
            root.getChildren().add(labelTextFieldInput);
        }
    }

    private void initChoiceBoxSetup() {
        if (isConn) {
            //String[] fontName = {"Serif", "細明體", "Arial", "Consolas", "Comic Sans MS", "微軟正黑體", "文泉驛微米黑", "Digital Readout ExpUpright", "Lcd", "Segoe Print", "Segoe Script", "Times New Roman"};
            fontSize = new String[]{"2", "4", "6", "8", "10", "12", "14", "16", "18", "20", "22", "24", "26", "28", "30", "40", "50", "60"};
            fontType = new String[]{"一般", "粗體", "斜體", "粗斜體"};
            _fontType = new int[]{java.awt.Font.PLAIN, java.awt.Font.BOLD, java.awt.Font.ITALIC, java.awt.Font.BOLD + java.awt.Font.ITALIC};
            nameLabel = new String[]{"字型", "大小", "字體"};
            nameChoiceBox = new String[]{"font", "fontSize", "fontType"};

            List<String> _listName = new ArrayList();
            List<String> _listCode = new ArrayList();

            List<FontInfo> fontName_list;
            fontName_list = utilDB.selectFontInfo(new FontInfo());

            for (int i = 0; i < fontName_list.size(); i++) {
                _listName.add(fontName_list.get(i).getFontName());
                _listCode.add(fontName_list.get(i).getFontCode());
            } // 加強一下

            // String[] fontList = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
            fontName = (String[]) _listName.toArray(new String[0]); // 功能名稱
            _fontName = (String[]) _listCode.toArray(new String[0]); // 功能代碼

            items = new String[][]{fontName, fontSize, fontType};

            choiceBoxSetup = new ChoiceBox[3];
            labelChoiceBoxSetup = new Label[choiceBoxSetup.length];

            for (int i = 0; i < choiceBoxSetup.length; i++) {
                choiceBoxSetup[i] = new ChoiceBox(FXCollections.observableArrayList(items[i]));
                choiceBoxSetup[i].setId(nameChoiceBox[i]);
                choiceBoxSetup[i].setLayoutX(gapAll[1]);
                choiceBoxSetup[i].setLayoutY(gapAll[0] * (3 + i));
                choiceBoxSetup[i].setPrefSize(sizes[0], sizes[1]);

                choiceBoxSetup[i].addEventHandler(ActionEvent.ACTION, new EventHandlerChoiceBoxSetup_ACTION());

                labelChoiceBoxSetup[i] = new Label(nameLabel[i]);
                labelChoiceBoxSetup[i].setLayoutX(gapAll[1] - gapChoiceBoxSetup);
                labelChoiceBoxSetup[i].setLayoutY(gapAll[0] * (3 + i));
                labelChoiceBoxSetup[i].setPrefSize(sizes[0], sizes[1]);
                labelChoiceBoxSetup[i].setFont(Font.font("Serif", FontWeight.BOLD, FontPosture.ITALIC, fontSizeLabelChoiceBoxSetup));

                root.getChildren().add(choiceBoxSetup[i]);
                root.getChildren().add(labelChoiceBoxSetup[i]);
            }
        }
    }

    private void initLabelPaper() {

        String styleLabelPaper = "-fx-background-color:rgba(255, 255, 255, 0.7);";
        Image imageError = new Image(this.getClass().getResourceAsStream("Data/Image/BusinessTypes/Error.png"));

        labelPaper = new Label();
        labelPaper.setId("LabelPaper");
        labelPaper.setLayoutX(sizeLabelPaperCoordinate[0]);
        labelPaper.setLayoutY(sizeLabelPaperCoordinate[1]);
        labelPaper.setMinWidth(widthLabel);
        labelPaper.setMinHeight(heightLabel);
        labelPaper.setStyle(styleLabelPaper);

        if (!isConn) {
            labelPaper.setGraphic(new ImageView(imageError));
        }

        root.getChildren().add(labelPaper);
    }

    private void initSliderFontRGB() {
        if (isConn) {
            sliderFontRGB = new Slider[3];
            labelSliderFontRGB = new Label();
            String[] sliderID = {"Red", "Green", "Blue"};
            String[] sliderColorRRBA = {"-fx-color:rgba(255, 0, 0, 1.0);", "-fx-color:rgba(0, 255, 0, 1.0);", "-fx-color:rgba(0, 0, 255, 1.0);"};

            for (int i = 0; i < sliderFontRGB.length; i++) {

                sliderFontRGB[i] = new Slider();

                sliderFontRGB[i].setOrientation(Orientation.HORIZONTAL);
                sliderFontRGB[i].setId(sliderID[i]);
                sliderFontRGB[i].setMin(0.0);
                sliderFontRGB[i].setMax(255.0);
                sliderFontRGB[i].setValue(0);
                sliderFontRGB[i].setMajorTickUnit(50.0);
                sliderFontRGB[i].setMinorTickCount(5);
                sliderFontRGB[i].setBlockIncrement(10.0);
                sliderFontRGB[i].setPrefSize(200, 25);
                sliderFontRGB[i].setShowTickLabels(true);
                sliderFontRGB[i].setShowTickMarks(true);
                sliderFontRGB[i].setSnapToTicks(true);
                sliderFontRGB[i].setLayoutX(gapAll[1]);
                sliderFontRGB[i].setLayoutY(gapAll[0] * (7 + i));

                sliderFontRGB[i].setStyle(sliderColorRRBA[i]);
                root.getChildren().add(sliderFontRGB[i]);
            }

            sliderFontRGB[0].valueProperty().addListener(new EventHandlerSliderFontRed_ValueProperty());
            sliderFontRGB[1].valueProperty().addListener(new EventHandlerSliderFontGreen_ValueProperty());
            sliderFontRGB[2].valueProperty().addListener(new EventHandlerSliderFontBlue_ValueProperty());

            labelSliderFontRGB = new Label("顏色");
            labelSliderFontRGB.setLayoutX(gapAll[1] - gapChoiceBoxSetup);
            labelSliderFontRGB.setLayoutY(gapAll[0] * 8);
            labelSliderFontRGB.setPrefSize(sizes[0], sizes[1]);
            labelSliderFontRGB.setFont(Font.font("Serif", FontWeight.BOLD, FontPosture.ITALIC, fontSizeLabelChoiceBoxSetup));

            root.getChildren().add(labelSliderFontRGB);
        }
    }

    private void initLabelInputText() {

        if (isConn) {

            labelInputText = new Label[initCountsLabelInputText];
            viewFontInfo = new ViewFontInfo[labelInputText.length];

            FontTypeFX2 _fontTypeFX2;
            ColorRGB _colorRGB;
            List<String> list = new ProcessArray().ReadFileStream("com/safewayoa/GetTicketMachine_TicketSetup/Data/Text/Safewayoa_UTF8.ini");
            //System.out.println(this.getClass().getClassLoader().getResourceAsStream("com/safewayoa/GetTicketMachine_TicketSetup/Safewayoa.ini"));
            //List<String> list = new ProcessArray().ReadFile("D:/Safewayoa.ini");

            for (int i = 0; i < labelInputText.length; i++) {

                viewFontInfo[i] = this.setListToViewFontInfo(list.get(i)); // 取得Safewayoa.ini的值，去設定viewFontInfo初始值
                _colorRGB = this.getStringToRGB(viewFontInfo[i].getColorRGB());
                _fontTypeFX2 = this.getFontType(viewFontInfo[i].getTypeCode());

                labelInputText[i] = new Label(viewFontInfo[i].getTexts());
                labelInputText[i].setId("ViewFont" + (i + 1));
                labelInputText[i].setLayoutX(sizeLabelPaperCoordinate[0] + viewFontInfo[i].getX());
                labelInputText[i].setLayoutY(sizeLabelPaperCoordinate[1] + viewFontInfo[i].getY());
                labelInputText[i].setFont(Font.font(viewFontInfo[i].getFontName(), _fontTypeFX2.getFontWeight(), _fontTypeFX2.getFontPosture(), viewFontInfo[i].getSizes()));
                labelInputText[i].setTextFill(Color.rgb(_colorRGB.getGreen(), _colorRGB.getGreen(), _colorRGB.getBlue()));

                labelInputText[i].addEventHandler(MouseEvent.MOUSE_DRAGGED, new EventHandlerLabelInputText_MOUSE_DRAGGED());
                labelInputText[i].addEventHandler(MouseEvent.MOUSE_PRESSED, new EventHandlerLabelInputText_MOUSE_PRESSED());

                root.getChildren().add(labelInputText[i]);
            }
        }
    }

    private void initLabelInputImage() {

        if (isConn) {
            labelInputImage = new Label[initCountsInputImage];
            viewImageInfo = new ViewImageInfo[labelInputImage.length];

            List<String> list = new ProcessArray().ReadFileStream("com/safewayoa/GetTicketMachine_TicketSetup/Data/Text/SafewayoaImage_UTF8.ini");

            //String styleLabelPaper = "-fx-background-color:rgba(255, 255, 255, 0.7);";
            for (int i = 0; i < labelInputImage.length; i++) {

                viewImageInfo[i] = this.setListToViewImageInfo(list.get(i));

                labelInputImage[i] = new Label();
                labelInputImage[i].setId("ViewImage" + (i + 1));
                labelInputImage[i].setLayoutX(sizeLabelPaperCoordinate[0] + viewImageInfo[i].getX());
                labelInputImage[i].setLayoutY(sizeLabelPaperCoordinate[1] + viewImageInfo[i].getY());
                labelInputImage[i].setMinWidth(1);
                labelInputImage[i].setMinHeight(1);
                //labelInputImage[i].setStyle(styleLabelPaper);
                labelInputImage[i].setGraphic(new ImageView(inputImage[i]));

                labelInputImage[i].addEventHandler(MouseEvent.MOUSE_DRAGGED, new EventHandlerLabelInputImage_MOUSE_DRAGGED());
                labelInputImage[i].addEventHandler(MouseEvent.MOUSE_PRESSED, new EventHandlerLabelInputImage_MOUSE_PRESSED());

                root.getChildren().add(labelInputImage[i]);
            }
        }
    }

    private void initLabelInputText(List<ViewFontInfo> _viewFontInfo) {

        labelInputText = new Label[initCountsLabelInputText];
        FontTypeFX2 _fontTypeFX2;
        ColorRGB _colorRGB;
        //System.out.println(this.getClass().getClassLoader().getResourceAsStream("com/safewayoa/GetTicketMachine_TicketSetup/Safewayoa.ini"));

        for (int i = 0; i < labelInputText.length; i++) {

            viewFontInfo[i] = _viewFontInfo.get(i); // 把數據存在公用的viewFontInfo上

            _colorRGB = this.getStringToRGB(viewFontInfo[i].getColorRGB());
            _fontTypeFX2 = this.getFontType(viewFontInfo[i].getTypeCode());

            labelInputText[i] = new Label(viewFontInfo[i].getTexts());
            labelInputText[i].setId("LabelInputText" + (i + 1));
            labelInputText[i].setLayoutX(sizeLabelPaperCoordinate[0] + viewFontInfo[i].getX());
            labelInputText[i].setLayoutY(sizeLabelPaperCoordinate[1] + viewFontInfo[i].getY());
            // labelInputText[i].setFont(Font.font(viewFontInfo[i].getFontName(), nowFont_LabelInputTextWeight, nowFont_LabelInputTextPosture, viewFontInfo.get(i).getSizes()));
            labelInputText[i].setFont(Font.font(viewFontInfo[i].getFontName(), _fontTypeFX2.getFontWeight(), _fontTypeFX2.getFontPosture(), viewFontInfo[i].getSizes()));
            labelInputText[i].setTextFill(Color.rgb(_colorRGB.getRed(), _colorRGB.getGreen(), _colorRGB.getBlue()));

            labelInputText[i].addEventHandler(MouseEvent.MOUSE_PRESSED, new EventHandlerLabelInputText_MOUSE_PRESSED());
            labelInputText[i].addEventHandler(MouseEvent.MOUSE_DRAGGED, new EventHandlerLabelInputText_MOUSE_DRAGGED());

            root.getChildren().add(labelInputText[i]);
        }
    }

    private void initLabelInputImage(List<ViewImageInfo> _viewImageInfo) {

        if (isConn) {
            labelInputImage = new Label[initCountsInputImage];
            viewImageInfo = new ViewImageInfo[labelInputImage.length];

            initInputImage(_viewImageInfo); // 讀取檔案名稱

            //String styleLabelPaper = "-fx-background-color:rgba(255, 255, 255, 0.7);";
            for (int i = 0; i < labelInputImage.length; i++) {

                viewImageInfo[i] = _viewImageInfo.get(i);

                labelInputImage[i] = new Label();
                labelInputImage[i].setId("ViewImage" + (i + 1));
                labelInputImage[i].setLayoutX(sizeLabelPaperCoordinate[0] + viewImageInfo[i].getX());
                labelInputImage[i].setLayoutY(sizeLabelPaperCoordinate[1] + viewImageInfo[i].getY());
                labelInputImage[i].setMinWidth(1);
                labelInputImage[i].setMinHeight(1);
                //labelInputImage[i].setStyle(styleLabelPaper);
                labelInputImage[i].setGraphic(new ImageView(inputImage[i]));

                labelInputImage[i].addEventHandler(MouseEvent.MOUSE_DRAGGED, new EventHandlerLabelInputImage_MOUSE_DRAGGED());
                labelInputImage[i].addEventHandler(MouseEvent.MOUSE_PRESSED, new EventHandlerLabelInputImage_MOUSE_PRESSED());

                root.getChildren().add(labelInputImage[i]);
            }
        }
    }

    // 拖曳
    public class EventHandlerLabelInputText_MOUSE_PRESSED implements EventHandler<MouseEvent> {

        @Override
        public void handle(MouseEvent e) {

            Label _labelInputText = (Label) e.getSource();

            sceneX_LabelInputText = e.getSceneX();
            sceneY_LabelInputText = e.getSceneY();
            translateX_LabelInputText = _labelInputText.getTranslateX();
            translateY_LabelInputText = _labelInputText.getTranslateY();

//            System.out.println("orgTranslateX = " + orgTranslateX);
//            System.out.println("orgTranslateY = " + orgTranslateY);
//            System.out.println("orgSceneX = " + orgSceneX);
//            System.out.println("orgSceneY = " + orgSceneY);
            nowID_LabelInputText = ProcessFrame.JObjectWhichOne(e.getSource(), labelInputText);
            textID.setText("文字：" + (nowID_LabelInputText + 1));
            textFieldInput.setText(_labelInputText.getText());
            setSliderFontRGB(new ColorRGB());
            setChoiceBoxSetup();
        }
    }

    // 拖曳
    public class EventHandlerLabelInputImage_MOUSE_PRESSED implements EventHandler<MouseEvent> {

        @Override
        public void handle(MouseEvent e) {

            Label _labelInputText = (Label) e.getSource();

            sceneX_LabelInputImage = e.getSceneX();
            sceneY_LabelInputImage = e.getSceneY();
            translateX_LabelInputImage = _labelInputText.getTranslateX();
            translateY_LabelInputImage = _labelInputText.getTranslateY();

            nowID_LabelInputImage = ProcessFrame.JObjectWhichOne(e.getSource(), labelInputImage);
            imageID.setText("圖形：" + (nowID_LabelInputImage + 1));
        }
    }

    public class EventHandlerLabelInputText_MOUSE_DRAGGED implements EventHandler<MouseEvent> {

        @Override
        public void handle(MouseEvent e) {

            int nowX, nowY;
            double offsetX = e.getSceneX() - sceneX_LabelInputText;
            double offsetY = e.getSceneY() - sceneY_LabelInputText;
            double newTranslateX = translateX_LabelInputText + offsetX;
            double newTranslateY = translateY_LabelInputText + offsetY;

            Label _labelInputText = (Label) e.getSource();

            _labelInputText.setTranslateX(newTranslateX);
            _labelInputText.setTranslateY(newTranslateY);

            nowX = (int) (newTranslateX - sizeLabelPaperCoordinate[0] + _labelInputText.getLayoutX()); // 猜出來的
            nowY = (int) (newTranslateY - sizeLabelPaperCoordinate[1] + _labelInputText.getLayoutY());

            viewFontInfo[nowID_LabelInputText].setX(nowX);
            viewFontInfo[nowID_LabelInputText].setY(nowY);

//            System.out.println("offsetX = " + offsetX);
//            System.out.println("offsetY = " + offsetY);
//            System.out.println("newTranslateX = " + (newTranslateX - sizeLabelPaperCoordinate[0] + _labelInputText.getLayoutX()));
//            System.out.println("newTranslateY = " + (newTranslateY - sizeLabelPaperCoordinate[1] + _labelInputText.getLayoutY()));
            System.out.println("viewFontInfo[" + nowID_LabelInputText + "].getX() = " + viewFontInfo[nowID_LabelInputText].getX());
            System.out.println("viewFontInfo[" + nowID_LabelInputText + "].getY() = " + viewFontInfo[nowID_LabelInputText].getY());
        }
    }

    public class EventHandlerLabelInputImage_MOUSE_DRAGGED implements EventHandler<MouseEvent> {

        @Override
        public void handle(MouseEvent e) {

            int nowX, nowY;
            double offsetX = e.getSceneX() - sceneX_LabelInputImage;
            double offsetY = e.getSceneY() - sceneY_LabelInputImage;
            double newTranslateX = translateX_LabelInputImage + offsetX;
            double newTranslateY = translateY_LabelInputImage + offsetY;

            Label _labelInputImage = (Label) e.getSource();

            _labelInputImage.setTranslateX(newTranslateX);
            _labelInputImage.setTranslateY(newTranslateY);

            nowX = (int) (newTranslateX - sizeLabelPaperCoordinate[0] + _labelInputImage.getLayoutX());
            nowY = (int) (newTranslateY - sizeLabelPaperCoordinate[1] + _labelInputImage.getLayoutY());

            viewImageInfo[nowID_LabelInputImage].setX(nowX);
            viewImageInfo[nowID_LabelInputImage].setY(nowY);

//            System.out.println("offsetX = " + offsetX);
//            System.out.println("offsetY = " + offsetY);
            System.out.println("newTranslateX = " + (newTranslateX - sizeLabelPaperCoordinate[0] + _labelInputImage.getLayoutX()));
            System.out.println("newTranslateY = " + (newTranslateY - sizeLabelPaperCoordinate[1] + _labelInputImage.getLayoutY()));
        }
    }

    public class EventHandlerChoiceBoxSetup_ACTION implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent e) {
            //String[] nameChoiceBox = {"font", "fontSize", "fontType"};

            ChoiceBox _choiceBoxSetup = (ChoiceBox) e.getSource();
            String choiceBoxName = _choiceBoxSetup.getId();
            String _nowType_LabelInputTextFont;
            int ID = choiceBoxSetup_WhichOne(choiceBoxName);
            System.out.println("ID = " + ID);

            switch (choiceBoxName) { // 利用名字做分類

                case "font":
                    nowFont_LabelInputText = (items[ID][_choiceBoxSetup.getSelectionModel().getSelectedIndex()]);
                    labelInputText[nowID_LabelInputText].setFont(Font.font(nowFont_LabelInputText, nowFont_LabelInputTextWeight, nowFont_LabelInputTextPosture, Integer.parseInt(nowFont_LabelInputTextSize_LabelInputText)));
                    viewFontInfo[nowID_LabelInputText].setFontName(nowFont_LabelInputText);

                    System.out.println("font is " + nowFont_LabelInputText);
                    System.out.println("viewFontInfo[" + nowID_LabelInputText + "].getFontName() = " + viewFontInfo[nowID_LabelInputText].getFontName());

                    break;

                case "fontSize":
                    nowFont_LabelInputTextSize_LabelInputText = (items[ID][_choiceBoxSetup.getSelectionModel().getSelectedIndex()]);
                    labelInputText[nowID_LabelInputText].setFont(Font.font(nowFont_LabelInputText, nowFont_LabelInputTextWeight, nowFont_LabelInputTextPosture, Integer.parseInt(nowFont_LabelInputTextSize_LabelInputText)));
                    viewFontInfo[nowID_LabelInputText].setSizes(Integer.parseInt(nowFont_LabelInputTextSize_LabelInputText));

                    System.out.println("fontSize is " + nowFont_LabelInputTextSize_LabelInputText);
                    System.out.println("viewFontInfo[" + nowID_LabelInputText + "].getSizes() = " + viewFontInfo[nowID_LabelInputText].getSizes());

                    break;

                case "fontType":

                    _nowType_LabelInputTextFont = (items[ID][_choiceBoxSetup.getSelectionModel().getSelectedIndex()]);

                    switch (_nowType_LabelInputTextFont) {
                        case "一般":
                            nowFont_LabelInputTextWeight = FontWeight.NORMAL;
                            nowFont_LabelInputTextPosture = FontPosture.REGULAR;
                            nowType_LabelInputTextFont = java.awt.Font.PLAIN;
                            break;
                        case "粗體":
                            nowFont_LabelInputTextWeight = FontWeight.BOLD;
                            nowFont_LabelInputTextPosture = FontPosture.REGULAR;
                            nowType_LabelInputTextFont = java.awt.Font.BOLD;
                            System.out.println("nowType_LabelInputTextFont = " + nowType_LabelInputTextFont);

                            break;
                        case "斜體":
                            nowFont_LabelInputTextWeight = FontWeight.NORMAL;
                            nowFont_LabelInputTextPosture = FontPosture.ITALIC;
                            nowType_LabelInputTextFont = java.awt.Font.ITALIC;
                            System.out.println("nowType_LabelInputTextFont = " + nowType_LabelInputTextFont);
                            break;
                        case "粗斜體":
                            nowFont_LabelInputTextWeight = FontWeight.BOLD;
                            nowFont_LabelInputTextPosture = FontPosture.ITALIC;
                            nowType_LabelInputTextFont = java.awt.Font.BOLD + java.awt.Font.ITALIC;
                            System.out.println("nowType_LabelInputTextFont = " + nowType_LabelInputTextFont);

                            break;
                        default:
                            nowFont_LabelInputTextWeight = FontWeight.NORMAL;
                            nowFont_LabelInputTextPosture = FontPosture.REGULAR;
                            nowType_LabelInputTextFont = java.awt.Font.PLAIN;
                            System.out.println("nowType_LabelInputTextFont = " + nowType_LabelInputTextFont);
                            break;
                    }

                    viewFontInfo[nowID_LabelInputText].setTypeCode(nowType_LabelInputTextFont);

                    System.out.println("fontType is " + nowType_LabelInputTextFont);
                    System.out.println("viewFontInfo[" + nowID_LabelInputText + "].getTypeCode() = " + viewFontInfo[nowID_LabelInputText].getTypeCode());
                    break;
                default:
                    break;
            }

            labelInputText[nowID_LabelInputText].setFont(Font.font(nowFont_LabelInputText, nowFont_LabelInputTextWeight, nowFont_LabelInputTextPosture, Integer.parseInt(nowFont_LabelInputTextSize_LabelInputText)));
        }
    }

    public class EventHandlerSliderFontRed_ValueProperty implements ChangeListener<Number> {

        @Override
        public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {

            colorRGB[0] = (int) newValue.doubleValue();
            labelInputText[nowID_LabelInputText].setTextFill(Color.rgb(colorRGB[0], colorRGB[1], colorRGB[2]));

            nowColorRGB_LabelInputText = colorRGB[0] + "," + colorRGB[1] + "," + colorRGB[2];
            viewFontInfo[nowID_LabelInputText].setColorRGB(nowColorRGB_LabelInputText);

            System.out.println("nowColorRGB_LabelInputText = " + nowColorRGB_LabelInputText);
            System.out.println("viewFontInfo[" + nowID_LabelInputText + "].getColorRGB() = " + viewFontInfo[nowID_LabelInputText].getColorRGB());
        }
    }

    public class EventHandlerSliderFontGreen_ValueProperty implements ChangeListener<Number> {

        @Override
        public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {

            colorRGB[1] = (int) newValue.doubleValue();
            labelInputText[nowID_LabelInputText].setTextFill(Color.rgb(colorRGB[0], colorRGB[1], colorRGB[2]));

            nowColorRGB_LabelInputText = colorRGB[0] + "," + colorRGB[1] + "," + colorRGB[2];
            viewFontInfo[nowID_LabelInputText].setColorRGB(nowColorRGB_LabelInputText);

            System.out.println("nowColorRGB_LabelInputText = " + nowColorRGB_LabelInputText);
            System.out.println("viewFontInfo[" + nowID_LabelInputText + "].getColorRGB() = " + viewFontInfo[nowID_LabelInputText].getColorRGB());

        }
    }

    public class EventHandlerSliderFontBlue_ValueProperty implements ChangeListener<Number> {

        @Override
        public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {

            colorRGB[2] = (int) newValue.doubleValue();
            labelInputText[nowID_LabelInputText].setTextFill(Color.rgb(colorRGB[0], colorRGB[1], colorRGB[2]));

            nowColorRGB_LabelInputText = colorRGB[0] + "," + colorRGB[1] + "," + colorRGB[2];
            viewFontInfo[nowID_LabelInputText].setColorRGB(nowColorRGB_LabelInputText);

            System.out.println("nowColorRGB_LabelInputText = " + nowColorRGB_LabelInputText);
            System.out.println("viewFontInfo[" + nowID_LabelInputText + "].getColorRGB() = " + viewFontInfo[nowID_LabelInputText].getColorRGB());
        }
    }

    public class EventHandlerTextFieldInput_OnKeyReleased implements EventHandler<KeyEvent> {

        @Override
        public void handle(KeyEvent e) {
            if (e.getCode() == KeyCode.ENTER) {
                if (textFieldInput.getText().isEmpty()) {
                    textFieldInput.setPromptText("Please enter your word.");
                }
            }

            labelInputText[nowID_LabelInputText].setText(textFieldInput.getText());
            viewFontInfo[nowID_LabelInputText].setTexts(labelInputText[nowID_LabelInputText].getText());
            System.out.println("viewFontInfo[" + nowID_LabelInputText + "].getTexts() = " + viewFontInfo[nowID_LabelInputText].getTexts());

        }
    }

    public class EventHandlerLabelInputText_ACTION implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent e) {

            Button _buttonSetup = (Button) e.getSource();
            String buttonName = _buttonSetup.getId();

            switch (buttonName) { // 利用名字做分類

                case "Reset":
                    labelInputText_Remove();
                    initLabelInputText();

                    labelInputImage_Remove();
                    initLabelInputImage();

                    System.out.println("Reset");

                    break;

                case "Save":
                    viewFontInfo_Save();
                    viewImageInfo_Save();
                    System.out.println("Save");
                    break;

                case "Read":
                    labelInputText_Remove();
                    List<ViewFontInfo> _listFont = utilDB.selectViewFontInfo(new ViewFontInfo());
                    initLabelInputText(_listFont);

                    labelInputImage_Remove();
                    List<ViewImageInfo> _listImage = utilDB.selectViewImageInfo(new ViewImageInfo());
                    initLabelInputImage(_listImage);

                    System.out.println("Read");
                    break;

                default:
                    break;
            }
        }
    }

    // 小工具
    private int choiceBoxSetup_WhichOne(String choiceBoxID) {

        int ID = 0;

        for (int i = 0; i < choiceBoxSetup.length; i++) {
            if (choiceBoxSetup[i].getId().equals(choiceBoxID)) {
                ID = i;
            }
        }
        return ID;
    }

    private ViewFontInfo setListToViewFontInfo(String str) {

        String[] arrayStr = str.split("\t");
        ViewFontInfo _viewFontInfo = new ViewFontInfo();
        // 0、文字內容 1、X坐標 2、Y坐標 3、字體名稱 4、字體大小 5、字體樣式 6、字體前景色 7、字體背景色

        _viewFontInfo.setTexts(arrayStr[0]);
        _viewFontInfo.setX(Integer.parseInt(arrayStr[1]));
        _viewFontInfo.setY(Integer.parseInt(arrayStr[2]));
        _viewFontInfo.setFontName(arrayStr[3]);
        _viewFontInfo.setSizes(Integer.parseInt(arrayStr[4]));
        _viewFontInfo.setTypeCode(Integer.parseInt(arrayStr[5]));
        _viewFontInfo.setColorRGB(arrayStr[6]);
        _viewFontInfo.setBackgroundColorRGB(arrayStr[7]);
        _viewFontInfo.setViewFontName(arrayStr[8]);

        System.out.println("_viewFontInfo.getViewFontName() = " + _viewFontInfo.getViewFontName());

        return _viewFontInfo;
    }

    private ViewImageInfo setListToViewImageInfo(String str) {

        String[] arrayStr = str.split("\t");
        ViewImageInfo _viewImageInfo = new ViewImageInfo();
        // 0、圖形名稱 1、X坐標 2、Y坐標

        _viewImageInfo.setViewImageName(arrayStr[0]);
        _viewImageInfo.setX(Integer.parseInt(arrayStr[1]));
        _viewImageInfo.setY(Integer.parseInt(arrayStr[2]));

        return _viewImageInfo;
    }

    private FontTypeFX2 getFontType(int fontType) {

        FontTypeFX2 fontTypeFX2 = new FontTypeFX2();

        switch (fontType) {
            case java.awt.Font.PLAIN:
                fontTypeFX2.setFontWeight(FontWeight.NORMAL);
                fontTypeFX2.setFontPosture(FontPosture.REGULAR);
                break;
            case java.awt.Font.BOLD:
                fontTypeFX2.setFontWeight(FontWeight.BOLD);
                fontTypeFX2.setFontPosture(FontPosture.REGULAR);
                break;
            case java.awt.Font.ITALIC:
                fontTypeFX2.setFontWeight(FontWeight.NORMAL);
                fontTypeFX2.setFontPosture(FontPosture.ITALIC);
                break;
            case java.awt.Font.BOLD + java.awt.Font.ITALIC:
                fontTypeFX2.setFontWeight(FontWeight.BOLD);
                fontTypeFX2.setFontPosture(FontPosture.ITALIC);
                break;
            default:
                fontTypeFX2.setFontWeight(FontWeight.NORMAL);
                fontTypeFX2.setFontPosture(FontPosture.REGULAR);
                break;
        }

        return fontTypeFX2;
    }

    private ColorRGB getStringToRGB(String str) {
        String[] arrayStr = str.split(",");

        ColorRGB _colorRGB = new ColorRGB(Integer.parseInt(arrayStr[0]), Integer.parseInt(arrayStr[1]), Integer.parseInt(arrayStr[2]));

//        _colorRGB.setGreen(Integer.parseInt(arrayStr[0]));
//        _colorRGB.setRed(Integer.parseInt(arrayStr[1]));
//        _colorRGB.setBlue(Integer.parseInt(arrayStr[2]));
        return _colorRGB;
    }

    private void setSliderFontRGB(ColorRGB colorRGB) {

        String colorStr = viewFontInfo[nowID_LabelInputText].getColorRGB();
        colorRGB = this.getStringToRGB(colorStr);

        System.out.println("colorStr = " + colorStr);

        sliderFontRGB[0].setValue(colorRGB.getRed());
        sliderFontRGB[1].setValue(colorRGB.getGreen());
        sliderFontRGB[2].setValue(colorRGB.getBlue());

//        _colorRGB.setGreen(Integer.parseInt(arrayStr[0]));
//        _colorRGB.setRed(Integer.parseInt(arrayStr[1]));
//        _colorRGB.setBlue(Integer.parseInt(arrayStr[2]));
    }

    // 取得預設的選項
    private void setChoiceBoxSetup() {

        int intSizes = viewFontInfo[nowID_LabelInputText].getSizes();
        int intTypeCode = viewFontInfo[nowID_LabelInputText].getTypeCode();
        String strFontName = viewFontInfo[nowID_LabelInputText].getFontName();

        for (int i = 0; i < fontName.length; i++) {
            if (fontName[i].equals(strFontName)) {
                choiceBoxSetup[0].getSelectionModel().select(i);
            }
        }

        for (int i = 0; i < fontSize.length; i++) {
            if (Integer.parseInt(fontSize[i]) == intSizes) {
                choiceBoxSetup[1].getSelectionModel().select(i);
            }
        }

        for (int i = 0; i < _fontType.length; i++) {
            if (_fontType[i] == intTypeCode) {
                choiceBoxSetup[2].getSelectionModel().select(i);
            }
        }

//        _colorRGB.setGreen(Integer.parseInt(arrayStr[0]));
//        _colorRGB.setRed(Integer.parseInt(arrayStr[1]));
//        _colorRGB.setBlue(Integer.parseInt(arrayStr[2]));
    }

    private void labelInputText_Remove() {
        for (Label labelInputText1 : labelInputText) {
            root.getChildren().remove(labelInputText1);
        }
    }

    private void labelInputImage_Remove() {
        for (Label labelInputImage1 : labelInputImage) {
            root.getChildren().remove(labelInputImage1);
        }
    }

    private void viewFontInfo_Save() {
        for (ViewFontInfo viewFontInfo1 : viewFontInfo) {
            utilDB.updateViewFontInfo(viewFontInfo1);
        }
    }

    private void viewImageInfo_Save() {
        for (ViewImageInfo viewImageInfo1 : viewImageInfo) {
            utilDB.updateViewImageInfo(viewImageInfo1);
        }
    }

    private void initInputImage() {

        inputImage = new Image[initCountsInputImage];

        InputStream imagePath;

        for (int i = 0; i < inputImage.length; i++) {

            imagePath = this.getClass().getResourceAsStream("Data/Image/TicketInfo/" + (i + 1) + ".png");

            if (imagePath == null) {
                imagePath = this.getClass().getResourceAsStream("Data/Image/TicketInfo/No-Image.png"); // 如果檔案讀不到就用預設值
            }

            inputImage[i] = new Image(imagePath);
        }
    }

    private void initInputImage(List<ViewImageInfo> viewImageInfo) {

        inputImage = new Image[viewImageInfo.size()];

        String imagePath;
        InputStream _imagePath;

        for (int i = 0; i < viewImageInfo.size(); i++) {

            imagePath = viewImageInfo.get(i).getPaths();
            File files = new File("src/" + imagePath); // 測試檔案是否存在
            System.out.println("files.canRead() = " + files.exists());

            if (files.exists()) {
                inputImage[i] = new Image(imagePath);
            } else {
                _imagePath = this.getClass().getResourceAsStream("Data/Image/TicketInfo/No-Image.png"); // 如果檔案讀不到就用預設值
                inputImage[i] = new Image(_imagePath);
            }
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
