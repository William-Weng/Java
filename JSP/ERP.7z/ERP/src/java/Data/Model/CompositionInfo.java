package Data.Model;

public class CompositionInfo { // 物料模型

    private int id; // 流水編號
    private String nameCht; // 更新時間
    private String barCode; // 資料表名稱
    private String composition; // 功能備用
    private String note; // 功能備用
    private String insertTime; // 功能備用
    private String tableName; // 功能備用
    private String codes; // 功能備用

    public CompositionInfo() {
        this.tableName = "Composition";
    }

    public int getId() {
        return id;
    }

    public String getNameCht() {
        return nameCht;
    }

    public String getBarCode() {
        return barCode;
    }

    public String getComposition() {
        return composition;
    }

    public String getNote() {
        return note;
    }

    public String getInsertTime() {
        return insertTime;
    }

    public String getTableName() {
        return tableName;
    }

    public String getCodes() {
        return codes;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNameCht(String nameCht) {
        this.nameCht = nameCht;
    }

    public void setBarCode(String barCode) {
        this.barCode = barCode;
    }

    public void setComposition(String composition) {
        this.composition = composition;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public void setInsertTime(String insertTime) {
        this.insertTime = insertTime;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public void setCodes(String codes) {
        this.codes = codes;
    }
}
