// =====資料庫連接相關數據===== //
package Data.Model;

public class SQLConnentInfo {

//------------------------------變數宣告----------------------------------------//
    private final String port; // 資料庫連接的網路位置跟埠…
    private final String databaseName; // 連接的資料庫名稱…
    private final String user; // 帳號…
    private final String password; // 密碼…
    private final String driver; // 驅動程式…
    private final String url; // 連接語法、編碼…

//---------------------------------取得變數方法----------------------------------//
    public SQLConnentInfo() {
        this.port = "127.0.0.1:3306"; // 資料庫連接的網路位置跟埠…
        this.databaseName = "ERP"; // 連接的資料庫名稱…
        this.user = "william"; // 帳號…
        this.password = "19790609"; // 密碼…
        this.driver = "com.mysql.jdbc.Driver"; // 驅動程式…
        this.url = "jdbc:mysql://" + port + "/" + databaseName + "?useUnicode=true&characterEncoding=UTF8"; // 連接語法、編碼…
    }

//-----------------------------------------------------結束----------------------------------------------------------//
    public String getPort() {
        return port;
    }

    public String getDatabaseName() {
        return databaseName;
    }

    public String getUser() {
        return user;
    }

    public String getPassword() {
        return password;
    }

    public String getDriver() {
        return driver;
    }

    public String getUrl() {
        return url;
    }
}
