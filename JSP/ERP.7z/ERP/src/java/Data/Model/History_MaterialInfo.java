package Data.Model;

public class History_MaterialInfo { // 物料模型

    private int id; // 流水編號
    private int materialID; // 物料價格
    private double amount; // 庫存數量
    private double price; // 高庫存量
    private String insertTime; // 更新時間
    private String tableName; // 資料表名稱
    private String codes; // 功能備用

    public History_MaterialInfo() {
        this.tableName = "History_Material";
    }

    @Override
    public String toString() {
        String str = "ID = " + this.getId()
                + ", MaterialID = " + this.getMaterialID()
                + ", Amount = " + this.getAmount()
                + ", Price = " + this.getPrice()
                + ", InsertTime = " + this.getInsertTime()
                + ", TableName = " + this.getTableName()
                + ", Codes = " + this.getCodes()
                + "\n";
        return str;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMaterialID() {
        return materialID;
    }

    public void setMaterialID(int materialID) {
        this.materialID = materialID;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getInsertTime() {
        return insertTime;
    }

    public void setInsertTime(String insertTime) {
        this.insertTime = insertTime;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getCodes() {
        return codes;
    }

    public void setCodes(String codes) {
        this.codes = codes;
    }
}
