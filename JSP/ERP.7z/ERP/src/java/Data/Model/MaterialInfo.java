package Data.Model;

public class MaterialInfo { // 物料模型

    private int id; // 流水編號
    private double price; // 物料價格
    private double stock; // 庫存數量
    private double stockHigh; // 高庫存量
    private double stockLow; // 低庫存量
    private String nameCht; // 物料名稱
    private String barCode; // 條碼編號
    private String unit; // 物料單位
    private String priceUnit; // 價格單位
    private String manufacturer; // 進貨廠商
    private String origin; // 物料產地
    private String note; // 文件註記
    private String insertTime; // 更新時間
    private String tableName; // 資料表名稱
    private String codes; // 功能備用

    public MaterialInfo() {
        this.tableName = "Material";
    }

    @Override
    public String toString() {
        String str = "ID = " + this.id
                + ", Price = " + this.price
                + ", Stock = " + this.stock
                + ", StockHigh = " + this.stockHigh
                + ", StockLow = " + this.stockLow
                + ", NameCht = " + this.nameCht
                + ", BarCode = " + this.barCode
                + ", Unit = " + this.unit
                + ", PriceUnit = " + this.priceUnit
                + ", Manufacturer = " + this.manufacturer
                + ", Origin = " + this.origin
                + ", Note = " + this.note
                + ", InsertTime = " + this.insertTime
                + ", TableName = " + this.tableName
                + ", Codes = " + this.codes
                + "\n";
        return str;
    }

    public int getID() {
        return id;
    }

    public void setID(int id) {
        this.id = id;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getStock() {
        return stock;
    }

    public void setStock(double stock) {
        this.stock = stock;
    }

    public double getStockHigh() {
        return stockHigh;
    }

    public void setStockHigh(double stockHigh) {
        this.stockHigh = stockHigh;
    }

    public double getStockLow() {
        return stockLow;
    }

    public void setStockLow(double stockLow) {
        this.stockLow = stockLow;
    }

    public String getNameCht() {
        return nameCht;
    }

    public void setNameCht(String nameCht) {
        this.nameCht = nameCht;
    }

    public String getBarCode() {
        return barCode;
    }

    public void setBarCode(String barCode) {
        this.barCode = barCode;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getPriceUnit() {
        return priceUnit;
    }

    public void setPriceUnit(String priceUnit) {
        this.priceUnit = priceUnit;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getInsertTime() {
        return insertTime;
    }

    public void setInsertTime(String insertTime) {
        this.insertTime = insertTime;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getCodes() {
        return codes;
    }

    public void setCodes(String codes) {
        this.codes = codes;
    }
}
