package Data.Model;

public class ManufacturerInfo { // 物料模型

    private int id; // 流水編號
    private String nameCht; // 更新時間
    private String barCode; // 更新時間
    private String tel; // 更新時間
    private String moble; // 更新時間
    private String eMail; // 更新時間
    private String address; // 更新時間
    private String location; // 更新時間
    private String valueAddedTax; // 更新時間
    private String note; // 更新時間
    private String insertTime; // 更新時間
    private String tableName; // 更新時間
    private String codes; // 更新時間

    public ManufacturerInfo() {
        this.tableName = "Manufacturer";
    }

    public int getId() {
        return id;
    }

    public String getNameCht() {
        return nameCht;
    }

    public String getBarCode() {
        return barCode;
    }

    public String getTel() {
        return tel;
    }

    public String getMoble() {
        return moble;
    }

    public String geteMail() {
        return eMail;
    }

    public String getAddress() {
        return address;
    }

    public String getLocation() {
        return location;
    }

    public String getValueAddedTax() {
        return valueAddedTax;
    }

    public String getNote() {
        return note;
    }

    public String getInsertTime() {
        return insertTime;
    }

    public String getTableName() {
        return tableName;
    }

    public String getCodes() {
        return codes;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNameCht(String nameCht) {
        this.nameCht = nameCht;
    }

    public void setBarCode(String barCode) {
        this.barCode = barCode;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public void setMoble(String moble) {
        this.moble = moble;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setValueAddedTax(String valueAddedTax) {
        this.valueAddedTax = valueAddedTax;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public void setInsertTime(String insertTime) {
        this.insertTime = insertTime;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public void setCodes(String codes) {
        this.codes = codes;
    }
}
