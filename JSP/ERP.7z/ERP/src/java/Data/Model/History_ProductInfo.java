package Data.Model;

public class History_ProductInfo { // 物料模型

    private int id; // 流水編號
    private int productID; // 物料價格
    private double amount; // 庫存數量
    private double price; // 高庫存量
    private double income; // 銷售淨利
    private double incomePercent; // 銷售淨利%
    private String insertTime; // 更新時間
    private String tableName; // 資料表名稱
    private String codes; // 功能備用

    public History_ProductInfo() {
        this.tableName = "History_Product";
    }

    @Override
    public String toString() {
        String str = "ID = " + this.getId()
                + ", MaterialID = " + this.getProductID()
                + ", Amount = " + this.getAmount()
                + ", Price = " + this.getPrice()
                + ", Income = " + this.getIncome()
                + ", IncomePercent = " + this.getIncomePercent()
                + ", InsertTime = " + this.getInsertTime()
                + ", TableName = " + this.getTableName()
                + ", Codes = " + this.getCodes()
                + "\n";
        return str;
    }

    public int getId() {
        return id;
    }

    public int getProductID() {
        return productID;
    }

    public double getAmount() {
        return amount;
    }

    public double getPrice() {
        return price;
    }

    public double getIncome() {
        return income;
    }

    public double getIncomePercent() {
        return incomePercent;
    }

    public String getInsertTime() {
        return insertTime;
    }

    public String getTableName() {
        return tableName;
    }

    public String getCodes() {
        return codes;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setIncome(double income) {
        this.income = income;
    }

    public void setIncomePercent(double incomePercent) {
        this.incomePercent = incomePercent;
    }

    public void setInsertTime(String insertTime) {
        this.insertTime = insertTime;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public void setCodes(String codes) {
        this.codes = codes;
    }
}
