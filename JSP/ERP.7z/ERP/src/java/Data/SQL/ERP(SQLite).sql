CREATE TABLE "main"."Material" ( -- 物料
	"ID" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL , -- 流水編號
	"Name" TEXT , -- 物料名稱
	"BarCode" TEXT UNIQUE , -- 物料一維條碼編號
	"Stock" TEXT NOT NULL , -- 庫存量
	"Unit" TEXT NOT NULL , -- 物料單位
	"Price" TEXT NOT NULL , -- 物料價格
	"PriceUnit" TEXT NOT NULL , -- 物料價格單位
	"StockHigh" TEXT NOT NULL , -- 高庫存量
	"StockLow" TEXT NOT NULL , -- 低庫存量
	"Manufacturer" TEXT , -- 進貨廠商
	"Origin" TEXT , -- 物料產地
	"Note" TEXT , -- 註記	
	"InsertTime" TEXT DEFAULT CURRENT_TIMESTAMP , -- 建立/更新時間
	"TableName" TEXT DEFAULT Material , -- 資料表名稱
	"Code" TEXT DEFAULT Material -- 備用
	);

CREATE TABLE "main"."Product" ( -- 成品
	"ID" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL , -- 流水編號
	"Name" TEXT , -- 成品名稱
	"BarCode" TEXT UNIQUE , -- 成品一維條碼編號
	"ListNumber" INTEGER , -- 成品組成清單編號
	"Stock" TEXT NOT NULL , -- 庫存量
	"Unit" TEXT NOT NULL , -- 成品單位
	"Price" TEXT NOT NULL , -- 成品價格(市價 → NT.9999)
	"Price_Original" TEXT NOT NULL , -- 成品原價(原價：NT.9999，買您NT.6888)
	"Price_Sale" TEXT NOT NULL , -- 成品特賣價(售價：NT.9999 → NT.6888 → 跳樓大拍賣1折 NT.688)
	"PriceUnit" TEXT NOT NULL , -- 成品價格單位
	"StockHigh" TEXT NOT NULL , -- 高庫存量
	"StockLow" TEXT NOT NULL , -- 低庫存量
	"Manufacturer" TEXT , -- 進貨廠商
	"Origin" TEXT , -- 物料產地
	"Note" TEXT , -- 註記	
	"InsertTime" TEXT DEFAULT CURRENT_TIMESTAMP , -- 建立/更新時間	
	"TableName" TEXT DEFAULT Product , -- 資料表名稱
	"Code" TEXT DEFAULT Product -- 備用
	);

CREATE TABLE "main"."Composition" ( -- 成品組成表
	"ID" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL , -- 流水編號
	"Name" TEXT , -- 清單名稱
	"BarCode" TEXT UNIQUE , -- 成品一維條碼編號
	"Composition" TEXT NOT NULL , -- 成品組成細目(1:5|2:3) -- 流水編號:數量
	"Note" TEXT , -- 註記	
	"InsertTime" TEXT DEFAULT CURRENT_TIMESTAMP , -- 建立/更新時間	
	"TableName" TEXT DEFAULT Composition , -- 資料表名稱
	"Code" TEXT DEFAULT Composition -- 備用
	);

CREATE TABLE "History_Product" ( -- 成品售出歷史清單
	"ID" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL , -- 流水編號
	"ProductID" INTEGER NOT NULL , -- 成品流水編號
	"Amount" TEXT NOT NULL , -- 售出數量
	"Price" TEXT NOT NULL , -- 成品實際賣出價格
	"Income" TEXT NOT NULL , -- 成品銷售淨利
	"IncomePercent" TEXT NOT NULL , -- 成品銷售利率
	"InsertTime" TEXT DEFAULT CURRENT_TIMESTAMP , -- 建立/更新時間
	"TableName" TEXT DEFAULT History_Product , -- 資料表名稱		
	"Code" TEXT DEFAULT History_Product -- 備用
	)

CREATE TABLE "main"."History_Material" ( -- 物料使用歷史清單
	"ID" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL , -- 流水編號
	"MaterialID" INTEGER NOT NULL , -- 物料流水編號
	"Amount" TEXT NOT NULL , -- 使用數量
	"Price" TEXT NOT NULL , -- 物料進貨價格
	"InsertTime" TEXT DEFAULT CURRENT_TIMESTAMP , -- 建立/更新時間
	"TableName" TEXT DEFAULT History_Material , -- 資料表名稱		
	"Code" TEXT DEFAULT History_Material -- 備用
	);

CREATE TABLE "main"."Customer" ( -- 客戶
	"ID" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL , -- 流水編號
	"Name" TEXT NOT NULL , -- 名稱
	"BarCode" TEXT UNIQUE , -- 客戶編號
	"Tel" TEXT , -- 電話(0222184569)
	"Moble" TEXT , -- 手機(0936987654)
	"eMail" TEXT , -- 電子郵件(lili@gmail.com)
	"Address" TEXT , -- 地址(台北市文山區動物園B2)
	"Location" TEXT , -- 工作地點(新北市新店區民權路102號4樓)
	"Note" TEXT , -- 註記	
	"InsertTime" TEXT DEFAULT CURRENT_TIMESTAMP , -- 建立/更新時間
	"TableName" TEXT DEFAULT Customer , -- 資料表名稱		
	"Code" TEXT DEFAULT Customer -- 備用
	);

CREATE TABLE "main"."Manufacturer" ( -- 廠商
	"ID" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL , -- 流水編號
	"Name" TEXT NOT NULL , -- 名稱
	"BarCode" TEXT UNIQUE , -- 廠商編號
	"ValueAddedTax" TEXT, -- 統一編號
	"Tel" TEXT , -- 電話(0222184569)
	"Moble" TEXT , -- 手機(0936987654)
	"eMail" TEXT , -- 電子郵件(coco@msa.hinet.net)
	"Address" TEXT , -- 地址(台北市文山區動物園B2)
	"Location" TEXT , -- 工作地點(新北市新店區民權路102號4樓)
	"Note" TEXT , -- 註記	
	"InsertTime" TEXT DEFAULT CURRENT_TIMESTAMP , -- 建立/更新時間
	"TableName" TEXT DEFAULT Manufacturer , -- 資料表名稱		
	"Code" TEXT DEFAULT Manufacturer -- 備用
	);
	
INSERT INTO "Product" VALUES(1,'豆乾','2321',1,5001,'KG',100,80,50,'NT',1000,100,'德昌昌食品','地球上','有加「二甲基黃」','2014-12-18 14:03','Product','春季:999,699,60,20,5,20,0|夏季:900,600,60,20,5,20,0');
INSERT INTO "Product" VALUES(2,'豆乾','1418872887815',2,500,'KG',100,80,50,'NT',1000,100,'德昌昌食品','地球上','有加「二甲基黃」','2014-12-18 14:03','Product','春季:999,699,60,20,5,20,0|夏季:900,600,60,20,5,20,0');
INSERT INTO "Product" VALUES(3,'豆乾(紅)','1418872903831',3,500,'KG',100,80,50,'NT',1000,100,'德昌昌食品','地球上','有加「二甲基黃」','2014-12-18 14:03','Product','春季:999,699,60,20,5,20,0|夏季:900,600,60,20,5,20,0');
INSERT INTO "Product" VALUES(4,'豆乾(綠)','1418872908368',4,500,'KG',100,80,50,'NT',1000,100,'德昌昌食品','地球上','有加「二甲基黃」','2014-12-18 14:03','Product','春季:999,699,60,20,5,20,0|夏季:900,600,60,20,5,20,0');
INSERT INTO "Product" VALUES(5,'豆乾(可以吃的)','1418872914518',5,500,'KG',100,80,50,'NT',1000,100,'德昌昌食品','地球上','有加「二甲基黃」','2014-12-18 14:03','Product','春季:999,699,60,20,5,20,0|夏季:900,600,60,20,5,20,0');
INSERT INTO "Product" VALUES(6,'豆乾(不能吃的)','1418872920158',6,500,'KG',100,80,50,'NT',1000,100,'德昌昌食品','地球上','有加「二甲基黃」','2014-12-18 14:03','Product','春季:999,699,60,20,5,20,0|夏季:900,600,60,20,5,20,0');
INSERT INTO "Product" VALUES(7,'真．豆乾','1418872928574',7,500,'KG',100,80,50,'NT',1000,100,'德昌昌食品','地球上','有加「二甲基黃」','2014-12-18 14:03','Product','春季:999,699,60,20,5,20,0|夏季:900,600,60,20,5,20,0');
INSERT INTO "Product" VALUES(8,'假．豆乾','1418882558874',8,500,'KG',100,80,50,'NT',1000,100,'德昌昌食品','地球上','有加「二甲基黃」','2014-12-18 14:02','Product','春季:999,699,60,20,5,20,0|夏季:900,600,60,20,5,20,0');

INSERT INTO "Material" VALUES(2,'大豆','1418352524198',9999.666,'公斤',12,'NT',700,50.25,'大鑫','臺灣','----','2014-12-18 14:05','Material','Material');
INSERT INTO "Material" VALUES(3,'黃豆','1418366560758',500.236,'公斤',12,'NT',700,50.25,'大鑫','臺灣','----','2014-12-18 14:06','Material','Material');
INSERT INTO "Material" VALUES(4,'綠豆','1418352683869',500.236,'公斤',12,'NT',700,50,'大鑫','臺灣','----','2014-12-18 14:06','Material','Material');
INSERT INTO "Material" VALUES(6,'大紅豆','1418882802586',500.236,'公斤',12,'NT',700,50,'大鑫','臺灣','----','2014-12-18 14:06','Material','Material');
INSERT INTO "Material" VALUES(7,'大綠豆','1418882812945',500.236,'公斤',12,'NT',700,50,'大鑫','臺灣','----','2014-12-18 14:06','Material','Material');
INSERT INTO "Material" VALUES(8,'大黃豆','1418882825170',500.236,'公斤',12,'NT',700,50.25,'大鑫','臺灣','----','2014-12-18 14:07','Material','Material');

INSERT INTO "Manufacturer" VALUES(1,'大鑫資訊','1111','12121212','0222182240','0936670057','linuxice0609@gmail.com','台北市文山區動物園B2','台北市文山區動物園B2','----','2014-12-31 02:31:13','Manufacturer','Manufacturer');
INSERT INTO "Manufacturer" VALUES(2,'小鑫資訊','2222','21212121','0222182240','0936670057','bird@ms11.url.com.tw','新北市新店區民權路102號4樓','新北市新店區民權路102號4樓','----','2014-12-31 02:31:38','Manufacturer','Manufacturer');
INSERT INTO "Manufacturer" VALUES(3,'小小鑫資訊','3333','34343434','0222182240','0936670057','bird@ms11.url.com.tw','新北市新店區民權路102號4樓','台北市文山區動物園B2','----','2014-12-31 02:31:54','Manufacturer','Manufacturer');

INSERT INTO "Composition" VALUES(1,'滿漢全席','1321323113','4:500,3:200,','----','2014-12-18 14:05','Composition','Composition');
INSERT INTO "Composition" VALUES(2,'鴻門宴','1418606008079','4:500,3:700,4:600,2:555,3:222,','----','2014-12-18 14:06','Composition','Composition');
INSERT INTO "Composition" VALUES(4,'鴻門宴','1418606056478','4:500,','----','2014-12-18 14:07','Composition','Composition');
INSERT INTO "Composition" VALUES(5,'鴻門宴','1418692551547','2:500,3:1000,3:1000,','----','2014-12-18 14:08','Composition','Composition');
INSERT INTO "Composition" VALUES(6,'鴻門宴','1418692097539','4:500,3:700,','----','2014-12-18 14:09','Composition','Composition');
INSERT INTO "Composition" VALUES(7,'鴻門宴','1418692140211','3:500,3:700,3:600,2:50,3:100,','----','2014-12-18 14:00','Composition','Composition');
INSERT INTO "Composition" VALUES(8,'鴻門宴','1418692540635','4:500,3:700,2:600,','----','2014-12-18 14:10','Composition','Composition');

INSERT INTO "History_Product" VALUES(1,1,200,10.5,168.168,20.5,'2015-01-05 01:17:33','History_Product','History_Product');
INSERT INTO "History_Product" VALUES(2,2,200,10.25,150.168,23.52,'2015-01-05 01:18:23','History_Product','History_Product');
INSERT INTO "History_Product" VALUES(3,3,168,9.35,150.123,12.58,'2015-01-05 01:18:59','History_Product','History_Product');
INSERT INTO "History_Product" VALUES(4,4,1234,9.35,123.123,36.125,'2015-01-05 01:19:31','History_Product','History_Product');
INSERT INTO "History_Product" VALUES(5,1,500,10.36,200.25,20.75,'2015-01-05 01:20:32','History_Product','History_Product');
INSERT INTO "History_Product" VALUES(6,2,236,10.36,200.25,20.75,'2015-01-05 01:20:44','History_Product','History_Product');
INSERT INTO "History_Product" VALUES(7,5,785,10.36,500.25,36.25,'2015-01-05 01:21:03','History_Product','History_Product');
INSERT INTO "History_Product" VALUES(8,6,250,10.36,123.25,36.25,'2015-01-05 01:21:24','History_Product','History_Product');
INSERT INTO "History_Product" VALUES(9,7,200,10.36,125.26,23.32,'2015-01-05 01:21:49','History_Product','History_Product');
INSERT INTO "History_Product" VALUES(10,7,250,12.36,258.25,36.75,'2015-01-05 01:22:25','History_Product','History_Product');
INSERT INTO "History_Product" VALUES(11,2,250,12.36,258.25,36.75,'2015-01-05 01:22:33','History_Product','History_Product');
INSERT INTO "History_Product" VALUES(12,3,236,25.36,250.125,37.86,'2015-01-05 01:23:22','History_Product','History_Product');

INSERT INTO "History_Material" VALUES(1,1,100,50,'2014-12-18 07:59','History_Material','History_Material');
INSERT INTO "History_Material" VALUES(2,2,50,60,'2014-12-18 07:59','History_Material','History_Material');
INSERT INTO "History_Material" VALUES(3,3,40,100,'2014-12-18 08:00','History_Material','History_Material');
INSERT INTO "History_Material" VALUES(4,4,40,60,'2014-12-18 08:00','History_Material','History_Material');
INSERT INTO "History_Material" VALUES(5,5,30,60,'2014-12-18 08:00','History_Material','History_Material');
INSERT INTO "History_Material" VALUES(6,6,1000,30,'2014-12-18 08:00','History_Material','History_Material');
INSERT INTO "History_Material" VALUES(7,1,1000,30,'2014-12-18 08:00','History_Material','History_Material');
INSERT INTO "History_Material" VALUES(8,2,1000,30,'2014-12-18 08:00','History_Material','History_Material');
INSERT INTO "History_Material" VALUES(9,7,1000,30,'2014-12-18 08:00','History_Material','History_Material');
INSERT INTO "History_Material" VALUES(10,4,50,30,'2014-12-18 08:00','History_Material','History_Material');

INSERT INTO "Customer" VALUES(2,'小斌斌','1111','0222182240','0936670057','linuxice0609@gmail.com','新北市新店區民權路102號4樓','台北市文山區動物園B2','----','2014-12-31 02:27:19','Customer','Customer');
INSERT INTO "Customer" VALUES(3,'小小斌','2222','0222182240','0920670057','bird@ms11.url.com.tw','台北市文山區動物園B2','新北市新店區民權路102號4樓','----','2014-12-31 02:27:33','Customer','Customer');
INSERT INTO "Customer" VALUES(4,'小小小斌','3333','0222182240','0936670057','linuxice0609@gmail.com','新北市新店區民權路102號4樓','台北市文山區動物園B2','----','2014-12-31 02:27:48','Customer','Customer');

