DROP DATABASE IF EXISTS `ERP`;

DROP TABLE IF EXISTS `ERP`.`Material`;
DROP TABLE IF EXISTS `ERP`.`Product`;
DROP TABLE IF EXISTS `ERP`.`Composition`;
DROP TABLE IF EXISTS `ERP`.`History_Product`;
DROP TABLE IF EXISTS `ERP`.`History_Material`;
DROP TABLE IF EXISTS `ERP`.`Customer`;
DROP TABLE IF EXISTS `ERP`.`Manufacturer`;
DROP TABLE IF EXISTS `ERP`.`Functions`;
DROP TABLE IF EXISTS `ERP`.`OnSale`;

CREATE DATABASE `ERP`;

CREATE TABLE `ERP`.`Material` ( -- 物料
	`ID` INTEGER PRIMARY KEY AUTO_INCREMENT NOT NULL , -- 流水編號
	`Name` VARCHAR(255) NOT NULL DEFAULT '----', -- 物料名稱
	`BarCode` VARCHAR(20) UNIQUE NOT NULL DEFAULT '----' , -- 物料一維條碼編號
	`Stock` DECIMAL(12,4) NOT NULL DEFAULT 0 , -- 庫存量
	`Unit` VARCHAR(10) NOT NULL DEFAULT '入', -- 物料單位
	`Price` DECIMAL(12,4) NOT NULL DEFAULT 0 , -- 物料價格
	`PriceUnit` VARCHAR(10) NOT NULL DEFAULT 'NT', -- 物料價格單位
	`StockHigh` DECIMAL(12,4) NOT NULL DEFAULT 0 , -- 高庫存量
	`StockLow` DECIMAL(12,4) NOT NULL DEFAULT 0 , -- 低庫存量
	`Manufacturer` VARCHAR(255) DEFAULT 'Safewayoa' , -- 進貨廠商
	`Origin` VARCHAR(255) DEFAULT 'ROC' , -- 物料產地
	`Note` VARCHAR(255) DEFAULT '----' , -- 註記	
	`InsertTime` TIMESTAMP DEFAULT CURRENT_TIMESTAMP , -- 建立/更新時間
	`TableName` VARCHAR(255) DEFAULT 'Material' , -- 資料表名稱
	`Code` VARCHAR(255) DEFAULT 'Material' , -- 備用
	`GMail` VARCHAR(255) NOT NULL DEFAULT 'linuxice0609@gmail.com' -- 客戶eMail帳號
	);

CREATE TABLE `ERP`.`Composition` ( -- 成品組成表
	`ID` INTEGER PRIMARY KEY AUTO_INCREMENT NOT NULL , -- 流水編號
	`Name` VARCHAR(255) NOT NULL DEFAULT '----' , -- 清單名稱
	`BarCode` VARCHAR(255) UNIQUE NOT NULL DEFAULT '----' , -- 成品一維條碼編號
	`Composition` VARCHAR(255) NOT NULL , -- 成品組成細目(00001:5|00102:3) -- 流水編號:數量
	`Note` VARCHAR(255) DEFAULT '----' , -- 註記	
	`InsertTime` TIMESTAMP DEFAULT CURRENT_TIMESTAMP , -- 建立/更新時間	
	`TableName` VARCHAR(255) DEFAULT 'Composition' , -- 資料表名稱
	`Code` VARCHAR(255) DEFAULT 'Composition' , -- 備用
	`GMail` VARCHAR(255) NOT NULL DEFAULT 'linuxice0609@gmail.com' -- 客戶eMail帳號
	);

CREATE TABLE `ERP`.`Product` ( -- 成品
	`ID` INTEGER PRIMARY KEY AUTO_INCREMENT NOT NULL , -- 流水編號
	`Name` VARCHAR(255) NOT NULL DEFAULT '----' , -- 成品名稱
	`BarCode` VARCHAR(255) UNIQUE NOT NULL DEFAULT '----' , -- 成品一維條碼編號
	`ListNumber` INTEGER NOT NULL DEFAULT 0 , -- 成品組成清單編號
	`Stock` DECIMAL(12,4) NOT NULL DEFAULT 0 , -- 庫存量
	`Unit` VARCHAR(255) NOT NULL DEFAULT '----' , -- 成品單位
	`Price` DECIMAL(12,4) NOT NULL DEFAULT 0 , -- 成品價格(市價 → NT.9999)
	`Price_Original` DECIMAL(12,4) NOT NULL DEFAULT 0 , -- 成品原價(原價：NT.9999，買您NT.6888)
	`Price_Sale` DECIMAL(12,4) NOT NULL DEFAULT 0 , -- 成品特賣價(售價：NT.9999 → NT.6888 → 跳樓大拍賣1折 NT.688)
	`PriceUnit` VARCHAR(255) NOT NULL DEFAULT '----' , -- 成品價格單位
	`StockHigh` DECIMAL(12,4) NOT NULL DEFAULT 0 , -- 高庫存量
	`StockLow` DECIMAL(12,4) NOT NULL DEFAULT 0 , -- 低庫存量
	`Manufacturer` VARCHAR(255) DEFAULT '----' , -- 進貨廠商
	`Origin` VARCHAR(255) DEFAULT '----' , -- 物料產地
	`Note` VARCHAR(255) DEFAULT '----' , -- 註記	
	`InsertTime` TIMESTAMP DEFAULT CURRENT_TIMESTAMP , -- 建立/更新時間	
	`TableName` VARCHAR(255) DEFAULT 'Product' , -- 資料表名稱
	`Code` VARCHAR(255) DEFAULT 'Product' , -- 備用(春季:299,999,60,20,0,25,0|夏季:299,799,60,20,5,20,0|秋季:299,599,60,20,5,15,0|冬季:299,1199,60,0,0,210,0)
	`GMail` VARCHAR(255) NOT NULL DEFAULT 'linuxice0609@gmail.com' -- 客戶eMail帳號
	);

CREATE TABLE `ERP`.`Customer` ( -- 客戶
	`ID` INTEGER PRIMARY KEY AUTO_INCREMENT NOT NULL , -- 流水編號
	`Name` VARCHAR(255) NOT NULL DEFAULT '----' , -- 名稱
	`BarCode` VARCHAR(255) UNIQUE NOT NULL DEFAULT '----' , -- 客戶編號
	`Tel` VARCHAR(255) DEFAULT '----' , -- 電話(0222182240)
	`Moble` VARCHAR(255) DEFAULT '----' , -- 手機(0936670057)
	`eMail` VARCHAR(255) DEFAULT '----' , -- 電子郵件(linuxice0609@gmail.com)
	`Address` VARCHAR(255) DEFAULT '----' , -- 地址(新北市新店區民權路102號4樓)
	`Location` VARCHAR(255) DEFAULT '----' , -- 工作地點(台北市文山區動物園B2)
	`Note` VARCHAR(255) DEFAULT '----' , -- 註記	
	`InsertTime` TIMESTAMP DEFAULT CURRENT_TIMESTAMP , -- 建立/更新時間
	`TableName` VARCHAR(255) DEFAULT 'Customer' , -- 資料表名稱		
	`Code` VARCHAR(255) DEFAULT 'Customer' , -- 備用
	`GMail` VARCHAR(255) NOT NULL DEFAULT 'linuxice0609@gmail.com' -- 客戶eMail帳號
	);

CREATE TABLE `ERP`.`Manufacturer` ( -- 廠商
	`ID` INTEGER PRIMARY KEY AUTO_INCREMENT NOT NULL , -- 流水編號
	`Name` VARCHAR(255) NOT NULL DEFAULT '----' , -- 名稱
	`BarCode` VARCHAR(255) UNIQUE DEFAULT '----' , -- 廠商編號
	`ValueAddedTax` VARCHAR(255) DEFAULT '----' , -- 統一編號
	`Tel` VARCHAR(255) DEFAULT '----' , -- 電話(0222182240)
	`Moble` VARCHAR(255) DEFAULT '----' , -- 手機(0920670057)
	`eMail` VARCHAR(255) DEFAULT '----' , -- 電子郵件(bird@ms11.url.com.tw)
	`Address` VARCHAR(255) DEFAULT '----' , -- 地址(台北市文山區動物園B2)
	`Location` VARCHAR(255) DEFAULT '----' , -- 工作地點(新北市新店區民權路102號4樓)
	`Note` VARCHAR(255) DEFAULT '----' , -- 註記	
	`InsertTime` TIMESTAMP DEFAULT CURRENT_TIMESTAMP , -- 建立/更新時間
	`TableName` VARCHAR(255) DEFAULT 'Manufacturer' , -- 資料表名稱		
	`Code` VARCHAR(255) DEFAULT 'Manufacturer' , -- 備用
	`GMail` VARCHAR(255) NOT NULL DEFAULT 'linuxice0609@gmail.com' -- 客戶eMail帳號
	);

CREATE TABLE `ERP`.`History_Material` ( -- 物料使用歷史清單
	`ID` INTEGER PRIMARY KEY AUTO_INCREMENT NOT NULL , -- 流水編號
	`MaterialID` INTEGER NOT NULL DEFAULT 0 , -- 物料流水編號
	`Amount` DECIMAL(12,4) NOT NULL DEFAULT 0 , -- 使用數量
	`Price` DECIMAL(12,4) NOT NULL DEFAULT 0 , -- 物料進貨價格
	`InsertTime` TIMESTAMP DEFAULT CURRENT_TIMESTAMP , -- 建立/更新時間
	`TableName` VARCHAR(255) DEFAULT 'History_Material' , -- 資料表名稱	
	`Code` VARCHAR(255) DEFAULT 'History_Material' , -- 備用
	`GMail` VARCHAR(255) NOT NULL DEFAULT 'linuxice0609@gmail.com' -- 客戶eMail帳號
	);

CREATE TABLE `ERP`.`History_Product` ( -- 成品售出歷史清單
	`ID` INTEGER PRIMARY KEY AUTO_INCREMENT NOT NULL , -- 流水編號
	`ProductID` INTEGER NOT NULL DEFAULT 0 , -- 成品流水編號
	`Amount` DECIMAL(12,4) NOT NULL DEFAULT 0 , -- 售出數量
	`Price` DECIMAL(12,4) NOT NULL DEFAULT 0 , -- 成品售價(單筆)
	`Income` DECIMAL(12,4) NOT NULL , -- 成品銷售淨利
	`IncomePercent` DECIMAL(12,4) NOT NULL , -- 成品銷售利率	InsertTime TIMESTAMP DEFAULT CURRENT_TIMESTAMP , -- 建立/更新時間
	`InsertTime` TIMESTAMP DEFAULT CURRENT_TIMESTAMP , -- 建立/更新時間
	`TableName` VARCHAR(255) DEFAULT 'History_Product' , -- 資料表名稱		
	`Code` VARCHAR(255) DEFAULT 'History_Product' , -- 備用
	`GMail` VARCHAR(255) NOT NULL DEFAULT 'linuxice0609@gmail.com' -- 客戶eMail帳號
	);

INSERT INTO `ERP`.`Material` (`Name`, `BarCode`, `Stock`, `Unit`, `Price`, `StockHigh`, `StockLow`) VALUES ('砂糖', '81072500001', '50', '公斤', '1', '100', '10');
INSERT INTO `ERP`.`Material` (`Name`, `BarCode`, `Stock`, `Unit`, `Price`, `StockHigh`, `StockLow`) VALUES ('麵粉', '81072500002', '30', '公斤', '2', '100', '10');
INSERT INTO `ERP`.`Material` (`Name`, `BarCode`, `Stock`, `Unit`, `Price`, `StockHigh`, `StockLow`) VALUES ('奶油', '81072500003', '20', '公斤', '3', '100', '10');
INSERT INTO `ERP`.`Material` (`Name`, `BarCode`, `Stock`, `Unit`, `Price`, `StockHigh`, `StockLow`) VALUES ('沙拉', '81072500004', '10', '公斤', '4', '100', '10');
INSERT INTO `ERP`.`Material` (`Name`, `BarCode`, `Stock`, `Unit`, `Price`, `StockHigh`, `StockLow`) VALUES ('純水', '81072500005', '10', '公斤', '5', '100', '10');
INSERT INTO `ERP`.`Material` (`Name`, `BarCode`, `Stock`, `Unit`, `Price`, `StockHigh`, `StockLow`) VALUES ('巧克力', '81072500006', '40', '公斤', '1', '100', '10');
INSERT INTO `ERP`.`Material` (`Name`, `BarCode`, `Stock`, `Unit`, `Price`, `StockHigh`, `StockLow`) VALUES ('花生', '81072500007', '40', '公斤', '2', '100', '10');
INSERT INTO `ERP`.`Material` (`Name`, `BarCode`, `Stock`, `Unit`, `Price`, `StockHigh`, `StockLow`) VALUES ('草莓', '81072500008', '40', '公斤', '3', '100', '10');
INSERT INTO `ERP`.`Material` (`Name`, `BarCode`, `Stock`, `Unit`, `Price`, `StockHigh`, `StockLow`) VALUES ('紅豆', '81072500009', '40', '公斤', '4', '100', '10');
INSERT INTO `ERP`.`Material` (`Name`, `BarCode`, `Stock`, `Unit`, `Price`, `StockHigh`, `StockLow`) VALUES ('起司', '81072500010', '40', '公斤', '5', '100', '10');

INSERT INTO `ERP`.`Composition` (`Name`, `BarCode`, `Composition`) VALUES ('《配方》巧克力麵包', '150201', '1:0.25|2:0.15|3:0.05|4:0.05|5:0.25|6:0.01');
INSERT INTO `ERP`.`Composition` (`Name`, `BarCode`, `Composition`) VALUES ('《配方》花生麵包', '150202', '1:0.25|2:0.15|3:0.05|4:0.05|5:0.25|7:0.01');
INSERT INTO `ERP`.`Composition` (`Name`, `BarCode`, `Composition`) VALUES ('《配方》草莓麵包', '150203', '1:0.25|2:0.15|3:0.05|4:0.05|5:0.25|8:0.01');
INSERT INTO `ERP`.`Composition` (`Name`, `BarCode`, `Composition`) VALUES ('《配方》紅豆麵包', '150204', '1:0.25|2:0.15|3:0.05|4:0.05|5:0.25|9:0.01');
INSERT INTO `ERP`.`Composition` (`Name`, `BarCode`, `Composition`) VALUES ('《配方》起司麵包', '150205', '1:0.25|2:0.15|3:0.05|4:0.05|5:0.25|10:0.01');

INSERT INTO `ERP`.`Product` (`Name`, `BarCode`, `ListNumber`, `Stock`, `Unit`, `Price`, `Price_Original`, `Price_Sale`, `StockHigh`, `StockLow`, `Code`) VALUES ('巧克力麵包', '71072500001', '1', '100', '個', '100', '60', '50', '300', '50', '春季:299,999,60,20,0,25,0|夏季:299,799,60,20,5,20,0|秋季:299,599,60,20,5,15,0|冬季:299,1199,60,0,0,210,0');
INSERT INTO `ERP`.`Product` (`Name`, `BarCode`, `ListNumber`, `Stock`, `Unit`, `Price`, `Price_Original`, `Price_Sale`, `StockHigh`, `StockLow`, `Code`) VALUES ('花生麵包', '71072500002', '2', '600', '個', '95', '55', '55', '300', '50', '春季:299,999,60,20,0,25,0|夏季:299,799,60,20,5,20,0|秋季:299,599,60,20,5,15,0|冬季:299,1199,60,0,0,210,0');
INSERT INTO `ERP`.`Product` (`Name`, `BarCode`, `ListNumber`, `Stock`, `Unit`, `Price`, `Price_Original`, `Price_Sale`, `StockHigh`, `StockLow`, `Code`) VALUES ('草莓麵包', '71072500003', '3', '40', '個', '90', '50', '50', '300', '50', '春季:299,999,60,20,0,25,0|夏季:299,799,60,20,5,20,0|秋季:299,599,60,20,5,15,0|冬季:299,1199,60,0,0,210,0');
INSERT INTO `ERP`.`Product` (`Name`, `BarCode`, `ListNumber`, `Stock`, `Unit`, `Price`, `Price_Original`, `Price_Sale`, `StockHigh`, `StockLow`, `Code`) VALUES ('紅豆麵包', '71072500004', '4', '350', '個', '85', '45', '45', '300', '50', '春季:299,999,60,20,0,25,0|夏季:299,799,60,20,5,20,0|秋季:299,599,60,20,5,15,0|冬季:299,1199,60,0,0,210,0');
INSERT INTO `ERP`.`Product` (`Name`, `BarCode`, `ListNumber`, `Stock`, `Unit`, `Price`, `Price_Original`, `Price_Sale`, `StockHigh`, `StockLow`, `Code`) VALUES ('起司麵包', '71072500005', '5', '10', '個', '80', '40', '40', '300', '50', '春季:299,999,60,20,0,25,0|夏季:299,799,60,20,5,20,0|秋季:299,599,60,20,5,15,0|冬季:299,1199,60,0,0,210,0');

INSERT INTO `ERP`.`Customer` (`Name`, `BarCode`, `Tel`, `Moble`, `eMail`, `Address`, `Location`) VALUES ('小黃', '150201', '0222181191', '0936670051', 'linuxice0601@gmail.com', '新北市民權路101號4樓', '新北市民權路101號3樓');
INSERT INTO `ERP`.`Customer` (`Name`, `BarCode`, `Tel`, `Moble`, `eMail`, `Address`, `Location`) VALUES ('小紅', '150202', '0222181192', '0936670052', 'linuxice0602@gmail.com', '新北市民權路102號4樓', '新北市民權路102號3樓');
INSERT INTO `ERP`.`Customer` (`Name`, `BarCode`, `Tel`, `Moble`, `eMail`, `Address`, `Location`) VALUES ('小藍', '150203', '0222181193', '0936670053', 'linuxice0603@gmail.com', '新北市民權路103號4樓', '新北市民權路103號3樓');
INSERT INTO `ERP`.`Customer` (`Name`, `BarCode`, `Tel`, `Moble`, `eMail`, `Address`, `Location`) VALUES ('小黑', '150204', '0222181194', '0936670054', 'linuxice0604@gmail.com', '新北市民權路104號4樓', '新北市民權路104號3樓');
INSERT INTO `ERP`.`Customer` (`Name`, `BarCode`, `Tel`, `Moble`, `eMail`, `Address`, `Location`) VALUES ('小紫', '150205', '0222181195', '0936670055', 'linuxice0605@gmail.com', '新北市民權路105號4樓', '新北市民權路105號3樓');

INSERT INTO `ERP`.`Manufacturer` (`Name`, `BarCode`, `ValueAddedTax`, `Tel`, `Moble`, `eMail`, `Address`, `Location`) VALUES ('大黃', '150101', '22181191', '0222181191', '0936670051', 'linuxice0601@gmail.com', '新北市民權路102號1樓', '新北市民權路102號5樓');
INSERT INTO `ERP`.`Manufacturer` (`Name`, `BarCode`, `ValueAddedTax`, `Tel`, `Moble`, `eMail`, `Address`, `Location`) VALUES ('大紅', '150102', '22181192', '0222181192', '0936670052', 'linuxice0602@gmail.com', '新北市民權路102號2樓', '新北市民權路102號4樓');
INSERT INTO `ERP`.`Manufacturer` (`Name`, `BarCode`, `ValueAddedTax`, `Tel`, `Moble`, `eMail`, `Address`, `Location`) VALUES ('大藍', '150103', '22181193', '0222181193', '0936670053', 'linuxice0603@gmail.com', '新北市民權路102號3樓', '新北市民權路102號3樓');
INSERT INTO `ERP`.`Manufacturer` (`Name`, `BarCode`, `ValueAddedTax`, `Tel`, `Moble`, `eMail`, `Address`, `Location`) VALUES ('大黑', '150104', '22181194', '0222181194', '0936670054', 'linuxice0604@gmail.com', '新北市民權路102號4樓', '新北市民權路102號2樓');
INSERT INTO `ERP`.`Manufacturer` (`Name`, `BarCode`, `ValueAddedTax`, `Tel`, `Moble`, `eMail`, `Address`, `Location`) VALUES ('大紫', '150105', '22181195', '0222181195', '0936670055', 'linuxice0605@gmail.com', '新北市民權路102號5樓', '新北市民權路102號1樓');

INSERT INTO `ERP`.`History_Material` (`MaterialID`, `Amount`, `Price`) VALUES ('1', '0.25', '1');
INSERT INTO `ERP`.`History_Material` (`MaterialID`, `Amount`, `Price`) VALUES ('2', '0.25', '2');
INSERT INTO `ERP`.`History_Material` (`MaterialID`, `Amount`, `Price`) VALUES ('3', '0.25', '3');
INSERT INTO `ERP`.`History_Material` (`MaterialID`, `Amount`, `Price`) VALUES ('4', '0.25', '4');
INSERT INTO `ERP`.`History_Material` (`MaterialID`, `Amount`, `Price`) VALUES ('5', '0.25', '5');

INSERT INTO `ERP`.`History_Product` (`ProductID`, `Amount`, `Price`, `Income`, `IncomePercent`) VALUES ('1', '20', '70', '20', '5.2');
INSERT INTO `ERP`.`History_Product` (`ProductID`, `Amount`, `Price`, `Income`, `IncomePercent`) VALUES ('2', '30', '65', '15', '25.25');
INSERT INTO `ERP`.`History_Product` (`ProductID`, `Amount`, `Price`, `Income`, `IncomePercent`) VALUES ('3', '40', '60', '10', '15.25');
INSERT INTO `ERP`.`History_Product` (`ProductID`, `Amount`, `Price`, `Income`, `IncomePercent`) VALUES ('4', '50', '55', '5', '2.25');
INSERT INTO `ERP`.`History_Product` (`ProductID`, `Amount`, `Price`, `Income`, `IncomePercent`) VALUES ('5', '10', '50', '1', '5.25');
