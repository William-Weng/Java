package Java.Servlet;

import Data.Model.History_MaterialInfo;
import Data.Model.History_ProductInfo;
import Tools.MySQL.DatabaseUtility;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/hello.insert"})

public class Insert extends HttpServlet {

    DatabaseUtility utilDB;
    String keyword;
    String name;
    String password;

    History_MaterialInfo history_MaterialInfo;
    History_ProductInfo history_ProductInfo;

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        keyword = request.getParameter("KEYWORD");
        name = request.getParameter("name");
        password = request.getParameter("password");

        if (name.equalsIgnoreCase("winni") && password.equalsIgnoreCase("810725")) {

            switch (keyword) {

                case "History_Material": {

                    history_MaterialInfo = new History_MaterialInfo();

                    String materialID = request.getParameter("MaterialID");
                    String amount = request.getParameter("Amount");
                    String price = request.getParameter("Price");
                    String insertTime = request.getParameter("InsertTime");

                    history_MaterialInfo.setMaterialID(Integer.parseInt(materialID));
                    history_MaterialInfo.setAmount(Double.parseDouble(amount));
                    history_MaterialInfo.setPrice(Double.parseDouble(price));
                    history_MaterialInfo.setInsertTime(insertTime);

                    utilDB = new DatabaseUtility();
                    utilDB.insert(history_MaterialInfo);

                    response.setStatus(HttpServletResponse.SC_OK);
                    out.write("History_Material 新增成功… (｡◕∀◕｡)");
                    System.out.println("History_Material 新增成功… (｡◕∀◕｡)");

                    break;
                }
                case "History_Product": {

                    history_ProductInfo = new History_ProductInfo();

                    String productID = request.getParameter("ProductID");
                    String amount = request.getParameter("Amount");
                    String price = request.getParameter("Price");
                    String insertTime = request.getParameter("InsertTime");
                    String income = request.getParameter("Income");
                    String incomePercent = request.getParameter("IncomePercent");

                    history_ProductInfo.setProductID(Integer.parseInt(productID));
                    history_ProductInfo.setAmount(Double.parseDouble(amount));
                    history_ProductInfo.setPrice(Double.parseDouble(price));
                    history_ProductInfo.setInsertTime(insertTime);
                    history_ProductInfo.setIncome(Double.parseDouble(income));
                    history_ProductInfo.setIncomePercent(Double.parseDouble(incomePercent));

                    utilDB = new DatabaseUtility();
                    utilDB.insert(history_ProductInfo);

                    response.setStatus(HttpServletResponse.SC_OK);
                    out.write("History_Product 新增成功… (｡◕∀◕｡)");
                    System.out.println("History_Product 新增成功… (｡◕∀◕｡)");

                    break;
                }
            }

        } else {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            out.write("帳號、密碼錯誤… (╥﹏╥)");
            System.out.println("帳號、密碼錯誤… (╥﹏╥)");
        }
    }
}
