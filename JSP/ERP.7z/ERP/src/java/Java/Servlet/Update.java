package Java.Servlet;

import Data.Model.MaterialInfo;
import Data.Model.ProductInfo;
import Tools.MySQL.DatabaseUtility;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/hello.update"})

public class Update extends HttpServlet {

    DatabaseUtility utilDB;
    String keyword;
    String name;
    String password;

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        keyword = request.getParameter("KEYWORD");
        name = request.getParameter("name");
        password = request.getParameter("password");

        if (name.equalsIgnoreCase("winni") && password.equalsIgnoreCase("810725")) {

            switch (keyword) {

                case "Material": {

                    String ID = request.getParameter("ID");
                    String stock = request.getParameter("Stock");

                    utilDB = new DatabaseUtility();
                    utilDB.update(new MaterialInfo(), Integer.parseInt(ID), Double.parseDouble(stock));

                    response.setStatus(HttpServletResponse.SC_OK);
                    out.write("更新成功… (｡◕∀◕｡)");
                    System.out.println("更新成功… (｡◕∀◕｡)");
                    break;
                }

                case "Product": {

                    String ID = request.getParameter("ID");
                    String stock = request.getParameter("Stock");
                    String price_Sale = request.getParameter("Price_Sale");

                    utilDB = new DatabaseUtility();
                    utilDB.update(new ProductInfo(), Integer.parseInt(ID), Double.parseDouble(stock), Double.parseDouble(price_Sale));

                    response.setStatus(HttpServletResponse.SC_OK);
                    out.write("更新成功… (｡◕∀◕｡)");
                    System.out.println("更新成功… (｡◕∀◕｡)");
                    break;
                }

                case "Product_Stock": {
                    String ID = request.getParameter("ID");
                    String stock = request.getParameter("Stock");

                    utilDB = new DatabaseUtility();
                    utilDB.update(new ProductInfo(), Integer.parseInt(ID), Double.parseDouble(stock));

                    response.setStatus(HttpServletResponse.SC_OK);
                    out.write("更新成功… (｡◕∀◕｡)");
                    System.out.println("更新成功… (｡◕∀◕｡)");
                    break;
                }

                case "Material_Stock": {

                    String ID = request.getParameter("ID");
                    String stock = request.getParameter("Stock");

                    String[] arrayID = ID.split(",");
                    String[] arrayStock = stock.split(",");

                    utilDB = new DatabaseUtility();

                    for (int i = 0; i < arrayID.length; i++) {

                        Thread Thread_Sleep = new Thread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    Thread.sleep(50);
                                } catch (InterruptedException e) {
                                    System.out.println("I'm interrupted!!");
                                    //e.printStackTrace(); 
                                }
                            }
                        });

                        Thread_Sleep.start();

                        utilDB.update(new MaterialInfo(), Integer.parseInt(arrayID[i]), Double.parseDouble(arrayStock[i]));
                    }

                    break;
                }

                default:
                    response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                    out.write("表格名稱錯誤… (╥﹏╥)" + keyword);
                    System.out.println("表格名稱錯誤… (╥﹏╥)" + keyword);
                    break;
            }

        } else {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            out.write("帳號、密碼錯誤… (╥﹏╥)");
            System.out.println("帳號、密碼錯誤… (╥﹏╥)");
        }
    }
}
