package Java.Servlet;

import Data.Model.CompositionInfo;
import Data.Model.CustomerInfo;
import Data.Model.History_MaterialInfo;
import Data.Model.History_ProductInfo;
import Data.Model.ManufacturerInfo;
import Data.Model.MaterialInfo;
import Data.Model.ProductInfo;
import Tools.MySQL.DatabaseUtility;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@WebServlet(urlPatterns = {"/hello.view"})

public class View extends HttpServlet implements Serializable {

    private List<MaterialInfo> _listMaterialInfo;
    private List<ProductInfo> _listProductInfo;
    private List<CompositionInfo> _listCompositionInfo;
    private List<CustomerInfo> _listCustomerInfo;
    private List<ManufacturerInfo> _listManufacturerInfo;
    private List<History_MaterialInfo> _listHistory_MaterialInfo;
    private List<History_ProductInfo> _listHistory_ProductInfo;

    String isOK = "@";
    String start = "{";
    String end = "}";
    String colon = ":";
    String comma = ",";

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String name = request.getParameter("name");
        String password = request.getParameter("password");

        if (name.equalsIgnoreCase("winni") && password.equalsIgnoreCase("810725")) {
            getJSON(response);
            response.setStatus(HttpServletResponse.SC_OK);
        } else {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            out.write("｡ﾟヽ(ﾟ´Д`)ﾉﾟ｡ 帳號、密碼錯誤…");
        }
    }

    public void getJSON(HttpServletResponse response) throws ServletException, IOException {

        //準備使用者資料
        DatabaseUtility utilDB = new DatabaseUtility();

        String materialName = "\"" + new MaterialInfo().getTableName() + "\"";
        String productName = "\"" + new ProductInfo().getTableName() + "\"";
        String compositionName = "\"" + new CompositionInfo().getTableName() + "\"";
        String customerName = "\"" + new CustomerInfo().getTableName() + "\"";
        String manufacturerName = "\"" + new ManufacturerInfo().getTableName() + "\"";
        String history_MaterialInfoName = "\"" + new History_MaterialInfo().getTableName() + "\"";
        String history_ProductInfoName = "\"" + new History_ProductInfo().getTableName() + "\"";

        try (PrintWriter out = response.getWriter()) {

            _listMaterialInfo = utilDB.select(new MaterialInfo());
            _listProductInfo = utilDB.select(new ProductInfo());
            _listCompositionInfo = utilDB.select(new CompositionInfo());
            _listCustomerInfo = utilDB.select(new CustomerInfo());
            _listManufacturerInfo = utilDB.select(new ManufacturerInfo());
            _listHistory_MaterialInfo = utilDB.select(new History_MaterialInfo());
            _listHistory_ProductInfo = utilDB.select(new History_ProductInfo());

            out.write(start);
            out.write(materialName + colon);

            //JSON陣列
            JSONArray array = new JSONArray();

            for (MaterialInfo bean : _listMaterialInfo) {
                //單個使用者JSON物件
                JSONObject obj = new JSONObject();

                try {
                    obj.put("ID", bean.getID());
                    obj.put("Price", bean.getPrice());
                    obj.put("Stock", bean.getStock());
                    obj.put("StockHigh", bean.getStockHigh());
                    obj.put("StockLow", bean.getStockLow());
                    obj.put("Name", bean.getNameCht());
                    obj.put("BarCode", bean.getBarCode());
                    obj.put("Unit", bean.getUnit());
                    obj.put("PriceUnit", bean.getPriceUnit());
                    obj.put("Manufacturer", bean.getManufacturer());
                    obj.put("Origin", bean.getOrigin());
                    obj.put("Note", bean.getNote());
                    obj.put("InsertTime", bean.getInsertTime().toString().substring(0, 16));
                    obj.put("TableName", bean.getTableName());
                    obj.put("Codes", bean.getCodes());
                } catch (JSONException e) {
                    System.out.println(e.getMessage());
                }
                array.put(obj);
            }

            out.write(array.toString() + comma);
            out.write(productName + colon);
            out.flush();

            array = new JSONArray();

            for (ProductInfo bean : _listProductInfo) {
                //單個使用者JSON物件
                JSONObject obj = new JSONObject();

                try {
                    obj.put("ID", bean.getID());
                    obj.put("ListNumber", bean.getListNumber());
                    obj.put("Price", bean.getPrice());
                    obj.put("Price_Original", bean.getPrice_Original());
                    obj.put("Price_Sale", bean.getPrice_Sale());
                    obj.put("Stock", bean.getStock());
                    obj.put("StockHigh", bean.getStockHigh());
                    obj.put("StockLow", bean.getStockLow());
                    obj.put("Name", bean.getNameCht());
                    obj.put("BarCode", bean.getBarCode());
                    obj.put("Unit", bean.getUnit());
                    obj.put("PriceUnit", bean.getPriceUnit());
                    obj.put("Manufacturer", bean.getManufacturer());
                    obj.put("Origin", bean.getOrigin());
                    obj.put("Note", bean.getNote());
                    obj.put("InsertTime", bean.getInsertTime().toString().substring(0, 16));
                    obj.put("TableName", bean.getTableName());
                    obj.put("Codes", bean.getCodes());
                } catch (JSONException e) {
                    System.out.println(e.getMessage());
                }
                array.put(obj);
            }

            out.write(array.toString() + comma);
            out.write(history_MaterialInfoName + colon);
            out.flush();

            array = new JSONArray();

            for (History_MaterialInfo bean : _listHistory_MaterialInfo) {
                //單個使用者JSON物件
                JSONObject obj = new JSONObject();

                try {
                    obj.put("Amount", bean.getAmount());
                    obj.put("Codes", bean.getCodes());
                    obj.put("ID", bean.getId());
                    obj.put("InsertTime", bean.getInsertTime().toString().substring(0, 16));
                    obj.put("MaterialID", bean.getMaterialID());
                    obj.put("Price", bean.getPrice());
                    obj.put("TableName", bean.getTableName());
                } catch (JSONException e) {
                    System.out.println(e.getMessage());
                }
                array.put(obj);
            }

            out.write(array.toString() + comma);
            out.write(history_ProductInfoName + colon);
            out.flush();

            array = new JSONArray();

            for (History_ProductInfo bean : _listHistory_ProductInfo) {
                //單個使用者JSON物件
                JSONObject obj = new JSONObject();

                try {
                    obj.put("Amount", bean.getAmount());
                    obj.put("Codes", bean.getCodes());
                    obj.put("ID", bean.getId());
                    obj.put("Income", bean.getIncome());
                    obj.put("IncomePercent", bean.getIncomePercent());
                    obj.put("InsertTime", bean.getInsertTime().toString().substring(0, 16));
                    obj.put("Price", bean.getPrice());
                    obj.put("ProductID", bean.getProductID());
                    obj.put("TableName", bean.getTableName());
                } catch (JSONException e) {
                    System.out.println(e.getMessage());
                }
                array.put(obj);
            }

            out.write(array.toString() + comma);
            out.write(compositionName + colon);
            out.flush();

            array = new JSONArray();

            for (CompositionInfo bean : _listCompositionInfo) {
                //單個使用者JSON物件
                JSONObject obj = new JSONObject();

                try {
                    obj.put("BarCode", bean.getBarCode());
                    obj.put("Codes", bean.getCodes());
                    obj.put("Composition", bean.getComposition());
                    obj.put("ID", bean.getId());
                    obj.put("InsertTime", bean.getInsertTime());
                    obj.put("Name", bean.getNameCht());
                    obj.put("Note", bean.getNote());
                    obj.put("TableName", bean.getTableName());
                } catch (JSONException e) {
                    System.out.println(e.getMessage());
                }
                array.put(obj);
            }

            out.write(array.toString() + comma);
            out.write(customerName + colon);
            out.flush();

            array = new JSONArray();

            for (CustomerInfo bean : _listCustomerInfo) {
                //單個使用者JSON物件
                JSONObject obj = new JSONObject();

                try {
                    obj.put("Address", bean.getAddress());
                    obj.put("BarCode", bean.getBarCode());
                    obj.put("Codes", bean.getCodes());
                    obj.put("ID", bean.getId());
                    obj.put("InsertTime", bean.getInsertTime().toString().substring(0, 16));
                    obj.put("Location", bean.getLocation());
                    obj.put("Moble", bean.getMoble());
                    obj.put("Name", bean.getNameCht());
                    obj.put("Note", bean.getNote());
                    obj.put("TableName", bean.getTableName());
                    obj.put("Tel", bean.getTel());
                    obj.put("eMail", bean.geteMail());
                } catch (JSONException e) {
                    System.out.println(e.getMessage());
                }
                array.put(obj);
            }

            out.write(array.toString() + comma);
            out.write(manufacturerName + colon);
            out.flush();

            array = new JSONArray();

            for (ManufacturerInfo bean : _listManufacturerInfo) {
                //單個使用者JSON物件
                JSONObject obj = new JSONObject();

                try {
                    obj.put("Address", bean.getAddress());
                    obj.put("BarCode", bean.getBarCode());
                    obj.put("Codes", bean.getCodes());
                    obj.put("ID", bean.getId());
                    obj.put("InsertTime", bean.getInsertTime().toString().substring(0, 16));
                    obj.put("Location", bean.getLocation());
                    obj.put("Moble", bean.getMoble());
                    obj.put("Name", bean.getNameCht());
                    obj.put("Note", bean.getNote());
                    obj.put("TableName", bean.getTableName());
                    obj.put("Tel", bean.getTel());
                    obj.put("ValueAddedTax", bean.getValueAddedTax());
                    obj.put("eMail", bean.geteMail());
                } catch (JSONException e) {
                    System.out.println(e.getMessage());
                }
                array.put(obj);
            }

            out.write(array.toString() + end);
            out.write(isOK);
            out.flush();
            out.close();
        }
    }
}
