// ======資料庫處理====== //
package Tools.MySQL;

import Data.Model.CompositionInfo;
import Data.Model.CustomerInfo;
import Data.Model.History_MaterialInfo;
import Data.Model.History_ProductInfo;
import Data.Model.ManufacturerInfo;
import Data.Model.MaterialInfo;
import Data.Model.ProductInfo;
import Data.Model.SQLConnentInfo;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DatabaseUtility implements Serializable {

//----------------------------------------------------變數宣告-----------------------------------------------------//
    private Connection conn = null;
    private Statement stat = null;
    private ResultSet rs = null;
    private PreparedStatement pst = null;

//---------------------------------------------------初始化函數---------------------------------------------------//
    public DatabaseUtility() {

        SQLConnentInfo infoSQL = new SQLConnentInfo();
        String driver = infoSQL.getDriver();
        String url = infoSQL.getUrl();
        String user = infoSQL.getUser();
        String password = infoSQL.getPassword();

        try {

            Class.forName(driver);
            conn = DriverManager.getConnection(url, user, password);

            if (conn != null && !conn.isClosed()) {
                System.out.println("資料庫連線測試成功…");
            }

        } catch (ClassNotFoundException eNotFound) {
            System.out.println("DriverClassNotFound :" + eNotFound.toString());
            System.out.println("資料庫驅動程式出錯…");
        } catch (SQLException eSQL) {
            System.out.println("Exception :" + eSQL.toString());
            System.out.println("資料庫帳號、密碼錯誤…");
        }
    }

    //-------------------------------------------------資料庫連線關閉-----------------------------------------------//
    private void closeSQL() {
        try {

            if (rs != null) {
                rs.close();
                rs = null;
            }
            if (stat != null) {
                stat.close();
                stat = null;
            }
            if (pst != null) {
                pst.close();
                pst = null;
            }

            System.out.println("資料庫連線關閉成功…");

        } catch (SQLException e) {
            System.out.println("Close Exception :" + e.toString());
            System.out.println("資料庫連線關閉失敗…");
        }
    }

    //-------------------------------------------------資料庫搜尋-----------------------------------------------//
    public List<MaterialInfo> select(MaterialInfo materialInfo) {

        materialInfo = new MaterialInfo();

        String selectSQL = "SELECT * FROM " + materialInfo.getTableName() + " ORDER BY ID DESC";
        List<MaterialInfo> _list = null;

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                materialInfo = new MaterialInfo(); // 把Class資料清空

                materialInfo.setBarCode(rs.getString("BarCode"));
                materialInfo.setCodes(rs.getString("Codes"));
                materialInfo.setID(rs.getInt("ID"));
                materialInfo.setInsertTime(rs.getString("InsertTime"));
                materialInfo.setManufacturer(rs.getString("Manufacturer"));
                materialInfo.setNameCht(rs.getString("NameCht"));
                materialInfo.setNote(rs.getString("Note"));
                materialInfo.setOrigin(rs.getString("Origin"));
                materialInfo.setPrice(rs.getDouble("Price"));
                materialInfo.setPriceUnit(rs.getString("PriceUnit"));
                materialInfo.setStock(rs.getDouble("Stock"));
                materialInfo.setStockHigh(rs.getDouble("StockHigh"));
                materialInfo.setStockLow(rs.getDouble("StockLow"));
                materialInfo.setTableName(rs.getString("TableName"));
                materialInfo.setUnit(rs.getString("Unit"));

                //System.out.println("_list = " + _list);
                _list.add(materialInfo);
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    public List<ProductInfo> select(ProductInfo productInfo) {

        productInfo = new ProductInfo();

        String selectSQL = "SELECT * FROM " + productInfo.getTableName() + " ORDER BY ID DESC";
        List<ProductInfo> _list = null;

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                productInfo = new ProductInfo(); // 把Class資料清空

                productInfo.setBarCode(rs.getString("BarCode"));
                productInfo.setCodes(rs.getString("Codes"));
                productInfo.setID(rs.getInt("ID"));
                productInfo.setInsertTime(rs.getString("InsertTime"));
                productInfo.setListNumber(rs.getInt("ListNumber"));
                productInfo.setManufacturer(rs.getString("Manufacturer"));
                productInfo.setNameCht(rs.getString("NameCht"));
                productInfo.setNote(rs.getString("Note"));
                productInfo.setOrigin(rs.getString("Origin"));
                productInfo.setPrice(rs.getDouble("Price"));
                productInfo.setPriceUnit(rs.getString("PriceUnit"));
                productInfo.setPrice_Original(rs.getDouble("Price_Original"));
                productInfo.setPrice_Sale(rs.getDouble("Price_Sale"));
                productInfo.setStock(rs.getDouble("Stock"));
                productInfo.setStockHigh(rs.getDouble("StockHigh"));
                productInfo.setStockLow(rs.getDouble("StockLow"));
                productInfo.setTableName(rs.getString("TableName"));
                productInfo.setUnit(rs.getString("Unit"));

                //System.out.println("_list = " + _list);
                _list.add(productInfo);
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    public List<History_ProductInfo> select(History_ProductInfo history_ProductInfo) {

        history_ProductInfo = new History_ProductInfo();

        String selectSQL = "SELECT * FROM " + history_ProductInfo.getTableName() + " ORDER BY ID DESC";
        List<History_ProductInfo> _list = null;

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                history_ProductInfo = new History_ProductInfo(); // 把Class資料清空

                history_ProductInfo.setAmount(rs.getDouble("Amount"));
                history_ProductInfo.setCodes(rs.getString("Codes"));
                history_ProductInfo.setId(rs.getInt("ID"));
                history_ProductInfo.setIncome(rs.getDouble("Income"));
                history_ProductInfo.setIncomePercent(rs.getDouble("IncomePercent"));
                history_ProductInfo.setInsertTime(rs.getString("InsertTime"));
                history_ProductInfo.setPrice(rs.getInt("Price"));
                history_ProductInfo.setProductID(rs.getInt("ProductID"));
                history_ProductInfo.setTableName(rs.getString("TableName"));

                //System.out.println("_list = " + _list);
                _list.add(history_ProductInfo);
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    public List<History_MaterialInfo> select(History_MaterialInfo history_MaterialInfo) {

        history_MaterialInfo = new History_MaterialInfo();

        String selectSQL = "SELECT * FROM " + history_MaterialInfo.getTableName() + " ORDER BY ID DESC";
        List<History_MaterialInfo> _list = null;

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                history_MaterialInfo = new History_MaterialInfo(); // 把Class資料清空

                history_MaterialInfo.setAmount(rs.getDouble("Amount"));
                history_MaterialInfo.setCodes(rs.getString("Codes"));
                history_MaterialInfo.setId(rs.getInt("ID"));
                history_MaterialInfo.setInsertTime(rs.getString("InsertTime"));
                history_MaterialInfo.setMaterialID(rs.getInt("MaterialID"));
                history_MaterialInfo.setPrice(rs.getDouble("Price"));
                history_MaterialInfo.setTableName(rs.getString("TableName"));

                //System.out.println("_list = " + _list);
                _list.add(history_MaterialInfo);
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    public List<CompositionInfo> select(CompositionInfo compositionInfo) {

        compositionInfo = new CompositionInfo();

        String selectSQL = "SELECT * FROM " + compositionInfo.getTableName() + " ORDER BY ID DESC";
        List<CompositionInfo> _list = null;

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                compositionInfo = new CompositionInfo(); // 把Class資料清空

                compositionInfo.setBarCode(rs.getString("BarCode"));
                compositionInfo.setCodes(rs.getString("Codes"));
                compositionInfo.setComposition(rs.getString("Composition"));
                compositionInfo.setId(rs.getInt("ID"));
                compositionInfo.setInsertTime(rs.getString("InsertTime"));
                compositionInfo.setNameCht(rs.getString("NameCht"));
                compositionInfo.setNote(rs.getString("Note"));
                compositionInfo.setTableName(rs.getString("TableName"));

                //System.out.println("_list = " + _list);
                _list.add(compositionInfo);
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    public List<CustomerInfo> select(CustomerInfo customerInfo) {

        customerInfo = new CustomerInfo();

        String selectSQL = "SELECT * FROM " + customerInfo.getTableName() + " ORDER BY ID DESC";
        List<CustomerInfo> _list = null;

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                customerInfo = new CustomerInfo(); // 把Class資料清空

                customerInfo.setAddress(rs.getString("Address"));
                customerInfo.setBarCode(rs.getString("BarCode"));
                customerInfo.setCodes(rs.getString("Codes"));
                customerInfo.setId(rs.getInt("ID"));
                customerInfo.setInsertTime(rs.getString("InsertTime"));
                customerInfo.setLocation(rs.getString("Location"));
                customerInfo.setMoble(rs.getString("Moble"));
                customerInfo.setNameCht(rs.getString("NameCht"));
                customerInfo.setTableName(rs.getString("TableName"));
                customerInfo.setTel(rs.getString("Tel"));
                customerInfo.seteMail(rs.getString("eMail"));
                customerInfo.setNote(rs.getString("Note"));

                //System.out.println("_list = " + _list);
                _list.add(customerInfo);
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    public List<ManufacturerInfo> select(ManufacturerInfo manufacturerInfo) {

        manufacturerInfo = new ManufacturerInfo();

        String selectSQL = "SELECT * FROM " + manufacturerInfo.getTableName() + " ORDER BY ID DESC";
        List<ManufacturerInfo> _list = null;

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                manufacturerInfo = new ManufacturerInfo(); // 把Class資料清空

                manufacturerInfo.setAddress(rs.getString("Address"));
                manufacturerInfo.setBarCode(rs.getString("BarCode"));
                manufacturerInfo.setCodes(rs.getString("Codes"));
                manufacturerInfo.setId(rs.getInt("ID"));
                manufacturerInfo.setInsertTime(rs.getString("InsertTime"));
                manufacturerInfo.setLocation(rs.getString("Location"));
                manufacturerInfo.setMoble(rs.getString("Moble"));
                manufacturerInfo.setNameCht(rs.getString("NameCht"));
                manufacturerInfo.setTableName(rs.getString("TableName"));
                manufacturerInfo.setTel(rs.getString("Tel"));
                manufacturerInfo.seteMail(rs.getString("eMail"));
                manufacturerInfo.setValueAddedTax(rs.getString("ValueAddedTax"));
                manufacturerInfo.setNote(rs.getString("Note"));

                //System.out.println("_list = " + _list);
                _list.add(manufacturerInfo);
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    //-------------------------------------------------資料庫新增-----------------------------------------------//
    public void insert(MaterialInfo materialInfo) {

        String insertSQL = "INSERT INTO " + materialInfo.getTableName()
                + " (BarCode, Manufacturer, NameCht, Note, Origin, Price, PriceUnit, Stock, StockHigh, StockLow) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {

            pst = conn.prepareStatement(insertSQL);

            pst.setString(1, materialInfo.getBarCode());
            pst.setString(2, materialInfo.getManufacturer());
            pst.setString(3, materialInfo.getNameCht());
            pst.setString(4, materialInfo.getNote());
            pst.setString(5, materialInfo.getOrigin());
            pst.setDouble(6, materialInfo.getPrice());
            pst.setString(7, materialInfo.getPriceUnit());
            pst.setDouble(8, materialInfo.getStock());
            pst.setDouble(9, materialInfo.getStockHigh());
            pst.setDouble(10, materialInfo.getStockLow());

            pst.executeUpdate();

            System.out.println("資料庫連線新增成功…");

        } catch (SQLException e) {
            System.out.println("InsertDB Exception :" + e.toString());
            System.out.println("資料庫尚未建立…");
        } finally {
            closeSQL();
        }
    }

    public void insert(ProductInfo productInfo) {

        String insertSQL = "INSERT INTO " + productInfo.getTableName() + " (BarCode, Manufacturer, NameCht, Note, Origin, Unit, ListNumber, Price, Price_Original, Price_Sale, Stock, StockHigh, StockLow) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {

            pst = conn.prepareStatement(insertSQL);

            pst.setString(1, productInfo.getBarCode());
            pst.setString(2, productInfo.getManufacturer());
            pst.setString(3, productInfo.getNameCht());
            pst.setString(4, productInfo.getNote());
            pst.setString(5, productInfo.getOrigin());
            pst.setString(6, productInfo.getUnit());
            pst.setInt(7, productInfo.getListNumber());
            pst.setDouble(8, productInfo.getPrice());
            pst.setDouble(9, productInfo.getPrice_Original());
            pst.setDouble(10, productInfo.getPrice_Sale());
            pst.setDouble(11, productInfo.getStock());
            pst.setDouble(12, productInfo.getStockHigh());
            pst.setDouble(13, productInfo.getStockLow());

            pst.executeUpdate();

            System.out.println("資料庫連線新增成功…");

        } catch (SQLException e) {
            System.out.println("InsertDB Exception :" + e.toString());
            System.out.println("資料庫尚未建立…");
        } finally {
            closeSQL();
        }
    }

    public void insert(History_MaterialInfo history_MaterialInfo) {

        String insertSQL = "INSERT INTO " + history_MaterialInfo.getTableName() + " (MaterialID, Amount, Price, InsertTime) VALUES (?, ?, ?, ?)";

        try {

            pst = conn.prepareStatement(insertSQL);

            pst.setInt(1, history_MaterialInfo.getMaterialID());
            pst.setDouble(2, history_MaterialInfo.getAmount());
            pst.setDouble(3, history_MaterialInfo.getPrice());
            pst.setString(4, history_MaterialInfo.getInsertTime());

            pst.executeUpdate();

            System.out.println("資料庫連線新增成功…");

        } catch (SQLException e) {
            System.out.println("InsertDB Exception :" + e.toString());
            System.out.println("資料庫尚未建立…");
        } finally {
            closeSQL();
        }
    }

    public void insert(History_ProductInfo history_ProductInfo) {

        String insertSQL = "INSERT INTO " + history_ProductInfo.getTableName() + " (ProductID, Amount, Price, InsertTime, Income, IncomePercent) VALUES (?, ?, ?, ?, ?, ?)";

        try {

            pst = conn.prepareStatement(insertSQL);

            pst.setInt(1, history_ProductInfo.getProductID());
            pst.setDouble(2, history_ProductInfo.getAmount());
            pst.setDouble(3, history_ProductInfo.getPrice());
            pst.setString(4, history_ProductInfo.getInsertTime());
            pst.setDouble(5, history_ProductInfo.getIncome());
            pst.setDouble(6, history_ProductInfo.getIncomePercent());

            pst.executeUpdate();

            System.out.println("資料庫連線新增成功…");

        } catch (SQLException e) {
            System.out.println("InsertDB Exception :" + e.toString());
            System.out.println("資料庫尚未建立…");
        } finally {
            closeSQL();
        }
    }

    //-------------------------------------------------資料庫刪除-----------------------------------------------//
    public void delete(MaterialInfo materialInfo, int ID) {

        String deleteSQL = "DELETE FROM " + materialInfo.getTableName() + " WHERE ID = ?";

        try {

            pst = conn.prepareStatement(deleteSQL);
            pst.setInt(1, ID);
            pst.executeUpdate();
            System.out.println("資料刪除成功…");

        } catch (SQLException e) {
            System.out.println("DeleteDB Exception :" + e.toString());
            System.out.println("資料表沒有可刪除的資料…");
        } finally {
            closeSQL();
        }
    }

    public void delete(ProductInfo productInfo, int ID) {

        String deleteSQL = "DELETE FROM " + productInfo.getTableName() + " WHERE ID = ?";

        try {

            pst = conn.prepareStatement(deleteSQL);
            pst.setInt(1, ID);
            pst.executeUpdate();
            System.out.println("資料刪除成功…");

        } catch (SQLException e) {
            System.out.println("DeleteDB Exception :" + e.toString());
            System.out.println("資料表沒有可刪除的資料…");
        } finally {
            closeSQL();
        }
    }

    //---------------------------------------------------修改單一資料表---------------------------------------------------//
    public boolean update(MaterialInfo materialInfo, int ID, Double stock) {

        String updateSQL = "UPDATE " + materialInfo.getTableName() + " SET Stock = ? WHERE ID = ?";
        boolean isOK = false;

        try {

            pst = conn.prepareStatement(updateSQL);

            pst.setDouble(1, stock);
            pst.setInt(2, ID);

            pst.executeUpdate();
            System.out.println("資料表更新成功…");

            isOK = true;

        } catch (SQLException e) {
            System.out.println("UpdateDB Exception :" + e.toString());
            System.out.println("資料表更新失敗…");
        } finally {
            closeSQL();
        }
        return isOK;
    }

    public void update(ProductInfo productInfo, int ID, Double Stock, Double Price_Sale) {

        String updateSQL = "UPDATE " + productInfo.getTableName() + " SET Stock = ?, Price_Sale = ? WHERE ID = ?";

        try {

            pst = conn.prepareStatement(updateSQL);

            pst.setDouble(1, Stock);
            pst.setDouble(2, Price_Sale);
            pst.setInt(3, ID);

            pst.executeUpdate();
            System.out.println("資料表更新成功…");

        } catch (SQLException e) {
            System.out.println("UpdateDB Exception :" + e.toString());
            System.out.println("資料表更新失敗…");
        } finally {
            closeSQL();
        }
    }

    public void update(ProductInfo productInfo, int ID, Double Stock) {

        String updateSQL = "UPDATE " + productInfo.getTableName() + " SET Stock = ? WHERE ID = ?";

        try {

            pst = conn.prepareStatement(updateSQL);

            pst.setDouble(1, Stock);
            pst.setInt(2, ID);

            pst.executeUpdate();
            System.out.println("資料表更新成功…");

        } catch (SQLException e) {
            System.out.println("UpdateDB Exception :" + e.toString());
            System.out.println("資料表更新失敗…");
        } finally {
            closeSQL();
        }
    }
//-----------------------------------------------------結束----------------------------------------------------------//
}
