function isCheck(inputText, errorMessage) {

    var regexAll = /^.{1,32}$/; // 任意文字1~32個
    var regexWord = /^[\w\-\s\.]{1,32}$/; // 任意英文數字1~32個
    var regexNumber = /^\d{1,10}\\.\d{0,3}$/; // 任意數字1~10個

    var regex = regexAll;
    var messageError = "";
    var flag = false;

    switch (inputText.id) {
        case 'nameCht':
        case 'unit':
        case 'manufacturer':
        case 'origin':
            regex = regexAll;
            messageError = '請輸入1~32個字…';
            break;
        case 'stock':
        case 'price':
        case 'stockHigh':
        case 'stockLow':
            regex = regexNumber;
            messageError = '請輸入1~32個數字…';
            break;
        case 'barCode':
            regex = regexWord;
            messageError = '請輸入8個數字…';
            break;
        default:
            regex = regexAll;
            messageError = '請輸入1~32個字…';
    }

    if (!regex.test(inputText.value)) {
        if (errorMessage !== null) {
            errorMessage.className = "error";
            flag = false;
        }
    } else {
        if (errorMessage !== null) {
            messageError = "OK";
            errorMessage.className = "ok";
            flag = true;
        }
    }

    errorMessage.innerHTML = messageError;

    return flag;
}

function submitCheck(formSubmit) {

    var isOK = [
        isCheck(formSubmit['nameCht'], document.getElementById('error_NameCht')),
        isCheck(formSubmit['barCode'], document.getElementById('error_BarCode')),
        isCheck(formSubmit['product_NameEng'], document.getElementById('error_NameEng')),
        isCheck(formSubmit['product_NameCht'], document.getElementById('error_NameCht')),
        isCheck(formSubmit['product_ID'], document.getElementById('error_ID')),
        isCheck(formSubmit['product_Price'], document.getElementById('error_Price')),
        isCheck(formSubmit['product_OriginCht'], document.getElementById('error_OriginCht')),
        isCheck(formSubmit['product_OriginEng'], document.getElementById('error_OriginEng')),
        isCheck(formSubmit['product_Voltage'], document.getElementById('error_Voltage')),
        isCheck(formSubmit['product_Item'], document.getElementById('error_Item')),
        isCheck(formSubmit['product_ManufacturerCht'], document.getElementById('error_ManufacturerCht')),
        isCheck(formSubmit['product_ManufacturerEng'], document.getElementById('error_ManufacturerEng')),
        isCheck(formSubmit['product_Weight'], document.getElementById('error_Weight')),
        isCheck(formSubmit['product_Website'], document.getElementById('error_Website')),
        isCheck(formSubmit['product_Color'], document.getElementById('error_Color')),
        isCheck(formSubmit['product_Format'], document.getElementById('error_Format')),
        isCheck(formSubmit['product_Ability'], document.getElementById('error_Ability')),
        isCheck(formSubmit['product_Introduction'], document.getElementById('error_Introduction'))
    ];

    for (var i = 0; i < isOK.length; i++) {
        if (!isOK[i]) {
            alert("未輸入完全…");
            return false;
        }
    }

    return true;
}