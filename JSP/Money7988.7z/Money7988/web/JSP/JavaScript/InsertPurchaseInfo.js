//--------------------[測試資料是否完全正確]--------------------//
function submitCheck(formSubmit) {

    var isOK = [
        isCheck(formSubmit['createTime'], document.getElementById('error_createTime')),
        isCheck(formSubmit['endTime'], document.getElementById('error_endTime')),
        isCheck(formSubmit['name'], document.getElementById('error_name')),
        isCheck(formSubmit['item'], document.getElementById('error_item'))
    ];

    for (var i = 0; i < isOK.length; i++) {
        if (!isOK[i]) {
            alert("未輸入完全…");
            return false;
        }
    }
    return true;
}

//--------------------[測試輸入資料格式是否正確]--------------------//
function isCheck(inputText, errorMessage) {

    var regexWord = /^.{1,255}$/;
    var regexDateTime = /^(?:(?!0000)[0-9]{4}-(?:(?:0[1-9]|1[0-2])-(?:0[1-9]|1[0-9]|2[0-8])|(?:0[13-9]|1[0-2])-(?:29|30)|(?:0[13578]|1[02])-31)|(?:[0-9]{2}(?:0[48]|[2468][048]|[13579][26])|(?:0[48]|[2468][048]|[13579][26])00)-02-29) ([0-1][0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$/;

    var messageError = "";
    var flag = false;

    switch (inputText.id) {
        case 'createTime':
        case 'endTime':
            regex = regexDateTime;
            messageError = '請輸入正確日期…';
            break;
        default:
            regex = regexWord;
            messageError = '請輸入1~255個字…';
    }

    if (errorMessage !== null) {
        if (!regex.test(inputText.value)) {
            errorMessage.className = "error";
            flag = false;
        }
        else {
            messageError = "OK";
            errorMessage.className = "ok";
            flag = true;
        }
    }

    errorMessage.innerHTML = messageError;

    return flag;
}