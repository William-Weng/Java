//--------------------[測試資料是否完全正確]--------------------//
function submitCheck(formSubmit) {

    var isOK = [
        isCheck(formSubmit['account'], document.getElementById('account')),
        isCheck(formSubmit['password'], document.getElementById('error_password')),
        isCheck(formSubmit['nameCht'], document.getElementById('error_nameCht')),
        isCheck(formSubmit['eMail'], document.getElementById('error_eMail')),
        isCheck(formSubmit['mobilPhone'], document.getElementById('error_mobilPhone'))
    ];

    for (var i = 0; i < isOK.length; i++) {
        if (!isOK[i]) {
            alert("未輸入完全…");
            return false;
        }
    }
    return true;
}

//--------------------[測試輸入資料格式是否正確]--------------------//
function isCheck(inputText, errorMessage) {

    var regexDefault = /^.{1,255}$/;
    var regex_eMail = /^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    var regexMobilPhone = /^\d{3,4}-\d{3}-\d{3}$/;
    var regexPassword = /^([a-zA-Z0-9@*#]{6,15})$/;

    var messageError = "";
    var flag = false;

    switch (inputText.id) {
        case 'eMail':
            regex = regex_eMail;
            messageError = '請輸入正確格式…';
            break;
        case 'mobilPhone':
            regex = regexMobilPhone;
            messageError = '請輸入正確格式…';
            break;
        case 'password':
            regex = regexPassword;
            messageError = '請輸入6~15位的英數字…';
            break;
        default:
            regex = regexDefault;
            messageError = '請輸入1~255個字…';
    }

    if (errorMessage !== null) {
        if (!regex.test(inputText.value)) {
            errorMessage.className = "error";
            flag = false;
        }
        else {
            messageError = "OK";
            errorMessage.className = "ok";
            flag = true;
        }
    }

    errorMessage.innerHTML = messageError;

    return flag;
}