// ======時間處理====== //
package Tools.Utility;

import java.util.*;
import java.text.SimpleDateFormat;

public class TimeNow {

    private String allTime = ""; // 1911-01-01 12:00:00:000
    private String date = ""; // 1911-01-01
    private String yearMonth = ""; // 1911-01
    private String time = ""; // 12:00:00:000
    private String year = ""; // 年
    private String month = ""; // 月
    private String day = ""; // 日
    private String hour = ""; // 時
    private String minute = ""; // 分
    private String second = ""; // 秒
    private String milliSecond = ""; // 毫秒

    //--------------------[初始化變數]--------------------//
    public TimeNow() {

        SimpleDateFormat allTimeNow = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss"); // 設定時間格式
        SimpleDateFormat dateNow = new SimpleDateFormat("yyyy-MM-dd"); // 設定時間格式
        SimpleDateFormat yearMonthNow = new SimpleDateFormat("yyyy-MM"); // 設定時間格式
        SimpleDateFormat timeNow = new SimpleDateFormat("kk:mm:ss:SSS"); // 設定時間格式
        SimpleDateFormat yearNow = new SimpleDateFormat("yyyy"); // 設定時間格式
        SimpleDateFormat monthNow = new SimpleDateFormat("MM"); // 設定時間格式
        SimpleDateFormat dayNow = new SimpleDateFormat("dd"); // 設定時間格式
        SimpleDateFormat hourNow = new SimpleDateFormat("kk"); // 設定時間格式
        SimpleDateFormat minuteNow = new SimpleDateFormat("mm"); // 設定時間格式
        SimpleDateFormat secondNow = new SimpleDateFormat("ss"); // 設定時間格式
        SimpleDateFormat milliSecondNow = new SimpleDateFormat("SSS"); // 設定時間格式

        Date nowToday = new Date(); // 取得當前時間

        this.allTime = allTimeNow.format(nowToday); // 依格式取得時間
        this.date = dateNow.format(nowToday); // 依格式取得時間
        this.yearMonth = yearMonthNow.format(nowToday); // 依格式取得時間
        this.time = timeNow.format(nowToday); // 依格式取得時間
        this.year = yearNow.format(nowToday); // 依格式取得時間
        this.month = monthNow.format(nowToday); // 依格式取得時間
        this.day = dayNow.format(nowToday); // 依格式取得時間
        this.hour = hourNow.format(nowToday); // 依格式取得時間
        this.minute = minuteNow.format(nowToday); // 依格式取得時間
        this.second = secondNow.format(nowToday); // 依格式取得時間
        this.milliSecond = milliSecondNow.format(nowToday); // 依格式取得時間
    }

    //--------------------[Java時間→SQL時間]--------------------//
    public java.sql.Date ToSqlDate() {
        java.util.Date now = new java.util.Date();
        java.sql.Date sqlDate = new java.sql.Date(now.getTime());

        return sqlDate;
    }

    public java.sql.Time ToSqlTime() {
        java.util.Date now = new java.util.Date();
        java.sql.Time sqlTime = new java.sql.Time(now.getTime());

        return sqlTime;
    }

    //--------------------[設定、取值]--------------------//
    public String getAllTime() {
        return allTime;
    }

    public String getDate() {
        return date;
    }

    public String getYearMonth() {
        return yearMonth;
    }

    public String getTime() {
        return time;
    }

    public String getYear() {
        return year;
    }

    public String getMonth() {
        return month;
    }

    public String getDay() {
        return day;
    }

    public String getHour() {
        return hour;
    }

    public String getMinute() {
        return minute;
    }

    public String getSecond() {
        return second;
    }

    public String getMilliSecond() {
        return milliSecond;
    }

    public void setAllTime(String allTime) {
        this.allTime = allTime;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setYearMonth(String yearMonth) {
        this.yearMonth = yearMonth;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public void setHour(String hour) {
        this.hour = hour;
    }

    public void setMinute(String minute) {
        this.minute = minute;
    }

    public void setSecond(String second) {
        this.second = second;
    }

    public void setMilliSecond(String milliSecond) {
        this.milliSecond = milliSecond;
    }
    //--------------------[結束]--------------------//
}
