package Tools.MySQL;

import Data.Model.PageInfo;
import Data.Model.PurchaseInfo;
import Data.Model.PurchaseNumber;
import Data.Model.RegisterInfo;
import Data.Model.SQLConnentInfo;
import Tools.Utility.TimeNow;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DatabaseUtility implements Serializable {

    private Connection conn;
    private Statement stat;
    private ResultSet rs;
    private PreparedStatement pst;

    //--------------------[開啟資料庫連線]--------------------//
    public DatabaseUtility() {

        setAllNull();

        SQLConnentInfo infoSQL = new SQLConnentInfo();

        try {

            Class.forName(infoSQL.getDriver());
            conn = DriverManager.getConnection(infoSQL.getUrl(), infoSQL.getUser(), infoSQL.getPassword());

            if (conn != null && !conn.isClosed()) {
                System.out.println("資料庫連線測試成功…");
            }

        } catch (ClassNotFoundException eNotFound) {
            System.out.println("DriverClassNotFound :" + eNotFound.toString());
            System.out.println("資料庫驅動程式出錯…");
        } catch (SQLException eSQL) {
            System.out.println("Exception :" + eSQL.toString());
            System.out.println("資料庫帳號、密碼錯誤…");
        }
    }

    //--------------------[關閉資料庫連線]--------------------//
    private void closeSQL() {
        try {

            if (rs != null) {
                rs.close();
                rs = null;
            }
            if (stat != null) {
                stat.close();
                stat = null;
            }
            if (pst != null) {
                pst.close();
                pst = null;
            }

            System.out.println("資料庫連線關閉成功…");

        } catch (SQLException e) {
            System.out.println("Close Exception :" + e.toString());
            System.out.println("資料庫連線關閉失敗…");
        }
    }

    //--------------------[清空資料庫連線]--------------------//
    private void setAllNull() {
        conn = null;
        stat = null;
        rs = null;
        pst = null;
    }

    //--------------------[寫入採購資訊]--------------------//
    public void insert(PurchaseInfo purchaseInfo) {

        String _insertSQL = "INSERT INTO " + purchaseInfo.getTableName() + " (Number, Name, CreateTime, EndTime, Item) VALUES (?, ?, ?, ?, ?)";

        try {

            pst = conn.prepareStatement(_insertSQL);

            pst.setString(1, purchaseInfo.getNumber());
            pst.setString(2, purchaseInfo.getName());
            pst.setString(3, purchaseInfo.getCreateTime());
            pst.setString(4, purchaseInfo.getEndTime());
            pst.setString(5, purchaseInfo.getItem());

            pst.executeUpdate();

            System.out.println("資料庫連線新增成功…");

        } catch (SQLException e) {
            System.out.println("InsertDB Exception :" + e.toString());
            System.out.println("資料庫尚未建立…");
        } finally {
            closeSQL();
        }
    }

    //--------------------[寫入流水號資訊]--------------------//
    public void insert(PurchaseNumber purchaseNumber) {

        String _insertSQL = "INSERT INTO " + purchaseNumber.getTableName() + " (Number, Date) VALUES (?, ?)";

        try {

            pst = conn.prepareStatement(_insertSQL);

            pst.setInt(1, purchaseNumber.getNumber());
            pst.setString(2, purchaseNumber.getDate());

            pst.executeUpdate();

            System.out.println("資料庫連線新增成功…");

        } catch (SQLException e) {
            System.out.println("InsertDB Exception :" + e.toString());
            System.out.println("資料庫尚未建立…");
        } finally {
            closeSQL();
        }
    }

    //--------------------[寫入註冊資訊]--------------------//
    public boolean insert(RegisterInfo registerInfo) {

        String _insertSQL = "INSERT INTO " + registerInfo.getTableName() + " (Account, Password, MobilPhone, eMail, NameCht) VALUES (?, ?, ?, ?, ?)";
        boolean isOK = false;

        try {

            pst = conn.prepareStatement(_insertSQL);

            pst.setString(1, registerInfo.getAccount());
            pst.setString(2, registerInfo.getPassword());
            pst.setString(3, registerInfo.getMobilPhone());
            pst.setString(4, registerInfo.geteMail());
            pst.setString(5, registerInfo.getNameCht());

            pst.executeUpdate();
            isOK = true;
            System.out.println("資料庫連線新增成功…");

        } catch (SQLException e) {
            isOK = false;
            System.out.println("InsertDB Exception :" + e.toString());
            System.out.println("資料庫尚未建立…");
        } finally {
            closeSQL();
        }
        return isOK;
    }

    //--------------------[更新流水號資訊]--------------------//
    public void update(PurchaseNumber purchaseNumber) {

        String updateSQL = "UPDATE " + purchaseNumber.getTableName() + " SET Number = ? WHERE ID = ?";

        try {

            pst = conn.prepareStatement(updateSQL);

            pst.setInt(1, purchaseNumber.getNumber());
            pst.setInt(2, purchaseNumber.getID());

            pst.executeUpdate();
            System.out.println("資料表更新成功…");

        } catch (SQLException e) {
            System.out.println("UpdateDB Exception :" + e.toString());
            System.out.println("資料表更新失敗…");
        } finally {
            closeSQL();
        }
    }
//--------------------[更新採購資訊]--------------------//

    public void update(PurchaseInfo purchaseInfo) {

        String updateSQL = "UPDATE " + purchaseInfo.getTableName() + " SET Name = ?, CreateTime = ?, EndTime = ?, Item = ?, UpdateTime = ? WHERE ID = ?";

        try {

            pst = conn.prepareStatement(updateSQL);

            pst.setString(1, purchaseInfo.getName());
            pst.setString(2, purchaseInfo.getCreateTime());
            pst.setString(3, purchaseInfo.getEndTime());
            pst.setString(4, purchaseInfo.getItem());
            pst.setString(5, new TimeNow().getAllTime());

            pst.setInt(6, purchaseInfo.getID());

            pst.executeUpdate();
            System.out.println("資料表更新成功…");

        } catch (SQLException e) {
            System.out.println("UpdateDB Exception :" + e.toString());
            System.out.println("資料表更新失敗…");
        } finally {
            closeSQL();
        }
    }

    //--------------------[刪除該資訊]--------------------//
    public void delete(String tableName, int ID) {

        String deleteSQL = "DELETE FROM " + tableName + " WHERE ID = ?";

        try {

            pst = conn.prepareStatement(deleteSQL);
            pst.setInt(1, ID);
            pst.executeUpdate();
            System.out.println("資料刪除成功…");

        } catch (SQLException e) {
            System.out.println("DeleteDB Exception :" + e.toString());
            System.out.println("資料表沒有可刪除的資料…");
        } finally {
            closeSQL();
        }
    }

    //--------------------[查詢所有流水號資訊]--------------------//
    public List<PurchaseNumber> select(PurchaseNumber purchaseNumber) {

        purchaseNumber = new PurchaseNumber();
        String _selectSQL = "SELECT * FROM " + purchaseNumber.getTableName() + " ORDER BY Date DESC";
        List<PurchaseNumber> _list = null;

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(_selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                purchaseNumber = new PurchaseNumber(); // 把Class資料清空

                purchaseNumber.setCode(rs.getString("Code"));
                purchaseNumber.setDate(rs.getString("Date"));
                purchaseNumber.setID(rs.getInt("ID"));
                purchaseNumber.setNumber(rs.getInt("Number"));
                purchaseNumber.setTableName(rs.getString("TableName"));
                purchaseNumber.setUpdateTime(rs.getString("UpdateTime"));

                _list.add(purchaseNumber);
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    //--------------------[查詢最新一筆流水號資訊]--------------------//
    public PurchaseNumber selectNewestOne(PurchaseNumber purchaseNumber) {

        purchaseNumber = new PurchaseNumber();
        String _selectSQL = "SELECT * FROM " + purchaseNumber.getTableName() + " ORDER BY Date DESC Limit 1";

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(_selectSQL);

            while (rs.next()) {

                purchaseNumber = new PurchaseNumber(); // 把Class資料清空

                purchaseNumber.setCode(rs.getString("Code"));
                purchaseNumber.setDate(rs.getString("Date"));
                purchaseNumber.setID(rs.getInt("ID"));
                purchaseNumber.setNumber(rs.getInt("Number"));
                purchaseNumber.setTableName(rs.getString("TableName"));
                purchaseNumber.setUpdateTime(rs.getString("UpdateTime"));
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return purchaseNumber;
    }

    //--------------------[查詢所有採購資訊]--------------------//
    public List<PurchaseInfo> select(PurchaseInfo purchaseInfo) {

        purchaseInfo = new PurchaseInfo();
        String _selectSQL = "SELECT * FROM " + purchaseInfo.getTableName() + " ORDER BY CreateTime DESC";
        List<PurchaseInfo> _list = null;

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(_selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                purchaseInfo = new PurchaseInfo(); // 把Class資料清空

                purchaseInfo.setCode(rs.getString("Code"));
                purchaseInfo.setCreateTime(rs.getString("CreateTime"));
                purchaseInfo.setEndTime(rs.getString("EndTime"));
                purchaseInfo.setID(rs.getInt("ID"));
                purchaseInfo.setItem(rs.getString("Item"));
                purchaseInfo.setName(rs.getString("Name"));
                purchaseInfo.setNumber(rs.getString("Number"));
                purchaseInfo.setTableName(rs.getString("TableName"));
                purchaseInfo.setUpdateTime(rs.getString("UpdateTime"));

                _list.add(purchaseInfo);
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    //--------------------[查詢部份採購資訊]--------------------//
    public List<PurchaseInfo> selectPost(PurchaseInfo purchaseInfo, PageInfo pageInfo) {

        purchaseInfo = new PurchaseInfo();
        String _selectSQL = "SELECT * FROM " + purchaseInfo.getTableName() + " ORDER BY UpdateTime DESC LIMIT " + pageInfo.getStart() + "," + pageInfo.getLimit();
        List<PurchaseInfo> _list = null;

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(_selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                purchaseInfo = new PurchaseInfo(); // 把Class資料清空

                purchaseInfo.setCode(rs.getString("Code"));
                purchaseInfo.setCreateTime(rs.getString("CreateTime"));
                purchaseInfo.setEndTime(rs.getString("EndTime"));
                purchaseInfo.setID(rs.getInt("ID"));
                purchaseInfo.setItem(rs.getString("Item"));
                purchaseInfo.setName(rs.getString("Name"));
                purchaseInfo.setNumber(rs.getString("Number"));
                purchaseInfo.setTableName(rs.getString("TableName"));
                purchaseInfo.setUpdateTime(rs.getString("UpdateTime"));

                _list.add(purchaseInfo);
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    //--------------------[查詢單筆採購資訊]--------------------//
    public PurchaseInfo selectOne(PurchaseInfo purchaseInfo) {

        String _selectSQL = "SELECT * FROM " + purchaseInfo.getTableName() + " WHERE ID = " + purchaseInfo.getID();

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(_selectSQL);

            while (rs.next()) {

                purchaseInfo = new PurchaseInfo(); // 把Class資料清空

                purchaseInfo.setCode(rs.getString("Code"));
                purchaseInfo.setCreateTime(rs.getString("CreateTime"));
                purchaseInfo.setEndTime(rs.getString("EndTime"));
                purchaseInfo.setID(rs.getInt("ID"));
                purchaseInfo.setItem(rs.getString("Item"));
                purchaseInfo.setName(rs.getString("Name"));
                purchaseInfo.setNumber(rs.getString("Number"));
                purchaseInfo.setTableName(rs.getString("TableName"));
                purchaseInfo.setUpdateTime(rs.getString("UpdateTime"));
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return purchaseInfo;
    }

    //--------------------[查詢單筆註冊資訊]--------------------//
    public RegisterInfo selectOne(RegisterInfo registerInfo) {

        String _selectSQL = "SELECT * FROM " + registerInfo.getTableName() + " WHERE Account = \'" + registerInfo.getAccount()+"\'";

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(_selectSQL);

            System.out.println(_selectSQL);
            
            while (rs.next()) {

                registerInfo = new RegisterInfo(); // 把Class資料清空

                registerInfo.setID(rs.getInt("ID"));
                registerInfo.setAccount(rs.getString("Account"));
                registerInfo.setPassword(rs.getString("Password"));
                registerInfo.setMobilPhone(rs.getString("MobilPhone"));
                registerInfo.setNameCht(rs.getString("NameCht"));
                registerInfo.setUpdateTime(rs.getString("UpdateTime"));
                registerInfo.seteMail(rs.getString("eMail"));
                registerInfo.setTableName(rs.getString("TableName"));
                registerInfo.setCode(rs.getString("Code"));
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return registerInfo;
    }

    //--------------------[查詢總筆數]--------------------//
    public int selectCount(String tableName) {

        String _selectSQL = "SELECT COUNT(*) AS rowCount FROM " + tableName;

        int _count = 0;

        try {
            stat = conn.createStatement();
            rs = stat.executeQuery(_selectSQL);

            rs.next();
            _count = rs.getInt("rowCount");

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _count;
    }
    //--------------------[結束]--------------------//
}
