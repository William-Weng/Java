package Java.Serlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/GCM.get"})

public class GCM_get extends HttpServlet implements Serializable {

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    //  http://192.168.0.117:8080/Money7988/hello.view?name=winni&password=810725&page=1&limit=10
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");

        String ID = request.getParameter("id");
        try (PrintWriter pw = new PrintWriter("../webapps/Money7988/JSON/GCM.json", "UTF-8")) {
            pw.println(ID);
            pw.flush();
        }
        response.setStatus(HttpServletResponse.SC_OK);
        System.out.println(response.getStatus());
    }
}
