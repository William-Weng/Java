package Java.Serlet;

import Data.Model.PageInfo;
import Data.Model.PurchaseInfo;
import Data.Model.RegisterInfo;
import Tools.MySQL.DatabaseUtility;
import Tools.Utility.Word;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@WebServlet(urlPatterns = {"/hello.view"})

public class MySQLtoJSON extends HttpServlet implements Serializable {

    private List<PurchaseInfo> _listPurchaseInfo;

    private String start = "{";
    private String end = "}";
    private String colon = ":";
    private String name, password, _page, _limit;

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    //  http://192.168.0.117:8080/Money7988/hello.view?name=winni&password=810725&page=1&limit=10
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");

        PrintWriter out = response.getWriter();
        DatabaseUtility utilDB = new DatabaseUtility();
        RegisterInfo registerInfo = new RegisterInfo();

        _page = request.getParameter("page");
        _limit = request.getParameter("limit");
        name = request.getParameter("name");
        password = request.getParameter("password");

        PageInfo pageInfo;

        if (_page == null || _page.trim().isEmpty() || !Word.isNumeric(_page.trim())) {
            _page = "1";
        }

        if (_limit == null || _limit.trim().isEmpty() || !Word.isNumeric(_limit.trim())) {
            _limit = "10";
        }

        if (name == null || _limit.trim().isEmpty() || !Word.isNumeric(_limit.trim())) {
            name = "";
        }

        if (password == null || _limit.trim().isEmpty() || !Word.isNumeric(_limit.trim())) {
            password = "";
        }

        registerInfo.setAccount(name);
        registerInfo = utilDB.selectOne(registerInfo);

        pageInfo = new PageInfo(new PurchaseInfo().getTableName(), Integer.parseInt(_page.trim()), Integer.parseInt(_limit.trim()));

        if (name.equals(registerInfo.getAccount()) && password.equals(registerInfo.getPassword())) {

            try (PrintWriter pw = new PrintWriter("../webapps/Money7988/JSON/" + registerInfo.getAccount() + ".json", "UTF-8")) {

                //準備使用者資料
                String purchaseInfoName = "\"" + new PurchaseInfo().getTableName() + "\"";

                _listPurchaseInfo = utilDB.selectPost(new PurchaseInfo(), pageInfo);

                //JSON陣列
                JSONArray array = new JSONArray();

                pw.println(start + purchaseInfoName + colon);

                for (PurchaseInfo bean : _listPurchaseInfo) {
                    //單個使用者JSON物件
                    JSONObject obj = new JSONObject();

                    try {
                        obj.put("ID", bean.getID());
                        obj.put("Code", bean.getCode());
                        obj.put("CreateTime", bean.getCreateTime().toString().substring(0, 19));
                        obj.put("EndTime", bean.getEndTime().toString().substring(0, 19));
                        obj.put("UpdateTime", bean.getUpdateTime().toString().substring(0, 19));
                        obj.put("Item", bean.getItem());
                        obj.put("Name", bean.getName());
                        obj.put("Number", bean.getNumber());
                    } catch (JSONException e) {
                        System.out.println(e.getMessage());
                    }
                    array.put(obj);
                }

                pw.println(array.toString() + end);
                pw.flush();

                response.sendRedirect("./JSON/" + registerInfo.getAccount() + ".json");
                response.setStatus(HttpServletResponse.SC_OK);
                System.out.println(response.getStatus());
            }
        } else {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            System.out.println(response.getStatus());
            out.write("帳號、密碼錯誤…");
            out.flush();
            out.close();
        }
    }
}
