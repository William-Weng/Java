package Java.Serlet;

// 這個JAVA程式的作用為

import java.io.IOException;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

// 發送 POST 給 Google GCM server，
// 並接收 Google GCM server 的回傳訊息
//在某 Android 裝置已移除您的 app 時
// 做對應的處理
public class GCM_send {

    private static String Authorization = "57b0dad2f5b0c2c017a4a2842cff4a489265d2b4";
    private static String API_KEY = "AIzaSyCRDKTR9NjVzx6Nza_i-JlYFy8h070HbEk";
    private static String GCM_URL = "https://android.googleapis.com/gcm/send";
    private static String REG_ID = "APA91bHNRclXa4GVFwP0bW1HG-vexO4x3a3wbfbXJcDIQK281dqIDtuBLk5XeuApZegTxt0P9KTG24_kQsmMIruNBXHHTHYDxaWL_CkWODn7Feg8n6DBfb8S1U1f-JMLa5KVvC4M_2qN8ujLz1xrGJ5RwN2cujoviA";

    public static void main(String[] args) throws JSONException, IOException {

        String regid;
        HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();

        try (CloseableHttpClient closeableHttpClient = httpClientBuilder.build()) {
            HttpPost httpPost = new HttpPost(GCM_URL);

            httpPost.addHeader(Authorization, API_KEY);

            httpPost.addHeader("Content-Type", "application/json");

            JSONObject jsonObject = new JSONObject();

            JSONArray jsonArray = new JSONArray();
            REG_ID = "APA91bHNRclXa4GVFwP0bW1HG-vexO4x3a3wbfbXJcDIQK281dqIDtuBLk5XeuApZegTxt0P9KTG24_kQsmMIruNBXHHTHYDxaWL_CkWODn7Feg8n6DBfb8S1U1f-JMLa5KVvC4M_2qN8ujLz1xrGJ5RwN2cujoviA";
            jsonArray.put(REG_ID);      //將資料表中的各Registration ID放入jsonArray中

            jsonObject.put("registration_ids", jsonArray);

            httpPost.setEntity(new StringEntity(jsonObject.toString()));
            HttpResponse httpResponse = closeableHttpClient.execute(httpPost);
            System.out.println(httpResponse.toString());

            String ss = EntityUtils.toString(httpResponse.getEntity());
        }
    }
}
