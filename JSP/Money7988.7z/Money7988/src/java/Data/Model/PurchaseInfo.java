package Data.Model;

public class PurchaseInfo {

    private int id; // 流水編號
    private String number; // 採購案號
    private String name; // 採購案名
    private String createTime; // 開標時間
    private String endTime; // 結標時間
    private String updateTime; // 更新時間
    private String item; // 採購細項
    private String tableName; // 資料表名
    private String code; // 其它功能

    //--------------------[初始化變數]--------------------//
    public PurchaseInfo() {
        this.tableName = "Money7988.PurchaseInfo";
    }

    public PurchaseInfo(String name, String createTime, String endTime, String item) {
        this();
        this.name = name;
        this.createTime = createTime;
        this.endTime = endTime;
        this.item = item;
    }

    //--------------------[自定義輸出格式]--------------------//
    @Override
    public String toString() {
        String _tab = "\t";
        String _str = this.getID() + _tab + this.getNumber() + _tab + this.getName() + _tab + this.getCreateTime() + _tab + this.getEndTime() + _tab + this.getUpdateTime() + _tab + this.getItem() + _tab + this.getTableName() + _tab + this.getCode();
        return _str;
    }

    //--------------------[設定、取值]--------------------//
    public int getID() {
        return id;
    }

    public String getNumber() {
        return number;
    }

    public String getName() {
        return name;
    }

    public String getCreateTime() {
        return createTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public String getItem() {
        return item;
    }

    public String getTableName() {
        return tableName;
    }

    public String getCode() {
        return code;
    }

    public void setID(int id) {
        this.id = id;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public void setCode(String code) {
        this.code = code;
    }
    //--------------------[結束]--------------------//
}
