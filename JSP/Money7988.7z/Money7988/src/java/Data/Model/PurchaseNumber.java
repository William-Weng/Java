package Data.Model;

public class PurchaseNumber {

    private int id; // 流水編號
    private int number; // 採購案號(號碼)
    private String date; // 採購案號(時間)
    private String updateTime; // 更新時間
    private String tableName; // 資料表名
    private String code; // 其它功能

    //--------------------[初始化變數]--------------------//
    public PurchaseNumber() {
        this.tableName = "Money7988.PurchaseNumber";
    }

    public PurchaseNumber(int number, String date) {
        this();
        this.number = number;
        this.date = date;
    }

    //--------------------[自定義輸出格式]--------------------//
    @Override
    public String toString() {
        String _tab = "\t";
        String _str = this.getID() + _tab + this.getDate() + _tab + this.getNumber() + _tab + this.getUpdateTime() + _tab + this.getTableName() + _tab + this.getCode();
        return _str;
    }

    //--------------------[設定、取值]--------------------//
    public int getID() {
        return id;
    }

    public int getNumber() {
        return number;
    }

    public String getDate() {
        return date;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public String getTableName() {
        return tableName;
    }

    public String getCode() {
        return code;
    }

    public void setID(int id) {
        this.id = id;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public void setCode(String code) {
        this.code = code;
    }
    //--------------------[結束]--------------------//
}
