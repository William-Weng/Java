package Data.Model;

public class RegisterInfo {

    private int id; // 流水編號
    private String account; // 帳號
    private String password; // 密碼
    private String nameCht; // 姓名
    private String eMail; // 電子郵件
    private String mobilPhone; // 手機
    private String updateTime; // 更新時間
    private String tableName; // 資料表名
    private String code; // 其它功能

    //--------------------[初始化變數]--------------------//
    public RegisterInfo() {
        this.tableName = "Money7988.RegisterInfo";
    }

    //--------------------[自定義輸出格式]--------------------//
    @Override
    public String toString() {
        String _tab = "\t";
        String _str = this.getID() + _tab + this.getAccount() + _tab + this.getPassword() + _tab + this.geteMail() + _tab + this.getMobilPhone() + _tab + this.getUpdateTime() + _tab + this.getTableName() + _tab;
        return _str;
    }

    //--------------------[設定、取值]--------------------//
    public int getID() {
        return id;
    }

    public String getAccount() {
        return account;
    }

    public String getPassword() {
        return password;
    }

    public String getNameCht() {
        return nameCht;
    }

    public String geteMail() {
        return eMail;
    }

    public String getMobilPhone() {
        return mobilPhone;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public String getTableName() {
        return tableName;
    }

    public String getCode() {
        return code;
    }

    public void setID(int id) {
        this.id = id;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setNameCht(String nameCht) {
        this.nameCht = nameCht;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }

    public void setMobilPhone(String mobilPhone) {
        this.mobilPhone = mobilPhone;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public void setCode(String code) {
        this.code = code;
    }
    //--------------------[結束]--------------------//
}
