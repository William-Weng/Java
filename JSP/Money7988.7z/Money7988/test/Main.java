
import Data.Model.RegisterInfo;
import Tools.MySQL.DatabaseUtility;

public class Main {

    public static void main(String[] args) {
        DatabaseUtility utilDB = new DatabaseUtility();
//
//        List<PurchaseInfo> _listPurchaseInfo;
//
//        _listPurchaseInfo = utilDB.select(new PurchaseInfo());
//
//        for (int i = 0; i < 50; i++) {
//            utilDB.insert(_listPurchaseInfo.get(0));
//        }

        RegisterInfo registerInfo = new RegisterInfo();

        registerInfo.setAccount("william");
        registerInfo = utilDB.selectOne(registerInfo);

        System.out.println(registerInfo.getAccount());
        System.out.println(registerInfo.getPassword());
    }
}
