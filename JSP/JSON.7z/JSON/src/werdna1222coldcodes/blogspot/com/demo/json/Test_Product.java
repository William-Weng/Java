package werdna1222coldcodes.blogspot.com.demo.json;

public class Test_Product {

    public static void main(String[] args) {
        String insert1 = "INSERT INTO ERP.Product (NameCht, BarCode, ListNumber, Stock, Unit, Price, Price_Original, Price_Sale, StockHigh, StockLow, Codes) VALUES (";
        String insert2 = "\"豆乾";
        String insertA = "\"";
        String insert3 = ",\"810725";
        String insert4 = ",2,500,\"KG\",100,80,50,1000,100,\"春季:299,999,60,20,0,25,0|夏季:299,799,60,20,5,20,0|秋季:299,599,60,20,5,15,0|冬季:299,1199,60,0,0,210,0\");";

        for (int i = 1; i <= 25; i++) {

            String strNumber = String.format("%05d", i); // "00123"
            System.out.println(insert1 + insert2 + strNumber + insertA + insert3 + strNumber + insertA + insert4);
        }
    }
}
