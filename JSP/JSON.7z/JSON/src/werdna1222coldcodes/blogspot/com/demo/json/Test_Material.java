package werdna1222coldcodes.blogspot.com.demo.json;

public class Test_Material {

    public static void main(String[] args) {
        String insert1 = "INSERT INTO ERP.Material (NameCht, BarCode, Stock, Unit, Price, PriceUnit, StockHigh, StockLow) VALUES (";
        String insert2 = "\"土豆";
        String insertA = "\"";
        String insert3 = ",\"810725";
        String insert4 = ",9999.666,\"公斤\",12,\"NT\",700,50.25);";

        for (int i = 1; i <= 25; i++) {

            String strNumber = String.format("%05d", i); // "00123"
            System.out.println(insert1 + insert2 + strNumber + insertA + insert3 + strNumber + insertA + insert4);
        }
    }
}
