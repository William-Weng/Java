package com.safewayoa.Tools.Utility;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Security {

    public static String getMD5(String str) {

        MessageDigest md5;
        StringBuilder stringBuilder = new StringBuilder();
        byte[] digest;

        try {
            md5 = MessageDigest.getInstance("MD5");
            md5.update(str.getBytes());
            digest = md5.digest();

            for (byte b : digest) {
                stringBuilder.append(String.format("%02x", b & 0xff));
            }

        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(Security.class.getName()).log(Level.SEVERE, null, ex);
        }

        return stringBuilder.toString();
    }
}
