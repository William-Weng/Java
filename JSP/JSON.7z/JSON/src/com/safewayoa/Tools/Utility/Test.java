
import com.safewayoa.Tools.Utility.Security;


public class Test {

    public static void main(String[] args) {
        System.out.println(Security.getMD5("31234687979"));
    }
}
