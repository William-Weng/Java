// =====資料庫連接相關數據===== //
package com.safewayoa.GetTicketMachine_InitialDB.Data.Model;

import com.safewayoa.Tools.Utility.ProcessArray;
import java.io.File;
import java.util.List;

public class SQLConnentInfo {

//------------------------------變數宣告----------------------------------------//
    private String ip; // 資料庫連接的網路位置…
    private String port; // 資料庫連接網路的埠…    
    private String databaseName; // 連接的資料庫名稱…
    private String user; // 帳號…
    private String password; // 密碼…
    private String driver; // 驅動程式…
    private String url; // 連接語法、編碼…（jdbc:mysql://127.0.0.1:3306/GetTicketMachine?useUnicode=true&characterEncoding=UTF8）

    public SQLConnentInfo() {

        String[] _SqlInfo;
        _SqlInfo = this.ReadSQLInfo("src/Text/INI/SQLConnentInfo_UTF8.ini");

        String[] SQLInfo = _SqlInfo[0].split("\t"); // 只讀第一行

        this.ip = SQLInfo[0];
        this.port = SQLInfo[1];
        this.user = SQLInfo[2];
        this.password = SQLInfo[3];

//        this.ip = "127.0.0.1";
//        this.port = "3306";
//        this.user = "william";
//        this.password = "19790609";
        this.databaseName = "GetTicketMachine";
        this.driver = "com.mysql.jdbc.Driver";

        this.url = "jdbc:mysql://" + ip + ":" + port + "/" + databaseName + "?useUnicode=true&characterEncoding=UTF8";

    }
    //----------ReadFile----------//

    private String[] ReadSQLInfo(String path) {

        File file = new File(path);
        String errorPath = "com/safewayoa/GetTicketMachine_InitialDB/Data/Text/INI/SQLConnentInfo_UTF8.ini";

        ProcessArray processArray = new ProcessArray();
        List<String> _list;

        if (file.exists()) {
            _list = processArray.ReadFile(path);
        } else {
            _list = processArray.ReadFileStream(errorPath);
        }

        String[] SQLInfo = _list.toArray(new String[0]); // toArray<String>

        //System.out.println("_list = " + _list);
        LoggerInfo.loggerInfo.info("檔案讀取成功");

        return SQLInfo;
    }

//----------ReadFile----------//
    public String getIp() {
        return ip;
    }

    public String getPort() {
        return port;
    }

    public String getDatabaseName() {
        return databaseName;
    }

    public String getUser() {
        return user;
    }

    public String getPassword() {
        return password;
    }

    public String getDriver() {
        return driver;
    }

    public String getUrl() {
        return url;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public void setDatabaseName(String databaseName) {
        this.databaseName = databaseName;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setDriver(String driver) {
        this.driver = driver;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
