DROP TABLE IF EXISTS GetTicketMachine.TicketInfo;

CREATE TABLE GetTicketMachine.TicketInfo(
    PrimaryKey INTEGER(5) AUTO_INCREMENT PRIMARY KEY,
    Numer INTEGER(5) NOT NULL,
    Status VARCHAR(4) NOT NULL DEFAULT '----',
    TableName VARCHAR(32) DEFAULT 'GetTicketMachine.TicketInfo',
    FunctionCode VARCHAR(4) DEFAULT '----',
    InsertDate DATE DEFAULT '1970-01-01',
    InsertTime TIME DEFAULT '00:00:00'
);