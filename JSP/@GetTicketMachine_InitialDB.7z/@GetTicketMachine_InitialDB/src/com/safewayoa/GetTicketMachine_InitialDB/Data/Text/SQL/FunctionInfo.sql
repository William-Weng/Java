DROP TABLE IF EXISTS GetTicketMachine.FunctionInfo;

CREATE TABLE GetTicketMachine.FunctionInfo(
    PrimaryKey INTEGER(1) AUTO_INCREMENT PRIMARY KEY,
    FunctionCode VARCHAR(4) UNIQUE DEFAULT '----',
    FunctionName VARCHAR(255) DEFAULT '----',
    RangeStart INTEGER(4) UNIQUE DEFAULT 0,
    RangeEnd INTEGER(4) UNIQUE DEFAULT 0,
    Running INTEGER(4) DEFAULT 0,
    Waitting INTEGER(4) DEFAULT 0,
    ImagesURL VARCHAR(255)  DEFAULT 'Image/BusinessTypes/1.png',
    InsertStaff VARCHAR(4) DEFAULT '----',
    InsertDate DATE DEFAULT '1970-01-01',
    InsertTime TIME DEFAULT '00:00:00'
);

INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (1, 'A001', '業務類型1', 1, 700, 0, 'Image/BusinessTypes/1.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (2, 'B001', '業務類型2', 701, 800, 700, 'Image/BusinessTypes/2.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (3, 'C001', '業務類型3', 801, 999, 800, 'Image/BusinessTypes/3.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (4, 'D001', '業務類型4', 1000, 1100, 999, 'Image/BusinessTypes/4.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (5, 'E001', '業務類型5', 1101, 1200, 1100, 'Image/BusinessTypes/5.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (6, 'F001', '業務類型6', 1201, 1300, 1200, 'Image/BusinessTypes/6.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (7, 'G001', '業務類型7', 1301, 1400, 1300, 'Image/BusinessTypes/7.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (8, 'H001', '業務類型8', 1401, 1500, 1400, 'Image/BusinessTypes/8.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (9, 'I001', '業務類型9', 1501, 1600, 1500, 'Image/BusinessTypes/9.png');