DROP DATABASE IF EXISTS GetTicketMachine;

CREATE DATABASE GetTicketMachine;

DROP TABLE IF EXISTS GetTicketMachine.ButtonInfo;

CREATE TABLE GetTicketMachine.ButtonInfo(
    PrimaryKey INTEGER(3) AUTO_INCREMENT PRIMARY KEY NOT NULL,
    ID INTEGER(5) DEFAULT 0,
    Width INTEGER(4) DEFAULT 250,
    Height INTEGER(4) DEFAULT 500,
    X INTEGER(4) DEFAULT 0,
    Y INTEGER(4) DEFAULT 0,
    Opacity DOUBLE  DEFAULT 0.7,
    Angle DOUBLE  DEFAULT 0.0,
    ZoomFactor DOUBLE   DEFAULT 1.0,
    ButtonName VARCHAR(32) UNIQUE DEFAULT '----',
    TableName VARCHAR(32) DEFAULT 'GetTicketMachine.ButtonInfo',
    FunctionCode VARCHAR(4) DEFAULT '----',
    InsertStaff VARCHAR(4) DEFAULT '----',
    InsertDate DATE DEFAULT '1970-01-01',
    InsertTime TIME DEFAULT '00:00:00'
);

INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, X, Y, Width, Height, FunctionCode) VALUES (1, 0, 'ButtonRun1', 50 ,162, 579, 756, 'A001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, X, Y, Width, Height, FunctionCode) VALUES (2, 1, 'ButtonRun2', 673 ,162, 579, 756, 'B001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, X, Y, Width, Height, FunctionCode) VALUES (3, 2, 'ButtonRun3', 1296 ,162, 579, 756, 'C001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, X, Y, Width, Height, FunctionCode) VALUES (4, 3, 'ButtonRun4', 50 ,162, 579, 756, 'D001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, X, Y, Width, Height, FunctionCode) VALUES (5, 4, 'ButtonRun5', 673 ,162, 579, 756, 'E001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, X, Y, Width, Height, FunctionCode) VALUES (6, 5, 'ButtonRun6', 1296 ,162, 579, 756, 'F001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, X, Y, Width, Height, FunctionCode) VALUES (7, 6, 'ButtonRun7', 50 ,162, 579, 756, 'G001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, X, Y, Width, Height, FunctionCode) VALUES (8, 7, 'ButtonRun8', 673 ,162, 579, 756, 'H001');
INSERT INTO GetTicketMachine.ButtonInfo(PrimaryKey, ID, ButtonName, X, Y, Width, Height, FunctionCode) VALUES (9, 8, 'ButtonRun9', 1296 ,162, 579, 756, 'I001');

DROP TABLE IF EXISTS GetTicketMachine.CountInfo;

CREATE TABLE GetTicketMachine.CountInfo(
    PrimaryKey INTEGER(1) AUTO_INCREMENT PRIMARY KEY,
    Counts INTEGER(2) DEFAULT 3,
    Property VARCHAR(10) DEFAULT '----',
    TableName VARCHAR(32) DEFAULT 'GetTicketMachine.CountInfo',
    InsertStaff VARCHAR(4) DEFAULT '----',
    InsertDate DATE DEFAULT '1970-01-01',
    InsertTime TIME DEFAULT '00:00:00'
);

INSERT INTO GetTicketMachine.CountInfo (PrimaryKey, Counts, Property) VALUES (1, 3, 'Counts');
INSERT INTO GetTicketMachine.CountInfo (PrimaryKey, Counts, Property) VALUES (2, 2, 'ViewFont');
INSERT INTO GetTicketMachine.CountInfo (PrimaryKey, Counts, Property) VALUES (3, 1, 'ViewImage');

DROP TABLE IF EXISTS GetTicketMachine.FontInfo;

CREATE TABLE GetTicketMachine.FontInfo(
    PrimaryKey INTEGER(1) AUTO_INCREMENT PRIMARY KEY,
    FontName VARCHAR(56) DEFAULT 'Times New Roman',
    FontCode VARCHAR(4) DEFAULT 'E001',
    Property VARCHAR(10) DEFAULT '----',
    TableName VARCHAR(32) DEFAULT 'GetTicketMachine.FontInfo',
    InsertStaff VARCHAR(4) DEFAULT '----',
    InsertDate DATE DEFAULT '1970-01-01',
    InsertTime TIME DEFAULT '00:00:00'
);

INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (1, 'E001', 'Consolas');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (2, 'E002', 'Segoe Print');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (3, 'E003', 'Segoe Script');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (4, 'E004', 'Serif');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (5, 'E005', 'Times New Roman');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (6, 'C001', '細明體');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (7, 'C002', '新細明體');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (8, 'C003', '標楷體');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (9, 'C004', '微軟正黑體');
INSERT INTO GetTicketMachine.FontInfo (PrimaryKey, FontCode, FontName) VALUES (10, 'C005', '文泉驛微米黑');

DROP TABLE IF EXISTS GetTicketMachine.FontTypeInfo;

CREATE TABLE GetTicketMachine.FontTypeInfo(
    PrimaryKey INTEGER(1) AUTO_INCREMENT PRIMARY KEY,
    FontTypeCode INTEGER(1) DEFAULT 0,
    FontTypeName VARCHAR(3) DEFAULT '一般',
    TableName VARCHAR(32) DEFAULT 'GetTicketMachine.FontTypeInfo',
    InsertStaff VARCHAR(4) DEFAULT '----',
    InsertDate DATE DEFAULT '1970-01-01',
    InsertTime TIME DEFAULT '00:00:00'
);

INSERT INTO GetTicketMachine.FontTypeInfo (PrimaryKey, FontTypeCode, FontTypeName) VALUES (1, 0, '一般');
INSERT INTO GetTicketMachine.FontTypeInfo (PrimaryKey, FontTypeCode, FontTypeName) VALUES (2, 1, '粗體');
INSERT INTO GetTicketMachine.FontTypeInfo (PrimaryKey, FontTypeCode, FontTypeName) VALUES (3, 2, '斜體');
INSERT INTO GetTicketMachine.FontTypeInfo (PrimaryKey, FontTypeCode, FontTypeName) VALUES (4, 3, '粗斜體');

DROP TABLE IF EXISTS GetTicketMachine.FunctionInfo;

CREATE TABLE GetTicketMachine.FunctionInfo(
    PrimaryKey INTEGER(1) AUTO_INCREMENT PRIMARY KEY,
    FunctionCode VARCHAR(4) UNIQUE DEFAULT '----',
    FunctionName VARCHAR(255) DEFAULT '----',
    RangeStart INTEGER(4) DEFAULT 0,
    RangeEnd INTEGER(4) DEFAULT 0,
    Running INTEGER(4) DEFAULT 0,
    Waitting INTEGER(4) DEFAULT 0,
    ImagesURL VARCHAR(255)  DEFAULT 'Image/BusinessTypes/1.png',
    InsertStaff VARCHAR(4) DEFAULT '----',
    InsertDate DATE DEFAULT '1970-01-01',
    InsertTime TIME DEFAULT '00:00:00'
);

INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (1, 'A001', '業務類型1', 1, 700, 0, 'Image/BusinessTypes/1.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (2, 'B001', '業務類型2', 701, 800, 700, 'Image/BusinessTypes/2.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (3, 'C001', '業務類型3', 801, 999, 800, 'Image/BusinessTypes/3.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (4, 'D001', '業務類型4', 1000, 1100, 999, 'Image/BusinessTypes/4.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (5, 'E001', '業務類型5', 1101, 1200, 1100, 'Image/BusinessTypes/5.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (6, 'F001', '業務類型6', 1201, 1300, 1200, 'Image/BusinessTypes/6.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (7, 'G001', '業務類型7', 1301, 1400, 1300, 'Image/BusinessTypes/7.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (8, 'H001', '業務類型8', 1401, 1500, 1400, 'Image/BusinessTypes/8.png');
INSERT INTO GetTicketMachine.FunctionInfo (PrimaryKey, FunctionCode, FunctionName, RangeStart, RangeEnd, Running, ImagesURL) VALUES (9, 'I001', '業務類型9', 1501, 1600, 1500, 'Image/BusinessTypes/9.png');

DROP TABLE IF EXISTS GetTicketMachine.StatusInfo;

CREATE TABLE GetTicketMachine.StatusInfo(
    PrimaryKey INTEGER(1) AUTO_INCREMENT PRIMARY KEY,
    StatusCode VARCHAR(10) NOT NULL,
    StatusName VARCHAR(32) NOT NULL,
    InsertStaff VARCHAR(4) DEFAULT '----',
    InsertDate DATE DEFAULT '1970-01-01',
    InsertTime TIME DEFAULT '00:00:00'
);

INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (1, 'OK', '處理完畢');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (2, 'Doing', '處理中');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (3, '----', '未處理');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (4, 'Transfer', '轉櫃');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (5, 'Others', '其它');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (6, '----', '----');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (7, '----', '----');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (8, '----', '----');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (9, '----', '----');

DROP TABLE IF EXISTS GetTicketMachine.TicketInfo;

CREATE TABLE GetTicketMachine.TicketInfo(
    PrimaryKey INTEGER(5) AUTO_INCREMENT PRIMARY KEY,
    Numer INTEGER(5) NOT NULL,
    Status VARCHAR(4) NOT NULL DEFAULT '----',
    TableName VARCHAR(32) DEFAULT 'GetTicketMachine.TicketInfo',
    FunctionCode VARCHAR(4) DEFAULT '----',
    InsertDate DATE DEFAULT '1970-01-01',
    InsertTime TIME DEFAULT '00:00:00'
);

DROP TABLE IF EXISTS GetTicketMachine.ViewFontInfo;

CREATE TABLE GetTicketMachine.ViewFontInfo(
    PrimaryKey INTEGER(2) AUTO_INCREMENT PRIMARY KEY,
    X INTEGER(4) DEFAULT 0,
    Y INTEGER(4) DEFAULT 0,
    Sizes INTEGER(2) DEFAULT 12,
    TypeCode INTEGER(1) DEFAULT 0,
    Texts VARCHAR(255) DEFAULT '----',
    FontName VARCHAR(255) DEFAULT '----',
    ColorRGB VARCHAR(12) DEFAULT '0,0,0',
    BackgroundColorRGB VARCHAR(12) DEFAULT '255,255,255',
    TableName VARCHAR(32) DEFAULT 'GetTicketMachine.ViewFontInfo',
    Property VARCHAR(15) DEFAULT '----',
    ViewFontName VARCHAR(10) UNIQUE DEFAULT '----',
    InsertStaff VARCHAR(4) DEFAULT '----',
    InsertDate DATE DEFAULT '1970-01-01',
    InsertTime TIME DEFAULT '00:00:00'
);

INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (1, '28934823', 'Number', 'ViewFont1', '25', '90', '30');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (2, '2014-10-10 12:00:00', 'Time', 'ViewFont2', '30', '240', '14');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (3, '業務類型', 'BusinessTypes', 'ViewFont3', '58', '65', '14');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (4, '大鑫資訊股份有限公司', '----', 'ViewFont4', '25', '10', '14');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (5, '新北市新店區民權路104號4樓', '----', 'ViewFont5', '10', '135', '12');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (6, 'TEL:02-2218-1199', '----', 'ViewFont6', '30', '165', '14');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (7, 'FAX:02-2218-2255', '----', 'ViewFont7', '30', '185', '14');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (8, '銀行、辦公耗材第一選擇', '----', 'ViewFont8', '15', '36', '14');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (9, 'http://safewayoa.myweb.hinet.net/', '----', 'ViewFont9', '15', '205', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (10, 'http://www.pcstore.com.tw/taiwan100/', '----', 'ViewFont10', '5', '220', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (11, '-----備用1-----', '----', 'ViewFont11', '5', '350', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (12, '-----備用2-----', '----', 'ViewFont12', '5', '365', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (13, '-----備用3-----', '----', 'ViewFont13', '5', '380', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (14, '-----備用4-----', '----', 'ViewFont14', '5', '395', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (15, '-----備用5-----', '----', 'ViewFont15', '5', '410', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (16, '-----備用6-----', '----', 'ViewFont16', '5', '425', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (17, '-----備用7-----', '----', 'ViewFont17', '5', '440', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (18, '-----備用8-----', '----', 'ViewFont18', '5', '455', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (19, '-----備用9-----', '----', 'ViewFont19', '5', '470', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (20, '-----備用10-----', '----', 'ViewFont20', '5', '485', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (21, '-----備用11-----', '----', 'ViewFont21', '90', '350', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (22, '-----備用12-----', '----', 'ViewFont22', '90', '365', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (23, '-----備用13-----', '----', 'ViewFont23', '90', '380', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (24, '-----備用14-----', '----', 'ViewFont24', '90', '395', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (25, '-----備用15-----', '----', 'ViewFont25', '90', '410', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (26, '-----備用16-----', '----', 'ViewFont26', '90', '425', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (27, '-----備用17-----', '----', 'ViewFont27', '90', '440', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (28, '-----備用18-----', '----', 'ViewFont28', '90', '455', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (29, '-----備用19-----', '----', 'ViewFont29', '90', '470', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (30, '-----備用20-----', '----', 'ViewFont30', '90', '485', '10');

DROP TABLE IF EXISTS GetTicketMachine.ViewImageInfo;

CREATE TABLE GetTicketMachine.ViewImageInfo(
    PrimaryKey INTEGER(2) AUTO_INCREMENT PRIMARY KEY,
    X INTEGER(4) DEFAULT 0,
    Y INTEGER(4) DEFAULT 0,
    Paths VARCHAR(255) DEFAULT 'Image/TicketInfo/1.png',
    TableName VARCHAR(36) DEFAULT 'GetTicketMachine.ViewImageInfo',
    Property VARCHAR(10) DEFAULT '----',
    ViewImageName VARCHAR(15) UNIQUE DEFAULT '----',
    InsertStaff VARCHAR(4) DEFAULT '----',
    InsertDate DATE DEFAULT '1970-01-01',
    InsertTime TIME DEFAULT '00:00:00'
);

INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (1, 'Image/TicketInfo/1.png', 75, 295, 'Logo', 'ViewImage1');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (2, 'Image/TicketInfo/2.png', 75, 330, 'Advertise', 'ViewImage2');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (3, 'Image/TicketInfo/3.png', 75, 365, 'QR-Code', 'ViewImage3');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (4, 'Image/TicketInfo/4.png', 110, 295, '----', 'ViewImage4');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (5, 'Image/TicketInfo/5.png', 110, 330, '----', 'ViewImage5');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (6, 'Image/TicketInfo/6.png', 110, 365, '----', 'ViewImage6');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (7, 'Image/TicketInfo/7.png', 145, 295, '----', 'ViewImage7');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (8, 'Image/TicketInfo/8.png', 145, 330, '----', 'ViewImage8');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (9, 'Image/TicketInfo/9.png', 145, 365, '----', 'ViewImage9');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (10, 'Image/TicketInfo/10.png', 145, 365, '----', 'ViewImage10');
