package com.safewayoa.GetTicketMachine_InitialDB.Data.Model;

import com.safewayoa.Tools.Utility.RecordLogger;
import java.util.logging.Logger;

public class LoggerInfo {

    public static final Logger loggerInfo = RecordLogger.setLoggerHanlder(Logger.getLogger("com.safewayoa"), "InitialDB");
}
