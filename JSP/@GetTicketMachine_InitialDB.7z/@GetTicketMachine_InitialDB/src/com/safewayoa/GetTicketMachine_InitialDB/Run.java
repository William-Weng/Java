package com.safewayoa.GetTicketMachine_InitialDB;

import com.safewayoa.GetTicketMachine_InitialDB.Data.Model.FunctionInfo;
import com.safewayoa.GetTicketMachine_InitialDB.Data.Model.LoggerInfo;
import com.safewayoa.GetTicketMachine_InitialDB.Data.Model.TicketInfo;
import com.safewayoa.Tools.MySQL.DatabaseUtility;
import com.safewayoa.Tools.Utility.ProcessArray;
import java.awt.Dimension;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class Run extends Application {

    boolean isConn;

    int widthAll, heightAll;

    Integer[] functionRangeStart;
    String[] functionName, functionCode;

    ChoiceBox[] choiceBoxSetup;
    Label[] labelChoiceBoxSetup;
    Button[] buttonChoiceBoxSetup;

    Dimension screenSize; // 取得螢幕解晰度大小
    Group root; // 畫面的根
    Scene scene; // 底層
    Tooltip tooltip; // 文字輸入提示框

    DatabaseUtility utilDB;
    FunctionInfo[] functionInfo;

    @Override
    public void start(Stage primaryStage) {

        root = new Group();
        scene = new Scene(root);

        utilDB = new DatabaseUtility();
        isConn = utilDB.connSQL();

        LoggerInfo.loggerInfo.info("程式正常開啟");

        initNumber();
        initLabelBackground();
        initLabelFrame();

        if (isConn) {
            initChoiceBoxSetup();
            initButtonSetup();
        }

        primaryStage.setTitle("資料庫初始化");
        primaryStage.setWidth(widthAll);
        primaryStage.setHeight(heightAll);
        primaryStage.setScene(scene);
        // primaryStage.setResizable(false);
        // primaryStage.setFullScreen(true);
        primaryStage.show();
    }

    //----------初始化底圖----------//
    private void initLabelBackground() {

        Label labelBackground;
        labelBackground = new Label();
        Image imageBackground;
        String imagePath = "Image/SQL/Background.jpg";

        File files = new File("src/" + imagePath); // 測試檔案是否存在

        //System.out.println("files.exists ? " + files.exists());
        if (files.exists()) {
            imageBackground = new Image(files.toURI().toString());
            System.out.println(files.toURI().toString());
        } else {
            imageBackground = new Image(this.getClass().getResourceAsStream("Data/Image/SQL/Background.jpg"));
        }
//        img = new Image(imagePath);
//        imageBackground = new Image(this.getClass().getResourceAsStream("Data/Image/BusinessTypes/Background.jpg"));
        labelBackground.setGraphic(new ImageView(imageBackground));

        root.getChildren().add(labelBackground);
    }

    private void initLabelFrame() {

        Label labelFrame;
        Image imageError = new Image(this.getClass().getResourceAsStream("Data/Image/BusinessTypes/Error.png"));

        String styleLabelPaper = "-fx-background-color:rgba(0, 0, 0, 0.3);";
        int[] coordinateLabelLabelFrame = {10, 10};

        labelFrame = new Label();
        labelFrame.setId("LabelFrame");
        labelFrame.setLayoutX(coordinateLabelLabelFrame[0]);
        labelFrame.setLayoutY(coordinateLabelLabelFrame[1]);
        labelFrame.setMinWidth(680);
        labelFrame.setMinHeight(320);
        labelFrame.setStyle(styleLabelPaper);

        if (!isConn) {
            labelFrame.setGraphic(new ImageView(imageError));
        }
        root.getChildren().add(labelFrame);
    }

    private void initNumber() {

        scene.setFill(Color.rgb(50, 200, 50, 0.5));
//        screenSize = Toolkit.getDefaultToolkit().getScreenSize();
//        widthAll = screenSize.width * 2 / 3; // 1920 * 1080
//        heightAll = screenSize.height * 2 / 3;

        widthAll = 720; // 1920 * 1080
        heightAll = 400;

        LoggerInfo.loggerInfo.info("初始化數據…");
    }

    private void initSQL() {

        String pathSQL = "com/safewayoa/GetTicketMachine_InitialDB/Data/Text/SQL/AllInOne.sql";
        ProcessArray processArray = new ProcessArray();
        StringBuffer stringBuffer = processArray.ReadSQLStream(pathSQL);

        String[] strSQL = stringBuffer.toString().split(";");

        for (String strSQL1 : strSQL) {
            utilDB.createDB(strSQL1);
        }

        LoggerInfo.loggerInfo.info("初始化資料庫…");
    }

    private void initFunctionInfo() {

        String pathSQL = "com/safewayoa/GetTicketMachine_InitialDB/Data/Text/SQL/FunctionInfo.sql";
        ProcessArray processArray = new ProcessArray();
        StringBuffer stringBuffer = processArray.ReadSQLStream(pathSQL);

        String[] strSQL = stringBuffer.toString().split(";");

        for (String strSQL1 : strSQL) {
            utilDB.createDB(strSQL1);
        }
        LoggerInfo.loggerInfo.info("初始化資料庫…");
    }

    private void initTicketInfo() {

        String pathSQL = "com/safewayoa/GetTicketMachine_InitialDB/Data/Text/SQL/TicketInfo.sql";
        ProcessArray processArray = new ProcessArray();
        StringBuffer stringBuffer = processArray.ReadSQLStream(pathSQL);

        String[] strSQL = stringBuffer.toString().split(";");

        for (String strSQL1 : strSQL) {
            utilDB.createDB(strSQL1);
        }
        LoggerInfo.loggerInfo.info("初始化資料庫…");
    }

    private void initButtonSetup() {

        Button[] buttonSetup;
        buttonSetup = new Button[3];

        int[] sizes = {200, 100};
        int[] gapAll = {50, 10, 200, 100};

        String[][] buttonSetupText = {{"InitialDB", "新建資料"}, {"ToZero", "全數歸零"}, {"Exit", "離開程式"}};
        int[][] size = {{sizes[0], sizes[1]}, {sizes[0], sizes[1]}, {sizes[0], sizes[1]}};
        int[][] coordinate = {{25, gapAll[2]}, {25 * 2 + sizes[0], gapAll[2]}, {25 * 3 + sizes[0] * 2, gapAll[2]}}; // 將下方設定的按鈕置

        for (int i = 0; i < buttonSetup.length; i++) {

            buttonSetup[i] = new Button();
            buttonSetup[i].setPrefSize(size[i][0], size[i][1]); // 設定最佳大小
            buttonSetup[i].setId(buttonSetupText[i][0]);
            buttonSetup[i].setContentDisplay(ContentDisplay.TOP);
            buttonSetup[i].setAlignment(Pos.CENTER);
            buttonSetup[i].setText(buttonSetupText[i][1]);
            buttonSetup[i].setTextFill(Color.rgb(255, 0, 0, 0.7)); // 顏色(R,G,B,透明度)
            buttonSetup[i].setOpacity(0.7); // 透明度
            buttonSetup[i].setFont(Font.font("Verdana", 20)); // (字型, 大小)
            buttonSetup[i].setTranslateX(coordinate[i][0]);
            buttonSetup[i].setTranslateY(coordinate[i][1]);
            // buttonSetup[i].setEffect(new Reflection()); // 設定特效：反射
            buttonSetup[i].addEventHandler(ActionEvent.ACTION, new EventHandlerButtonSetup_ACTION());

            root.getChildren().add(buttonSetup[i]);
        }

        LoggerInfo.loggerInfo.info("初始化按鈕…");
    }

    private void initChoiceBoxSetup() {

        choiceBoxSetup = new ChoiceBox[2];
        labelChoiceBoxSetup = new Label[choiceBoxSetup.length];
        buttonChoiceBoxSetup = new Button[choiceBoxSetup.length];
        functionInfo = new FunctionInfo[choiceBoxSetup.length];

        int[] sizes_ChoiceBoxSetup = {200, 36};
        int[] sizes_ButtonChoiceBoxSetup = {200, 36};

        int[] coordinate_ChoiceBoxSetup = {25, 50};

        int gap = 250;

        String[][] nameChoiceBox = {{"Running", "目前號碼：？"}, {"Waitting", "等待人數：？"}};
        String[][] nameButton = {{"Zero_Running", "歸零"}, {"Zero_Waitting", "歸零"}};

        List<String> _listName = new ArrayList();
        List<String> _listCode = new ArrayList();
        List<Integer> _listStart = new ArrayList();

        List<FunctionInfo> fontName_list;
        fontName_list = utilDB.selectFunctionInfo(new FunctionInfo());

        for (int i = 0; i < fontName_list.size(); i++) {
            _listName.add(fontName_list.get(i).getFunctionName());
            _listCode.add(fontName_list.get(i).getFunctionCode());
            _listStart.add(fontName_list.get(i).getRangeStart());
        } // 加強一下

        functionName = _listName.toArray(new String[0]); // 功能名稱
        functionCode = _listCode.toArray(new String[0]); // 功能代碼
        functionRangeStart = _listStart.toArray(new Integer[0]); // 功能號碼起始點

        for (int i = 0; i < choiceBoxSetup.length; i++) {

            choiceBoxSetup[i] = new ChoiceBox(FXCollections.observableArrayList(functionName));
            choiceBoxSetup[i].setId(nameChoiceBox[i][0]);
            choiceBoxSetup[i].setLayoutX(coordinate_ChoiceBoxSetup[0]);
            choiceBoxSetup[i].setLayoutY(coordinate_ChoiceBoxSetup[1] + 50 * i);
            choiceBoxSetup[i].setPrefSize(sizes_ChoiceBoxSetup[0], sizes_ChoiceBoxSetup[1]);
            choiceBoxSetup[i].addEventHandler(ActionEvent.ACTION, new EventHandlerChoiceBoxSetup_ACTION());

            labelChoiceBoxSetup[i] = new Label();
            labelChoiceBoxSetup[i].setText(nameChoiceBox[i][1]);
            labelChoiceBoxSetup[i].setFont(Font.font("Verdana", 20));
            labelChoiceBoxSetup[i].setTextFill(Color.rgb(0, 0, 0, 1.0));
            labelChoiceBoxSetup[i].setTextAlignment(TextAlignment.LEFT);
            labelChoiceBoxSetup[i].setLayoutX(coordinate_ChoiceBoxSetup[0] + gap);
            labelChoiceBoxSetup[i].setLayoutY(coordinate_ChoiceBoxSetup[1] + 50 * i);

            buttonChoiceBoxSetup[i] = new Button();
            buttonChoiceBoxSetup[i].setPrefSize(sizes_ButtonChoiceBoxSetup[0], sizes_ButtonChoiceBoxSetup[1]); // 設定最佳大小
            buttonChoiceBoxSetup[i].setId(nameButton[i][0]);
            buttonChoiceBoxSetup[i].setContentDisplay(ContentDisplay.TOP);
            buttonChoiceBoxSetup[i].setAlignment(Pos.CENTER);
            buttonChoiceBoxSetup[i].setText(nameButton[i][1]);
            buttonChoiceBoxSetup[i].setTextFill(Color.rgb(255, 0, 0, 0.8)); // 顏色(R,G,B,透明度)
            buttonChoiceBoxSetup[i].setOpacity(0.7); // 透明度
            buttonChoiceBoxSetup[i].setFont(Font.font("Verdana", 20)); // (字型, 大小)
            buttonChoiceBoxSetup[i].setTranslateX(coordinate_ChoiceBoxSetup[0] + gap + 200);
            buttonChoiceBoxSetup[i].setTranslateY(coordinate_ChoiceBoxSetup[1] + 50 * i);
            buttonChoiceBoxSetup[i].addEventHandler(ActionEvent.ACTION, new EventHandlerButtonChoiceBoxSetup_ACTION());

            functionInfo[i] = new FunctionInfo();
            functionInfo[i].setFunctionCode(functionCode[0]);

            root.getChildren().add(choiceBoxSetup[i]);
            root.getChildren().add(labelChoiceBoxSetup[i]);
            root.getChildren().add(buttonChoiceBoxSetup[i]);
        }

        LoggerInfo.loggerInfo.info("初始化下拉式選單…");

    }

    public class EventHandlerChoiceBoxSetup_ACTION implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent e) {

            ChoiceBox _choiceBoxSetup = (ChoiceBox) e.getSource();
            String choiceBoxName = _choiceBoxSetup.getId();
            FunctionInfo _functionInfo;
            TicketInfo _ticketInfo = new TicketInfo();

            utilDB.connSQL();

            switch (choiceBoxName) { // 利用名字做分類

                case "Running":
                    functionInfo[0].setFunctionCode(functionCode[_choiceBoxSetup.getSelectionModel().getSelectedIndex()]);
                    _functionInfo = utilDB.selectFunctionInfoOne(functionInfo[0]);

                    labelChoiceBoxSetup[0].setText("目前號碼：" + _functionInfo.getRunning());
                    //System.out.println("Running");
                    break;

                case "Waitting":
                    functionInfo[1].setFunctionCode(functionCode[_choiceBoxSetup.getSelectionModel().getSelectedIndex()]);
                    _functionInfo = utilDB.selectFunctionInfoOne(functionInfo[1]);
                    _ticketInfo.setFunctionCode(functionInfo[1].getFunctionCode());
                    utilDB.deleteTicketInfo(_ticketInfo);

                    labelChoiceBoxSetup[1].setText("等待人數：" + _functionInfo.getWaitting());
                    //System.out.println("Waitting");
                    break;

                default:
                    utilDB.closeSQL();
                    break;
            }
        }
    }

    public class EventHandlerButtonSetup_ACTION implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent e) {

            Button _buttonSetup = (Button) e.getSource();
            String buttonName = _buttonSetup.getId();

            switch (buttonName) { // 利用名字做分類

                case "InitialDB":
                    initSQL();
                    //System.out.println("InitialDB");
                    break;

                case "ToZero":
                    initFunctionInfo();
                    initTicketInfo();
                    //System.out.println("ToZero");
                    break;

                case "Exit":
                    LoggerInfo.loggerInfo.info("程式正常關閉");
                    System.exit(0);
                    break;

                default:
                    break;
            }
        }
    }

    public class EventHandlerButtonChoiceBoxSetup_ACTION implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent e) {

            Button _buttonChoiceBoxSetup = (Button) e.getSource();
            String buttonName = _buttonChoiceBoxSetup.getId();
            utilDB.connSQL();

            switch (buttonName) { // 利用名字做分類

                case "Zero_Running":
                    int ID = getRangeStartID(functionInfo[0].getFunctionCode());
                    functionInfo[0].setRunning(functionRangeStart[ID] - 1); // 從零開始算
                    utilDB.updateFunctionInfo_Running(functionInfo[0]);
                    //System.out.println("Zero_Running");
                    break;

                case "Zero_Waitting":
                    functionInfo[1].setWaitting(0);
                    utilDB.updateFunctionInfo_Waitting(functionInfo[1]);
                    //System.out.println("Zero_Waitting");
                    break;

                default:
                    utilDB.closeSQL();
                    break;
            }
        }
    }

    public int getRangeStartID(String code) {

        int ID = 0;

        for (int i = 0; i < functionCode.length; i++) {
            if (functionCode[i].equals(code)) {
                ID = i;
                break;
            }
        }
        //System.out.println("ID = " + ID);

        return ID;
    }

    //----------結束----------//
    public static void main(String[] args) {
        launch(args);
    }
}
