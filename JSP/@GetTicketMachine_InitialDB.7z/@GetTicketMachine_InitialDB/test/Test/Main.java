package Test;

import com.safewayoa.Tools.MySQL.DatabaseUtility;
import com.safewayoa.Tools.Utility.ProcessArray;

public class Main {

    public static void main(String[] args) {

        DatabaseUtility utilDB = new DatabaseUtility();
        utilDB.connSQL();

        ProcessArray processArray = new ProcessArray();
        StringBuffer stringBuffer = processArray.ReadSQLStream("com/safewayoa/GetTicketMachine_InitialDB/Data/MySQL/ToZero.sql");

        String[] strSQL = stringBuffer.toString().split(";");

        for (int i = 0; i < strSQL.length; i++) {
            utilDB.createDB(strSQL[i]);
        }
    }
}
