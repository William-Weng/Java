package William.Data.Model;

public class SQLConnentInfo {

    private String port; // 資料庫連接的網路位置跟埠…
    private String databaseName; // 連接的資料庫名稱…
    private String user; // 帳號…
    private String password; // 密碼…
    private String driver; // 驅動程式…
    private String url; // 連接語法、編碼…

    //--------------------[初始化變數]--------------------//
    public SQLConnentInfo() {
        this.port = "localhost:3306";
        this.databaseName = "Money7988";
        this.user = "william";
        this.password = "19790609";
        this.driver = "com.mysql.jdbc.Driver";
        this.url = "jdbc:mysql://" + this.port + "/" + this.databaseName + "?useUnicode=true&characterEncoding=UTF8"; // 連接語法、編碼…
    }

    //--------------------[自定義輸出格式]--------------------//
    @Override
    public String toString() {
        String _tab = "\t";
        String _str = this.port + _tab + this.databaseName + _tab + this.user + _tab + this.password + _tab + this.driver + _tab + this.url;
        return _str;
    }

    //--------------------[設定、取值]--------------------//
    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getdatabaseName() {
        return databaseName;
    }

    public void setTableName(String databaseName) {
        this.databaseName = databaseName;
    }

    public String getUser() {
        return user;
    }

    public String setUser(String user) {
        return this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDriver() {
        return driver;
    }

    public void setDriver(String driver) {
        this.driver = driver;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
    //--------------------[結束]--------------------//
}
