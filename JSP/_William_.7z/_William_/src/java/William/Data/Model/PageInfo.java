package William.Data.Model;

import William.Tools.SQL.DatabaseUtility;

public class PageInfo {

    private int count; // 總筆數
    private int limit; // 一頁有幾筆
    private int page; // 在第幾頁
    private int paging; // 共幾個分頁
    private int start; // 從第幾筆開始
    private String tableName; // 資料表名

    //--------------------[初始化變數]--------------------//
    public PageInfo() {
    }

    public PageInfo(String tableName, int page, int limit) {

        DatabaseUtility utilDB = new DatabaseUtility();

        this.count = utilDB.select_Count(tableName);

        if (limit < 0) { // 如果是負值的話，就一次取10筆
            this.limit = 10;
        } else {
            this.limit = limit;
        }

        if (page < 1) { // 最小就是1頁
            this.page = 1;
        } else {
            this.page = page;
        }

        if (this.count % this.limit == 0) { // 如果有餘數的話，就再加1頁
            this.paging = this.count / this.limit;
        } else {
            this.paging = this.count / this.limit + 1;
        }

        this.start = (this.page - 1) * this.limit; // 從第幾筆開始
        this.tableName = tableName;
    }

    //--------------------[自定義輸出格式]--------------------//
    @Override
    public String toString() {
        String _tab = "\t";
        String _str = this.getCount() + _tab + this.getLimit() + _tab + this.getPage() + _tab + this.getPaging() + _tab + this.getStart() + _tab + this.getTableName();
        return _str;
    }

    //--------------------[設定、取值]--------------------//
    public int getCount() {
        return count;
    }

    public int getLimit() {
        return limit;
    }

    public int getPage() {
        return page;
    }

    public int getPaging() {
        return paging;
    }

    public int getStart() {
        return start;
    }

    public String getTableName() {
        return tableName;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public void setPaging(int paging) {
        this.paging = paging;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
    //--------------------[結束]--------------------//
}
