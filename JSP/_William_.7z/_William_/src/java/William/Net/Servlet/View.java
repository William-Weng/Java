package William.Net.Servlet;

import William.Data.Model.PageInfo;
import William.Tools.SQL.DatabaseUtility;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@WebServlet(urlPatterns = {"/hello.view"})

public class View extends HttpServlet implements Serializable {

    private List<PageInfo> list_PageInfo;

    String start = "{";
    String end = "}";
    String colon = ":";
    String comma = ",";
    String name, password;

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        name = request.getParameter("name");
        password = request.getParameter("password");

        if (name.equalsIgnoreCase("root") && password.equalsIgnoreCase("1234")) {
            this.getJSON(response);
            response.setStatus(HttpServletResponse.SC_OK);
        } else {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            out.write("帳號、密碼錯誤… (╥﹏╥)");
        }
        System.out.println(response.getStatus());
    }

    public void getJSON(HttpServletResponse response) throws ServletException, IOException {

        DatabaseUtility utilDB;
        PageInfo _pageInfo = new PageInfo();

        String guestInfoPlusName = "\"" + _pageInfo.getTableName() + "\"";

        try (PrintWriter out = response.getWriter()) {

            utilDB = new DatabaseUtility();
            list_PageInfo = utilDB.select_All(_pageInfo);

            JSONArray array = new JSONArray();

            out.write(start + guestInfoPlusName + colon);

            for (PageInfo bean : list_PageInfo) {

                JSONObject obj = new JSONObject();

                try {

                    obj.put("Count", bean.getCount());
                    obj.put("Page", bean.getPage());

                } catch (JSONException e) {
                    System.out.println("｡ﾟヽ(ﾟ´Д`)ﾉﾟ｡ 《" + _pageInfo.getTableName() + "》資料庫帳號、密碼錯誤…");
                    System.out.println("Σ(*ﾟдﾟﾉ)ﾉ 錯誤訊息：" + e.toString());
                }
                array.put(obj);
            }

            out.write(array.toString() + end);
            out.flush();
        }
    }
}
