DROP DATABASE IF EXISTS `DB`; -- 刪除資料庫

DROP TABLE IF EXISTS `DB`.`Table`; -- 刪除資料表

CREATE DATABASE `DB`; -- 建立資料庫

CREATE TABLE `DB`.`Table` ( -- 建立資料表
    `ID` INTEGER(10) PRIMARY KEY AUTO_INCREMENT NOT NULL , -- 流水號
    `Text` VARCHAR(20) NOT NULL DEFAULT '----', -- 文字
    `Stock` DECIMAL(12,4) NOT NULL DEFAULT 0 , -- 小數
    `Time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP -- 時間
    );

INSERT INTO `DB`.`Table` (`Stock`, `Text`) VALUES ('123456.1234', '測試用'); -- 新增數據
