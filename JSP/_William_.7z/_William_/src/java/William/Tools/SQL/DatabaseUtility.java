package William.Tools.SQL;

import William.Data.Model.PageInfo;
import William.Data.Model.SQLConnentInfo;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DatabaseUtility implements Serializable {

    private Connection conn;
    private Statement stat;
    private ResultSet rs;
    private PreparedStatement pst;
    private final SQLConnentInfo infoSQL;

    //--------------------[開啟資料庫連線]--------------------//
    public DatabaseUtility() {

        this.setNull_All();

        infoSQL = new SQLConnentInfo();

        try {

            Class.forName(infoSQL.getDriver());
            conn = DriverManager.getConnection(infoSQL.getUrl(), infoSQL.getUser(), infoSQL.getPassword());

            if (conn != null && !conn.isClosed()) {
                System.out.println("d(`･∀･)b 《" + infoSQL.getdatabaseName() + "》資料庫連線測試成功…");
            }

        } catch (ClassNotFoundException eNotFound) {

            System.out.println("｡ﾟヽ(ﾟ´Д`)ﾉﾟ｡ 《" + infoSQL.getdatabaseName() + "》資料庫驅動程式出錯…");
            System.out.println("Σ(*ﾟдﾟﾉ)ﾉ 錯誤訊息：" + eNotFound.toString());

        } catch (SQLException eSQL) {

            System.out.println("｡ﾟヽ(ﾟ´Д`)ﾉﾟ｡ 《" + infoSQL.getdatabaseName() + "》資料庫帳號、密碼錯誤…");
            System.out.println("Σ(*ﾟдﾟﾉ)ﾉ 錯誤訊息：" + eSQL.toString());
        }
    }

    //--------------------[關閉資料庫連線]--------------------//
    private void closeSQL() {

        try {

            if (rs != null) {
                rs.close();
                rs = null;
            }
            if (stat != null) {
                stat.close();
                stat = null;
            }
            if (pst != null) {
                pst.close();
                pst = null;
            }

            System.out.println("d(`･∀･)b 《" + infoSQL.getdatabaseName() + "》資料庫連線關閉成功");

        } catch (SQLException e) {

            System.out.println("｡ﾟヽ(ﾟ´Д`)ﾉﾟ｡ 《" + infoSQL.getdatabaseName() + "》資料庫連線關閉失敗…");
            System.out.println("Σ(*ﾟдﾟﾉ)ﾉ 錯誤訊息：" + e.toString());

        }
    }

    //--------------------[清空資料庫連線]--------------------//
    private void setNull_All() {

        conn = null;
        stat = null;
        rs = null;
        pst = null;

    }

    //--------------------[新增頁數資訊→單筆]--------------------//
    public void insert_One(PageInfo pageInfo) {

        String insertSQL = "INSERT INTO " + pageInfo.getTableName() + " (Count, Limit) VALUES (?, ?)";

        try {

            pst = conn.prepareStatement(insertSQL); // 執行參數化查詢

            pst.setInt(1, pageInfo.getCount()); // 設定各參數
            pst.setInt(2, pageInfo.getLimit());

            pst.executeUpdate(); // 執行SQL語句

            System.out.println("d(`･∀･)b 《" + pageInfo.getTableName() + "》資料新增成功…");

        } catch (SQLException e) {

            System.out.println("｡ﾟヽ(ﾟ´Д`)ﾉﾟ｡ 《" + pageInfo.getTableName() + "》資料新增失敗…");
            System.out.println("Σ(*ﾟдﾟﾉ)ﾉ 錯誤訊息：" + e.toString());

        } finally {
            closeSQL();
        }
    }

    //--------------------[修改頁數資訊→單筆]--------------------//
    public void update_One(PageInfo pageInfo) {

        String updateSQL = "UPDATE " + pageInfo.getTableName() + " SET Number = ? WHERE ID = ?";

        try {

            pst = conn.prepareStatement(updateSQL); // 執行參數化查詢

            pst.setInt(1, pageInfo.getCount()); // 設定各參數
            pst.setInt(2, pageInfo.getLimit());

            pst.executeUpdate(); // 執行SQL語句

            System.out.println("d(`･∀･)b 《" + pageInfo.getTableName() + "》資料更新成功…");

        } catch (SQLException e) {

            System.out.println("｡ﾟヽ(ﾟ´Д`)ﾉﾟ｡ 《" + pageInfo.getTableName() + "》資料表更新失敗…");
            System.out.println("Σ(*ﾟдﾟﾉ)ﾉ 錯誤訊息：" + e.toString());

        } finally {
            closeSQL();
        }
    }

    //--------------------[刪除該表資訊→單筆]--------------------//
    public void delete_One(String tableName, int ID) {

        String deleteSQL = "DELETE FROM " + tableName + " WHERE ID = ?";

        try {

            pst = conn.prepareStatement(deleteSQL); // 執行參數化查詢

            pst.setInt(1, ID); // 設定各參數

            pst.executeUpdate(); // 執行SQL語句

            System.out.println("d(`･∀･)b 《" + tableName + "》資料刪除成功…");

        } catch (SQLException e) {

            System.out.println("｡ﾟヽ(ﾟ´Д`)ﾉﾟ｡ 《" + tableName + "》資料刪除失敗…");
            System.out.println("Σ(*ﾟдﾟﾉ)ﾉ 錯誤訊息：" + e.toString());

        } finally {
            closeSQL();
        }
    }

    //--------------------[查詢頁數資訊→所有]--------------------//
    public List<PageInfo> select_All(PageInfo pageInfo) {

        pageInfo = new PageInfo();
        List<PageInfo> list = null;

        String _selectSQL = "SELECT * FROM " + pageInfo.getTableName();

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(_selectSQL);
            list = new ArrayList();

            while (rs.next()) {

                pageInfo = new PageInfo(); // 把Class資料清空

                pageInfo.setCount(rs.getInt("Count")); // 取得SQL欄位值
                pageInfo.setTableName(rs.getString("TableName"));

                list.add(pageInfo);

            }

            System.out.println("d(`･∀･)b 《" + pageInfo.getTableName() + "》資料查詢成功…");

        } catch (SQLException e) {

            System.out.println("｡ﾟヽ(ﾟ´Д`)ﾉﾟ｡ 《" + pageInfo.getTableName() + "》資料查詢失敗…");
            System.out.println("Σ(*ﾟдﾟﾉ)ﾉ 錯誤訊息：" + e.toString());

        } finally {
            closeSQL();
        }
        return list;
    }

    //--------------------[查詢頁數資訊→單筆]--------------------//
    public PageInfo select_One(PageInfo pageInfo, int ID) {

        pageInfo = new PageInfo();
        String selectSQL = "SELECT * FROM " + pageInfo.getTableName() + " WHERE ID = ?";

        try {

            pst = conn.prepareStatement(selectSQL); // 執行參數化查詢

            pst.setInt(1, ID); // 設定各參數

            pst.executeUpdate(); // 執行SQL語句

            while (rs.next()) {

                pageInfo = new PageInfo(); // 把Class資料清空

                pageInfo.setCount(rs.getInt("Count")); // 取得SQL欄位值
                pageInfo.setTableName(rs.getString("TableName"));

            }

            System.out.println("d(`･∀･)b 《" + pageInfo.getTableName() + "》資料查詢成功…");

        } catch (SQLException e) {

            System.out.println("｡ﾟヽ(ﾟ´Д`)ﾉﾟ｡ 《" + pageInfo.getTableName() + "》資料查詢失敗…");
            System.out.println("Σ(*ﾟдﾟﾉ)ﾉ 錯誤訊息：" + e.toString());

        } finally {
            closeSQL();
        }
        return pageInfo;
    }

    //--------------------[查詢資料筆數]--------------------//
    public int select_Count(String tableName) {

        int count = 0;

        String selectSQL = "SELECT COUNT(*) AS rowCount FROM " + tableName;

        try {

            stat = conn.createStatement();  // 直接執行查詢
            rs = stat.executeQuery(selectSQL); // 執行SQL語句
            rs.next(); // 指向第一個指標
            count = rs.getInt("rowCount"); // 取得SQL欄位值

            System.out.println("d(`･∀･)b 《" + tableName + "》筆數查詢成功…");

        } catch (SQLException e) {

            System.out.println("｡ﾟヽ(ﾟ´Д`)ﾉﾟ｡ 《" + tableName + "》筆數查詢失敗…");
            System.out.println("Σ(*ﾟдﾟﾉ)ﾉ 錯誤訊息：" + e.toString());

        } finally {
            closeSQL();
        }
        return count;
    }
    //--------------------[結束]--------------------//
}
