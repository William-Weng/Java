package com.safewayoa.GetTicketMachine_FontInfoDB;

import com.safewayoa.GetTicketMachine_FontInfoDB.Data.Model.FontInfo;
import com.safewayoa.GetTicketMachine_FontInfoDB.Data.Model.LoggerInfo;
import com.safewayoa.Tools.MySQL.DatabaseUtility;
import com.safewayoa.Tools.Utility.ProcessArray;
import com.safewayoa.Tools.Utility.ProcessFrame;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Toolkit;
import java.io.File;
import java.util.List;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class Run extends Application {

    boolean isConn;

    int widthAll, heightAll, gapChoiceBoxSetup, fontSizeLabelChoiceBoxSetup, nowID, nowFontSize;
    int[] gapAll;
    String nowFontName, testString;

    static String[] fontArray;

    List<String> _listString;
    List<FontInfo> _listFontInfo;

    Label labelBackground, labelFontTest, labelChoiceBoxSetup, labelTextFieldInput, labelReadBackground;
    ChoiceBox choiceBoxSetup;
    TextField textFieldInput;
    Button[] buttonSetup;
    Label[] labelRead;

    ProcessArray processArray;
    FontInfo[] fontInfo;
    DatabaseUtility utilDB;

    Dimension screenSize; // 取得螢幕解晰度大小
    Group root; // 畫面的根
    Scene scene; // 底層

    @Override
    public void start(Stage primaryStage) {

        root = new Group();
        scene = new Scene(root);

        utilDB = new DatabaseUtility();
        isConn = utilDB.connSQL();

        LoggerInfo.loggerInfo.info("程式正常開啟");

        initNumber();
        initLabelBackground();
        initLabelReadBackground();

        if (isConn) {
            initLabelFontTest();
            initFontInfo();
            initTextFieldInput();
            initButtonSetup();
            initFunctionInfo(_listFontInfo);
            initLabelRead(fontInfo);
        }

        primaryStage.setTitle("字型名稱設定");
        primaryStage.setWidth(widthAll);
        primaryStage.setHeight(heightAll);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    //----------初始化數值----------//
    private void initNumber() {

        scene.setFill(Color.rgb(50, 200, 50, 0.5));
        screenSize = Toolkit.getDefaultToolkit().getScreenSize(); // 取得當前螢幕解析度
        fontArray = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames(); // 取得當前系統所有字型名稱

//        widthAll = screenSize.width * 2 / 3; // 1920 * 1080
//        heightAll = screenSize.height * 2 / 3;
        widthAll = 870; // 1920 * 1080
        heightAll = 550;

        gapAll = new int[]{50, 100, 120, 200};
        gapChoiceBoxSetup = 90;
        fontSizeLabelChoiceBoxSetup = 20;
        nowFontSize = 26;

        nowFontName = "新細明體";
        testString = "大鑫資訊 Welcome";
        fontInfo = new FontInfo[10];

        LoggerInfo.loggerInfo.info("初始化數據成功");
    }

    //----------初始化FontInfo----------//
    private void initFontInfo() {

        processArray = new ProcessArray();
        _listString = processArray.ReadFileStream("com/safewayoa/GetTicketMachine_FontInfoDB/Data/Text/INI/FontInfo_UTF8.ini");

        for (int i = 0; i < fontInfo.length; i++) {
            fontInfo[i] = setListToFontInfoInfo(_listString.get(i));
        }
//        for (String fontArray1 : fontArray) {
//            System.out.println("fontArray = " + fontArray1);
//        }

        _listFontInfo = utilDB.selectFontInfo(new FontInfo());

        LoggerInfo.loggerInfo.info("初始化字型成功");
    }

    //----------初始化背景圖----------//
    private void initLabelBackground() {

        labelBackground = new Label();
        Image imageBackground;
        String imagePath = "Image/Font/Background.jpg";

        File files = new File("src/" + imagePath); // 測試檔案是否存在

        if (files.exists()) {
            imageBackground = new Image("file:src/" + imagePath);
        } else {
            imageBackground = new Image(this.getClass().getResourceAsStream("Data/Image/Font/Background.jpg"));
        }

        labelBackground.setGraphic(new ImageView(imageBackground));

        root.getChildren().add(labelBackground);

        LoggerInfo.loggerInfo.info("初始化背景圖成功");
    }

    private void initLabelFontTest() {

        int[] coordinateLabelFontTest = {350, gapAll[0]};
        int[] sizesLabelFontTest = {400, 30};
        String styleLabelFontTest = "-fx-background-color:rgba(0, 0, 0, 0.3);";

        labelFontTest = new Label(testString);
        labelFontTest.setFont(Font.font("Verdana", nowFontSize));
        labelFontTest.setTextFill(Color.rgb(0, 0, 0, 1.0));
        labelFontTest.setTextAlignment(TextAlignment.LEFT);
        labelFontTest.setLayoutX(coordinateLabelFontTest[0] - 10);
        labelFontTest.setLayoutY(coordinateLabelFontTest[1] - 10);
        labelFontTest.setMinWidth(sizesLabelFontTest[0] + gapAll[1]);
        labelFontTest.setMinHeight(sizesLabelFontTest[1] + 30);
        // labelFontTest.setWrapText(true);

        labelFontTest.setStyle(styleLabelFontTest);

        root.getChildren().add(labelFontTest);

        LoggerInfo.loggerInfo.info("初始化標籤成功");
    }

    //----------初始化輸入框----------//
    private void initTextFieldInput() {

        int[] sizesTextFieldInput = {200, 30};

        Tooltip tooltip = new Tooltip("請輸入您想要測試的文字…");
        textFieldInput = new TextField(testString);
        textFieldInput.setLayoutX(gapAll[1]);
        textFieldInput.setLayoutY(gapAll[0]);
        textFieldInput.setPrefSize(sizesTextFieldInput[0], sizesTextFieldInput[1]);
        textFieldInput.setTooltip(tooltip);
        textFieldInput.setOnKeyReleased(new EventHandlerTextFieldInput_OnKeyReleased());

        labelTextFieldInput = new Label("測試文字");
        labelTextFieldInput.setLayoutX(gapAll[1] - gapChoiceBoxSetup);
        labelTextFieldInput.setLayoutY(gapAll[0]);
        labelTextFieldInput.setFont(Font.font("Serif", FontWeight.BOLD, FontPosture.ITALIC, fontSizeLabelChoiceBoxSetup));

        choiceBoxSetup = new ChoiceBox(FXCollections.observableArrayList(fontArray));
        choiceBoxSetup.setId("RangeEnd");
        choiceBoxSetup.setLayoutX(gapAll[1]);
        choiceBoxSetup.setLayoutY(gapAll[0] * 2);
        choiceBoxSetup.setPrefSize(sizesTextFieldInput[0], sizesTextFieldInput[1]);
        choiceBoxSetup.addEventHandler(ActionEvent.ACTION, new EventHandlerChoiceBoxSetup_ACTION());

        labelChoiceBoxSetup = new Label("系統字型");
        labelChoiceBoxSetup.setLayoutX(gapAll[1] - gapChoiceBoxSetup);
        labelChoiceBoxSetup.setLayoutY(gapAll[0] * 2);
        labelChoiceBoxSetup.setFont(Font.font("Serif", FontWeight.BOLD, FontPosture.ITALIC, fontSizeLabelChoiceBoxSetup));

        root.getChildren().add(textFieldInput);
        root.getChildren().add(labelTextFieldInput);
        root.getChildren().add(choiceBoxSetup);
        root.getChildren().add(labelChoiceBoxSetup);

        LoggerInfo.loggerInfo.info("初始化輸入框成功");
    }

    //----------初始化按鈕----------//
    private void initButtonSetup() {

        buttonSetup = new Button[3];

        String[][] buttonSetupText = {{"Reset", "初始設定"}, {"Save", "設定完成"}, {"Exit", "離開程式"}};
        int[] sizesButtonSetup = {200, 60};
        int gapButtonSetup = 30;

        for (int i = 0; i < buttonSetup.length; i++) {
            buttonSetup[i] = new Button();
            buttonSetup[i].setPrefSize(sizesButtonSetup[0], sizesButtonSetup[1]); // 設定最佳大小
            buttonSetup[i].setId(buttonSetupText[i][0]);
            buttonSetup[i].setContentDisplay(ContentDisplay.TOP);
            buttonSetup[i].setAlignment(Pos.CENTER);
            buttonSetup[i].setText(buttonSetupText[i][1]);
            buttonSetup[i].setTextFill(Color.rgb(255, 0, 0, 0.8)); // 顏色(R,G,B,透明度)
            buttonSetup[i].setOpacity(0.7); // 透明度
            buttonSetup[i].setFont(Font.font("Verdana", 20)); // (字型, 大小)
            buttonSetup[i].setTranslateX(gapAll[1]);
            buttonSetup[i].setTranslateY(gapAll[0] * (5 + i) + gapButtonSetup * i);

            buttonSetup[i].addEventHandler(ActionEvent.ACTION, new EventHandlerButtonSetup_ACTION());

            root.getChildren().add(buttonSetup[i]);
        }
        LoggerInfo.loggerInfo.info("初始化按鈕成功");
    }

    //----------更新FunctionInfo----------//
    private void initFunctionInfo(List<FontInfo> _fontInfo) {

        for (int i = 0; i < fontInfo.length; i++) {
            fontInfo[i] = _fontInfo.get(i);
            //System.out.println("fontInfo[i] = " + fontInfo[i]);
        }
        LoggerInfo.loggerInfo.info("更新數據成功");
    }

    //----------更新上面的文字----------//
    private void initLabelRead(FontInfo[] _fontInfo) {

        labelRead = new Label[_fontInfo.length];

        int gapLabelRead = 35, fontSizes = nowFontSize;

        int[] coordinateLabelRead = {350, gapAll[2]};
        int[] sizesLabelRead = {400, 30};

        for (int i = 0; i < labelRead.length; i++) {

            labelRead[i] = new Label();
            labelRead[i].setText(_fontInfo[i].getFontName());
            labelRead[i].setFont(Font.font("Verdana", fontSizes));
            labelRead[i].setTextFill(Color.rgb(0, 0, 0, 1.0));
            labelRead[i].setTextAlignment(TextAlignment.LEFT);
            labelRead[i].setLayoutX(coordinateLabelRead[0]);
            labelRead[i].setLayoutY(coordinateLabelRead[1] + gapLabelRead * i);
            labelRead[i].setMinWidth(sizesLabelRead[0]);
            labelRead[i].setMinHeight(sizesLabelRead[1]);

            labelRead[i].addEventHandler(MouseEvent.MOUSE_PRESSED, new EventHandlerLabelRead_MOUSE_PRESSED());

            root.getChildren().add(labelRead[i]);
        }
        LoggerInfo.loggerInfo.info("更新標籤成功");
    }

    private void initLabelReadBackground() {

        int[] coordinateLabelRead = {350, gapAll[2]};
        int[] sizesLabelRead = {400, 30};
        String styleLabelRead = "-fx-background-color:rgba(0, 0, 0, 0.3);";
        Image imageError = new Image(this.getClass().getResourceAsStream("Data/Image/BusinessTypes/Error.png"));

        labelReadBackground = new Label();
        labelReadBackground.setFont(Font.font("Verdana", nowFontSize));
        labelReadBackground.setTextFill(Color.rgb(0, 0, 0, 1.0));
        labelReadBackground.setTextAlignment(TextAlignment.LEFT);
        labelReadBackground.setLayoutX(coordinateLabelRead[0] - 10);
        labelReadBackground.setLayoutY(coordinateLabelRead[1] - 10);
        labelReadBackground.setMinWidth(sizesLabelRead[0] + 100);
        labelReadBackground.setMinHeight(sizesLabelRead[1] * (fontInfo.length + 1) + 30);

        if (!isConn) {
            labelReadBackground.setGraphic(new ImageView(imageError));
        }

        labelReadBackground.setStyle(styleLabelRead);

        root.getChildren().add(labelReadBackground);

        LoggerInfo.loggerInfo.info("更新標籤成功");
    }

    //----------事件----------//
    public class EventHandlerButtonSetup_ACTION implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent e) {

            Button _buttonSetup = (Button) e.getSource();
            String buttonName = _buttonSetup.getId();

            switch (buttonName) { // 利用名字做分類

                case "Reset":
                    initFontInfo();
                    setLabelRead_Text();
                    //System.out.println("Reset");
                    break;

                case "Save":
                    saveFontInfo();
                    //System.out.println("Save");
                    break;

                case "Exit":
                    LoggerInfo.loggerInfo.info("程式正常關閉");
                    System.exit(0);
                    break;

                default:
                    break;
            }
        }
    }

    public class EventHandlerLabelRead_MOUSE_PRESSED implements EventHandler<MouseEvent> {

        @Override
        public void handle(MouseEvent e) {
            nowID = ProcessFrame.JObjectWhichOne(e.getSource(), labelRead);

            for (int i = 0; i < fontArray.length; i++) {
                if (fontArray[i].equals(fontInfo[nowID].getFontName())) {
                    choiceBoxSetup.getSelectionModel().select(i);
                }
            }

            //System.out.println("nowID = " + nowID);
        }
    }

    public class EventHandlerChoiceBoxSetup_ACTION implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent e) {

            ChoiceBox _choiceBoxSetup = (ChoiceBox) e.getSource();
            nowFontName = fontArray[_choiceBoxSetup.getSelectionModel().getSelectedIndex()];

            labelRead[nowID].setText(nowFontName);
            fontInfo[nowID].setFontName(nowFontName);
            labelFontTest.setFont(Font.font(nowFontName, nowFontSize));

        }
    }

    public class EventHandlerTextFieldInput_OnKeyReleased implements EventHandler<KeyEvent> {

        @Override
        public void handle(KeyEvent e) {

            if (e.getCode() == KeyCode.ENTER) {
                if (textFieldInput.getText().isEmpty()) {
                    textFieldInput.setPromptText("Please enter your word.");
                }
            }

            labelFontTest.setText(textFieldInput.getText());
        }
    }

    //----------小工具----------// 
    private FontInfo setListToFontInfoInfo(String str) {

        String[] arrayStr = str.split("\t");
        FontInfo _fontInfo = new FontInfo();

        _fontInfo.setFontCode(arrayStr[0]);
        _fontInfo.setFontName(arrayStr[1]);

        //System.out.println("_fontInfo = " + _fontInfo.getFontCode() + " / " + _fontInfo.getFontName());

        return _fontInfo;
    }

    private void setLabelRead_Text() {
        for (int i = 0; i < fontInfo.length; i++) {
            labelRead[i].setText(fontInfo[i].getFontName());
        }
    }

    private void saveFontInfo() {
        utilDB.connSQL();
        for (FontInfo fontInfo1 : fontInfo) {
            fontInfo1.setFontName(fontInfo1.getFontName());
            utilDB.updateFontInfo(fontInfo1);
        }
    }

    //----------結束----------//
    public static void main(String[] args) {
        launch(args);
    }
}
