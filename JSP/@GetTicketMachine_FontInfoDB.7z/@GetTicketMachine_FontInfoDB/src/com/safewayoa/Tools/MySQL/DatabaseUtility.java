// ======資料庫處理====== //
package com.safewayoa.Tools.MySQL;

import com.safewayoa.GetTicketMachine_FontInfoDB.Data.Model.FontInfo;
import com.safewayoa.GetTicketMachine_FontInfoDB.Data.Model.LoggerInfo;
import com.safewayoa.GetTicketMachine_FontInfoDB.Data.Model.SQLConnentInfo;
import com.safewayoa.Tools.Utility.TimeNow;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DatabaseUtility implements Serializable {

//----------------------------------------------------變數宣告-----------------------------------------------------//
    private Connection conn = null;
    private Statement stat = null;
    private ResultSet rs = null;
    private PreparedStatement pst = null;

    //---------------------------------------------------連線函數---------------------------------------------------//
    public boolean connSQL() {

        SQLConnentInfo infoSQL = new SQLConnentInfo();
        String driver = infoSQL.getDriver();
        String url = infoSQL.getUrl();
        String user = infoSQL.getUser();
        String password = infoSQL.getPassword();

        boolean isConn = false;

        try {

            Class.forName(driver);
            conn = DriverManager.getConnection(url, user, password);

            if (conn != null && !conn.isClosed()) {
                //System.out.println("資料庫連線測試成功…");
                LoggerInfo.loggerInfo.info("資料庫連線測試成功…");
            }

            isConn = true;

        } catch (ClassNotFoundException eNotFound) {
//            System.out.println("DriverClassNotFound :" + eNotFound.toString());
//            System.out.println("資料庫驅動程式出錯…");
            LoggerInfo.loggerInfo.info("資料庫驅動程式出錯…");

        } catch (SQLException eSQL) {
//            System.out.println("Exception :" + eSQL.toString());
//            System.out.println("資料庫帳號、密碼錯誤…");
            LoggerInfo.loggerInfo.info("資料庫帳號、密碼錯誤…");

        }
        return isConn;
    }

    //-------------------------------------------------資料庫連線關閉-----------------------------------------------//
    public void closeSQL() {
        try {

            if (rs != null) {
                rs.close();
                rs = null;
            }
            if (stat != null) {
                stat.close();
                stat = null;
            }
            if (pst != null) {
                pst.close();
                pst = null;
            }

//            System.out.println("資料庫連線關閉成功…");
            LoggerInfo.loggerInfo.info("資料庫連線關閉成功…");

        } catch (SQLException e) {
//            System.out.println("Close Exception :" + e.toString());
//            System.out.println("資料庫連線關閉失敗…");
            LoggerInfo.loggerInfo.info("資料庫連線關閉失敗…");
        }
    }

    public List<FontInfo> selectFontInfo(FontInfo fontInfo) {

        String selectSQL = "SELECT * FROM " + fontInfo.getTableName() + " Order By PrimaryKey ";
        List<FontInfo> _list = new ArrayList();

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                fontInfo = setFontInfo();
                _list.add(fontInfo);
            }
            LoggerInfo.loggerInfo.info("資料庫查詢成功…");

        } catch (SQLException e) {
//            System.out.println("SelectTable Exception :" + e.toString());
//            System.out.println("資料庫連線查詢失敗…");
            LoggerInfo.loggerInfo.info("資料庫查詢失敗…");

        } finally {
            closeSQL();
        }
        return _list;
    }

    //----------更新按鈕資訊----------//
    public void updateFontInfo(FontInfo fontInfo) {

        String updateSQL = "UPDATE " + fontInfo.getTableName() + " "
                + "SET FontName = ?, InsertDate = ?, InsertTime = ? "
                + "WHERE FontCode = ? ";

        try {

            pst = conn.prepareStatement(updateSQL);

            pst.setString(1, fontInfo.getFontName());
            pst.setDate(2, TimeNow.ToSqlDate());
            pst.setTime(3, TimeNow.ToSqlTime());
            pst.setString(4, fontInfo.getFontCode());

            pst.executeUpdate();
            //System.out.println("資料表更新成功…");
            LoggerInfo.loggerInfo.info("資料表更新成功…");

        } catch (SQLException e) {
//            System.out.println("UpdateDB Exception :" + e.toString());
//            System.out.println("資料表更新失敗…");
            LoggerInfo.loggerInfo.info("資料表更新失敗…");

        } finally {
            closeSQL();
        }
    }

    //----------小工具----------//
    public FontInfo setFontInfo() throws SQLException {

        FontInfo _fontInfo = new FontInfo(); // 把Class資料清空

        _fontInfo.setFontCode(rs.getString("FontCode"));
        _fontInfo.setFontName(rs.getString("FontName"));
        _fontInfo.setInsertDate(rs.getDate("InsertDate"));
        _fontInfo.setInsertStaff(rs.getString("InsertStaff"));
        _fontInfo.setInsertTime(rs.getTime("InsertTime"));
        _fontInfo.setPrimaryKey(rs.getInt("PrimaryKey"));
        _fontInfo.setProperty(rs.getString("Property"));
        _fontInfo.setTableName(rs.getString("TableName"));

        return _fontInfo;
    }
}
