// ======資料庫處理====== //
package backup;

import com.safewayoa.GetTicketMachine.Data.Model.SQLConnentInfo;
import com.safewayoa.Tools.Utility.ProcessWord;
import com.safewayoa.Tools.Utility.TimeNow;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ExecuteDatabase {

//----------------------------------------------------變數宣告-----------------------------------------------------//
    private Connection conn = null;
    private Statement stat = null;
    private ResultSet rs = null;
    private PreparedStatement pst = null;

    private String tableName = "Customers.CelledMachineDB";
    private String dropdbSQL = "";
    private String createdbSQL = "";
    private String insertdbSQL = "";
    private String selectSQL = "";
    private String deletedbSQL = "";
    private String updatedbSQL = "";
    private String backupdbSQL = "";
    private String rowName = " ";

    private int iWaittingCount = 0;
    private String sTicketNumber = "";

//---------------------------------------------------初始化函數---------------------------------------------------//
    public ExecuteDatabase() {

        SQLConnentInfo infoSQL = new SQLConnentInfo();
        String driver = infoSQL.getDriver();
        String url = infoSQL.getUrl();
        String user = infoSQL.getUser();
        String password = infoSQL.getPassword();

        try {

            Class.forName(driver);
            conn = DriverManager.getConnection(url, user, password);

            if (conn != null && !conn.isClosed()) {
                System.out.println("資料庫連線測試成功…");
            }

        } catch (ClassNotFoundException eNotFound) {
            System.out.println("DriverClassNotFound :" + eNotFound.toString());
            System.out.println("資料庫驅動程式出錯…");
        } catch (SQLException eSQL) {
            System.out.println("Exception :" + eSQL.toString());
            System.out.println("資料庫帳號、密碼錯誤…");
        }
    }

//-----------------------------------------------------建構函數----------------------------------------------------//
    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public int getWaittingCount() {
        return iWaittingCount;
    }

    public void setWaittingCount(int iWaittingCount) {
        this.iWaittingCount = iWaittingCount;
    }

    public String getTicketNumber() {
        return sTicketNumber;
    }

    public void setTicketNumber(String sTicketNumber) {
        this.sTicketNumber = sTicketNumber;
    }

    public String getRowName() {
        return rowName;
    }

    public void setRowName(String rowName) {
        this.rowName = rowName;
    }
//-------------------------------------------------資料庫連線關閉-----------------------------------------------//

    private void closeSQL() {
        try {

            if (rs != null) {
                rs.close();
                rs = null;
            }
            if (stat != null) {
                stat.close();
                stat = null;
            }
            if (pst != null) {
                pst.close();
                pst = null;
            }

            System.out.println("資料庫連線關閉成功…");

        } catch (SQLException e) {
            System.out.println("Close Exception :" + e.toString());
            System.out.println("資料庫連線關閉失敗…");
        }
    }

//----------------------------------------------------建立資料表--------------------------------------------------//
    public void createTable(String tableName) {

        createdbSQL = "CREATE TABLE " + tableName + " (id INTEGER(10), name VARCHAR(20), passwd VARCHAR(20))";

        try {

            stat = conn.createStatement();
            stat.executeUpdate(createdbSQL);
            System.out.println("資料庫連線建立成功…");

        } catch (SQLException e) {
            System.out.println("CreateDB Exception :" + e.toString());
            System.out.println("資料庫連線名稱重複…");
        } finally {
            closeSQL();
        }
    }

//---------------------------------------------------移除資料表---------------------------------------------------//
    public void dropTable(String tableName) {

        dropdbSQL = "DROP TABLE " + tableName;

        try {

            stat = conn.createStatement();
            stat.executeUpdate(dropdbSQL);
            System.out.println("資料庫連線刪除成功…");

        } catch (SQLException e) {
            System.out.println("DropDB Exception :" + e.toString());
            System.out.println("資料庫連線名稱重複…");
        } finally {
            closeSQL();
        }
    }

//----------------------------------------------------查詢資料表--------------------------------------------------//
    public void selectTable() {

        selectSQL = "SELECT * FROM " + tableName;

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(selectSQL);

            ResultSetMetaData rm = rs.getMetaData();
            int colNumber = rm.getColumnCount();

            for (int i = 1; i <= colNumber; i++) {
                System.out.print(rm.getColumnName(i) + "\t\t");
            }

            System.out.println();

            while (rs.next()) {
                for (int i = 1; i <= colNumber; i++) {
                    System.out.print(rs.getObject(i) + "\t\t");
                }
                System.out.println();
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
    }

//---------------------------------------------------查詢資料表---------------------------------------------------//
    public List<String> selectTable_CelledMachineDB(String TicketPrintDate, String TicketStatus, String BusinessType) {

        tableName = "Customers.CelledMachineDB";
        rowName = "TicketPrintNumer";
        selectSQL = "SELECT " + rowName + " FROM " + tableName + " WHERE TicketPrintDate = ? AND TicketStatus = ? AND BusinessType = ?";

        List<String> list = new ArrayList();

        try {

            pst = conn.prepareStatement(selectSQL);
            pst.setString(1, TicketPrintDate);
            pst.setString(2, TicketStatus);
            pst.setString(3, BusinessType);

            rs = pst.executeQuery();

            ResultSetMetaData rm = rs.getMetaData();

            // 取得欄位的個數…
            int colNumber = rm.getColumnCount();

            // 列印每個欄位名稱…
            for (int i = 1; i <= colNumber; i++) {
                System.out.print(rm.getColumnName(i) + "\t\t");
            }

            System.out.println();

            while (rs.next()) {
                for (int i = 1; i <= colNumber; i++) {
                    System.out.print(rs.getObject(i) + "\t\t");
                    list.add(String.valueOf(rs.getObject(i)));
                }
                System.out.println();
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return list;
    }

    //---------------------------------------------------查詢資料表---------------------------------------------------//
    public List<String> selectTable_TicketStatus(String TicketPrintDate, String TicketPrintNumer) {

        tableName = "Customers.CelledMachineDB";
        rowName = " TicketStatus";
        selectSQL = "SELECT " + rowName + " FROM " + tableName + " WHERE TicketPrintDate = ? AND TicketPrintNumer = ?";

        List<String> list = new ArrayList();

        try {

            pst = conn.prepareStatement(selectSQL);
            pst.setString(1, TicketPrintDate);
            pst.setString(2, TicketPrintNumer);

            rs = pst.executeQuery();

            ResultSetMetaData rm = rs.getMetaData();

            // 取得欄位的個數…
            int colNumber = rm.getColumnCount();

            // 列印每個欄位名稱…
            for (int i = 1; i <= colNumber; i++) {
                System.out.print(rm.getColumnName(i) + "\t\t");
            }

            System.out.println();

            while (rs.next()) {
                for (int i = 1; i <= colNumber; i++) {
                    list.add(String.valueOf(rs.getObject(i)));
                    System.out.print(rs.getObject(i) + "\t\t");
                }
                System.out.println();
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return list;
    }

//----------------------------------------------------查詢資料表--------------------------------------------------//
    public List<String> selectTable_TempDB(int ID) {

        List<String> list = new ArrayList();

        tableName = "Customers.TempDB";
        selectSQL = "SELECT * FROM " + tableName + " WHERE ID = ?";

        try {

            pst = conn.prepareStatement(selectSQL);
            pst.setInt(1, ID);

            rs = pst.executeQuery();

            ResultSetMetaData rm = rs.getMetaData();

            int colNumber = rm.getColumnCount();

            for (int i = 1; i <= colNumber; i++) {
                System.out.print(rm.getColumnName(i) + "\t\t");
            }

            System.out.println();

            while (rs.next()) {
                for (int i = 1; i <= colNumber; i++) {
                    System.out.print(rs.getObject(i) + "\t\t");
                    list.add(String.valueOf(rs.getObject(i)));
                }

                this.setWaittingCount((int) rs.getObject(2));
                this.setTicketNumber((String) rs.getObject(3));

                System.out.println();
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return list;
    }

//------------------------------------------------------新增數據----------------------------------------------------//
    public void insertTable_CelledMachineDB(int TicketPrintNumer, String TicketPrintDate, String TicketPrintTime, String BusinessType) {

        tableName = "Customers.CelledMachineDB";
        insertdbSQL = "INSERT INTO " + tableName + " (TicketPrintNumer, TicketPrintDate, TicketPrintTime, BusinessType) VALUES (?, ?, ?, ?)";

        try {

            pst = conn.prepareStatement(insertdbSQL);
            pst.setString(1, ProcessWord.IntToString(TicketPrintNumer));
            pst.setString(2, TicketPrintDate);
            pst.setString(3, TicketPrintTime);
            pst.setString(4, BusinessType);

            pst.executeUpdate();

            System.out.println("資料庫連線新增成功…");

        } catch (SQLException e) {
            System.out.println("InsertDB Exception :" + e.toString());
            System.out.println("資料庫尚未建立…");
        } finally {
            closeSQL();
        }
    }

//------------------------------------------------------新增數據----------------------------------------------------//
    public void insertTable_StaffWorkDB(String StaffID, String StaffGetTicketNumer, String StaffGetTicketNumerDate, String StaffGetTicketNumerTime, String TicketStatus) {

        tableName = "Customers.StaffWorkDB";
        insertdbSQL = "INSERT INTO " + tableName + " (StaffID, StaffGetTicketNumer, StaffGetTicketNumerDate, StaffGetTicketNumerTime, TicketStatus) VALUES (?, ?, ?, ?, ?)";

        try {

            pst = conn.prepareStatement(insertdbSQL);
            pst.setString(1, StaffID);
            pst.setString(2, StaffGetTicketNumer);
            pst.setString(3, StaffGetTicketNumerDate);
            pst.setString(4, StaffGetTicketNumerTime);
            pst.setString(5, TicketStatus);
            pst.executeUpdate();

            System.out.println("資料庫連線新增成功…");

        } catch (SQLException e) {
            System.out.println("InsertDB Exception :" + e.toString());
            System.out.println("資料庫尚未建立…");
        } finally {
            closeSQL();
        }
    }

//---------------------------------------------------刪除單筆資料------------------------------------------------//
    public void deleteTable(int id) {

        deletedbSQL = "DELETE FROM " + tableName + " WHERE ID = ?";

        try {

            pst = conn.prepareStatement(deletedbSQL);
            pst.setInt(1, id);
            pst.executeUpdate();
            System.out.println("資料刪除成功…");

        } catch (SQLException e) {
            System.out.println("DeleteDB Exception :" + e.toString());
            System.out.println("資料表沒有可刪除的資料…");
        } finally {
            closeSQL();
        }
    }

//---------------------------------------------------備份資料表---------------------------------------------------//
    public void backupTable() {

        TimeNow backupTime = new TimeNow();
        String tableTime = backupTime.getYear() + backupTime.getMonth() + backupTime.getDay() + backupTime.getHour() + backupTime.getMinute() + backupTime.getSecond();
        String tableNameNew = tableName + "_" + tableTime;

        backupdbSQL = "CREATE TABLE " + tableNameNew + " SELECT * FROM " + tableName;

        try {

            stat = conn.createStatement();
            stat.executeUpdate(backupdbSQL);
            System.out.println("資料庫備份成功…");

        } catch (SQLException e) {
            System.out.println("BackupDB Exception :" + e.toString());
            System.out.println("資料庫備份失敗…");
        } finally {
            closeSQL();
        }
    }

//---------------------------------------------------修改資料表---------------------------------------------------//
    public void updateTable_CelledMachineDB_2(String sTicketPrintNumer, String sTicketStatus) {

        tableName = "Customers.CelledMachineDB";
        updatedbSQL = "UPDATE " + tableName + " SET TicketStatus =  ? WHERE  TicketPrintNumer =  ?";
        try {

            pst = conn.prepareStatement(updatedbSQL);
            pst.setString(1, sTicketStatus);
            pst.setString(2, sTicketPrintNumer);
            pst.executeUpdate();
            System.out.println("資料表更新成功…");

        } catch (SQLException e) {
            System.out.println("UpdateDB Exception :" + e.toString());
            System.out.println("資料表更新失敗…");
        } finally {
            closeSQL();
        }
    }

    //---------------------------------------------------修改資料表---------------------------------------------------//
    public void updateTable_CelledMachineDB(String sTicketPrintNumer, String sTicketPrintDate, String sTicketStatus, String TicketStatus) {

        tableName = "Customers.CelledMachineDB";
        updatedbSQL = "UPDATE " + tableName + " SET TicketStatus =  ? WHERE  TicketPrintNumer =  ? AND TicketPrintDate = ? AND TicketStatus = ?";
        try {

            pst = conn.prepareStatement(updatedbSQL);
            pst.setString(1, TicketStatus);
            pst.setString(2, sTicketPrintNumer);
            pst.setString(3, sTicketPrintDate);
            pst.setString(4, sTicketStatus);
            pst.executeUpdate();
            System.out.println("資料表更新成功…");

        } catch (SQLException e) {
            System.out.println("UpdateDB Exception :" + e.toString());
            System.out.println("資料表更新失敗…");
        } finally {
            closeSQL();
        }
    }

    //---------------------------------------------------修改資料表---------------------------------------------------//
    public void updateTable_StaffWorkDB(String StaffID, String StaffGetTicketNumerDate, String StaffGetTicketNumer, String TicketStatus, String sStaffeEndTicketNumerDate, String sStaffEndTicketNumerTime, String sTicketStatus) {

        tableName = "Customers.StaffWorkDB";
        updatedbSQL = "UPDATE " + tableName + " SET StaffeEndTicketNumerDate =  ?, StaffEndTicketNumerTime = ?, TicketStatus = ? WHERE  StaffID =  ? AND StaffGetTicketNumerDate = ? AND StaffGetTicketNumer = ? AND TicketStatus = ?";
        try {

            pst = conn.prepareStatement(updatedbSQL);
            pst.setString(1, sStaffeEndTicketNumerDate);
            pst.setString(2, sStaffEndTicketNumerTime);
            pst.setString(3, sTicketStatus);
            pst.setString(4, StaffID);
            pst.setString(5, StaffGetTicketNumerDate);
            pst.setString(6, StaffGetTicketNumer);
            pst.setString(7, TicketStatus);
            pst.executeUpdate();
            System.out.println("資料表更新成功…");

        } catch (SQLException e) {
            System.out.println("UpdateDB Exception :" + e.toString());
            System.out.println("資料表更新失敗…");
        } finally {
            closeSQL();
        }
    }

//---------------------------------------------------修改資料表---------------------------------------------------//
    public void update_TableDBint(int ID, int iWaittingCount) {

        tableName = "Customers.TempDB";
        updatedbSQL = "UPDATE " + tableName + " SET WaittingCount = ? WHERE ID =  ?";

        try {

            pst = conn.prepareStatement(updatedbSQL);
            pst.setInt(1, iWaittingCount);
            pst.setInt(2, ID);
            pst.executeUpdate();
            System.out.println("資料表更新成功…");

        } catch (SQLException e) {
            System.out.println("UpdateDB Exception :" + e.toString());
            System.out.println("資料表更新失敗…");
        } finally {
            closeSQL();
        }
    }

//---------------------------------------------------修改資料表---------------------------------------------------//
    public void update_TableDBstr(int ID, int iTicketPrintNumer) {

        tableName = "Customers.TempDB";
        updatedbSQL = "UPDATE " + tableName + " SET TicketPrintNumer = ? WHERE ID =  ?";

        try {

            pst = conn.prepareStatement(updatedbSQL);
            pst.setString(1, ProcessWord.IntToString(iTicketPrintNumer));
            pst.setInt(2, ID);
            pst.executeUpdate();
            System.out.println("資料表更新成功…");

        } catch (SQLException e) {
            System.out.println("UpdateDB Exception :" + e.toString());
            System.out.println("資料表更新失敗…");
        } finally {
            closeSQL();
        }
    }
//-----------------------------------------------------結束----------------------------------------------------------//
}
