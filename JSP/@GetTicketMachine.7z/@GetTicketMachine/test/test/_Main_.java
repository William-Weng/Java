package test;

import com.safewayoa.GetTicketMachine.Data.Model.ViewImageInfo;
import com.safewayoa.Tools.MySQL.DatabaseUtility;
import java.util.List;

public class _Main_ {

    public static void main(String[] args) {
        DatabaseUtility utilDB = new DatabaseUtility();
        List<ViewImageInfo> _list;

        utilDB.connSQL();

        utilDB.insertFile();
//
//        ButtonFunctionInfo buttonFunctionInfo = new ButtonFunctionInfo();
//        ButtonInfo buttonInfo = new ButtonInfo();
//
//        buttonInfo.setFunctionCode("C001");
//        buttonInfo.setButtonName("ButtonRun3");
//        
//        utilDB = new DatabaseUtility();
//
//        buttonFunctionInfo = utilDB.selectButtonFunctionInfoOne(buttonInfo);
//
//        utilDB.printButtonFunctionInfo(buttonFunctionInfo);
//        PrintTicket_2 PrintTicket_2 = new PrintTicket_2();
//        PrintTicket_2.printTicket(1234);
    }
}
