package test;

import com.safewayoa.GetTicketMachine.Data.Model.ViewFontInfo;
import com.safewayoa.Tools.MySQL.DatabaseUtility;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.print.PageFormat;
import java.awt.print.Paper;
import java.awt.print.Printable;
import static java.awt.print.Printable.NO_SUCH_PAGE;
import static java.awt.print.Printable.PAGE_EXISTS;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;

public class PrintTicket_2 implements Printable {

    private int ticketInfoNumer;

    //--- Private instances declarations
    public void printTicket(int ticketInfoNumer) {

        this.ticketInfoNumer = ticketInfoNumer;
        double[] margin = {0, 0};

        PrinterJob printerJob = PrinterJob.getPrinterJob();
        Paper paper = new Paper();
        PageFormat pageFormat = printerJob.defaultPage();

        paper.setImageableArea(margin[0], margin[1], paper.getWidth(), paper.getHeight()); // 取得紙張可列印範圍
        System.out.println("paper.getWidth() = " + paper.getWidth());
        pageFormat.setPaper(paper); // 設定紙張規格
        printerJob.setPrintable(this, pageFormat); // 將紙張設定寫入

        boolean OK;
        //OK = printJob.printDialog();
        OK = true;

        if (OK) {
            try {
                printerJob.print();
            } catch (PrinterException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    @Override
    public int print(Graphics g, PageFormat pageFormat, int page) {

        Graphics2D g2d;
        DatabaseUtility UtilDB;
        //--- Validate the page number, we only print the first page
        if (page == 0) {  //--- Create a graphic2D object a set the default parameters

            g2d = (Graphics2D) g;
            g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY()); // 設定到(0,0)

            System.out.println("pageFormat.getHeight() = " + pageFormat.getHeight());
            System.out.println("pageFormat.getWidth() = " + pageFormat.getWidth());
            System.out.println("pageFormat.getImageableX() = " + pageFormat.getImageableX());
            ViewFontInfo fontViewInfo = new ViewFontInfo();
            fontViewInfo.setColorRGB("0,0,0");
            fontViewInfo.setBackgroundColorRGB("255,255,255");
            fontViewInfo.setTexts(String.valueOf(ticketInfoNumer));
            fontViewInfo.setX(0);
            fontViewInfo.setY(0);

            printString(g2d, fontViewInfo);

            return (PAGE_EXISTS);
        } else {
            return (NO_SUCH_PAGE);
        }
    }

    //----------小工具----------//
    public int[] getGRB(String colors) { // 將(25,25,25)切開
        String[] _colors = colors.split(",");
        int[] textColor = {Integer.parseInt(_colors[0]), Integer.parseInt(_colors[1]), Integer.parseInt(_colors[2])};
        return textColor;
    }

    public void printString(Graphics2D g2d, ViewFontInfo fontViewInfo) {
        int[] textColor = getGRB(fontViewInfo.getColorRGB());
        int[] textBackgroundColor = getGRB(fontViewInfo.getBackgroundColorRGB());

        g2d.setFont(new Font("", Font.BOLD, 8));
        g2d.setColor(new Color(textBackgroundColor[0], textBackgroundColor[1], textBackgroundColor[2])); // 文字底色

        if (!fontViewInfo.getBackgroundColorRGB().equals("255,255,255")) { // 底色白色就變透明
            g2d.fillRect(fontViewInfo.getX(), fontViewInfo.getY(), g2d.getFontMetrics().stringWidth(fontViewInfo.getTexts()), g2d.getFontMetrics().getHeight()); // 取得文字的寬、高
        }

        g2d.setColor(new Color(textColor[0], textColor[1], textColor[2]));// 文字顏字，正常顯示字符串，剛好在底色框內
        g2d.drawString(fontViewInfo.getTexts(), fontViewInfo.getX(), fontViewInfo.getY() + g2d.getFontMetrics().getAscent());
    }

    public int getTicketInfoNumer() {
        return ticketInfoNumer;
    }

    public void setTicketInfoNumer(int ticketInfoNumer) {
        this.ticketInfoNumer = ticketInfoNumer;
    }
}
