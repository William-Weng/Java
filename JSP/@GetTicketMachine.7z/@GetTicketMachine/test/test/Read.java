/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import com.safewayoa.Tools.Utility.ProcessArray;
import java.util.List;

/**
 *
 * @author william
 */
public class Read {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ProcessArray ProcessArray = new ProcessArray();

        List<String> _list = ProcessArray.ReadFile("src/Data/Text/SQLConnentInfo_UTF8.ini");
        System.out.println("_list = " + _list);

        String[] SQLInfo = _list.toArray(new String[0]);
        String[] SqlPP = SQLInfo[0].split("\t");

        for (int i = 0; i < SqlPP.length; i++) {
            System.out.println("SqlPP = " + SqlPP[i]);
        }
    }

}
