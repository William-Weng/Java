/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import com.safewayoa.GetTicketMachine.Run;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import javafx.scene.image.Image;

/**
 *
 * @author william
 */
public class ImageABC {

    String imagePath;
    InputStream _imagePath;
    Image imagePic;
    Image imagePic2;

    public void images() {
        _imagePath = Run.class.getResourceAsStream("Data/Image/BusinessTypes/1.png");
        imagePic = new Image(_imagePath);

        imagePath = "Image/TicketInfo/Logo.gif";
        File files = new File("src/" + imagePath);
        System.out.println("files.canRead() = " + files.exists());
        System.out.println("File = " + files);
        imagePic2 = new Image(imagePath);
    }

    public static void main(String[] args) {
        ImageABC imageABC = new ImageABC();
        imageABC.images();
    }

}
