
import backup.PrintTicket;

public class Thread5 {

    public static void main(String[] args) {
        Thread5A thread5A = new Thread5A("執行緒A");
        Thread5A thread5A1 = new Thread5A("執行緒B");

        System.out.println("主程式結束!!!");

    }

}

class Thread5A implements Runnable {

    String name;             //設定執行緒的名稱

    Thread t;

    Thread5A(String name) {

        this.name = name;

        t = new Thread(this, name);

        t.start();

    }

    @Override
    public void run() {
        PrintTicket printTicket = new PrintTicket();

        try {

            for (int i = 0; i < 5; i++) {
                printTicket.printTicket(1234);
                Thread.sleep(3000);
                printTicket.printTicket(1234);

                System.out.println(name + "的 i 值為：" + i);

            }

        } catch (InterruptedException e) {

            System.out.println(e.toString());

        }

    }

}
