// ======文數字處理====== //
package com.safewayoa.Tools.Utility;

import java.util.ArrayList;
import java.util.List;

public class ProcessWord {

    private final String wavBase = "src/Data/Wav/";
    private final String wavFile[] = {
        wavBase + "0.wav",
        wavBase + "1.wav",
        wavBase + "2.wav",
        wavBase + "3.wav",
        wavBase + "4.wav",
        wavBase + "5.wav",
        wavBase + "6.wav",
        wavBase + "7.wav",
        wavBase + "8.wav",
        wavBase + "9.wav",
        wavBase + "來賓.wav",
        wavBase + "號.wav",
        wavBase + "請.wav",
        wavBase + "櫃台.wav"
    };

    //-------------------------將10轉成0010------------------------//
    public static String IntToString(int number) {
        String str = "";

        if (number / 10000 == 0) {
            str = "" + number;
        }

        if (number / 1000 == 0) {
            str = "0" + number;
        }

        if (number / 100 == 0) {
            str = "00" + number;
        }

        if (number / 10 == 0) {
            str = "000" + number;
        }

        return str;
    }

    //----------------------將0005轉成0005.wav-----------------------//
    public List<String> IntToWav(int number, int counter) {
        List<String> list = new ArrayList();
        String str1 = IntToString(number);
        char[] arrayChar = str1.toCharArray();
        int index = 0;

        list.add(wavFile[10]); // 來賓.wav

        for (char charStr : arrayChar) {
            list.add(wavFile[Integer.parseInt(String.valueOf(charStr))]); // 1→1.wav
            System.out.println(charStr);
        }

        list.add(wavFile[11]); // 號.wav
        list.add(wavFile[12]); // 請.wav
        list.add(wavFile[counter]);
        list.add(wavFile[11]); // 號.wav
        list.add(wavFile[13]); // 櫃台.wav

        System.out.println(list);

        return list;
    }

}
