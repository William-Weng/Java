package com.safewayoa.Tools.Utility;

import com.safewayoa.GetTicketMachine.Data.Model.LoggerInfo;
import com.safewayoa.GetTicketMachine.Data.Model.ViewFontInfo;
import com.safewayoa.GetTicketMachine.Data.Model.ViewImageInfo;
import com.safewayoa.GetTicketMachine.Run;
import com.safewayoa.Tools.MySQL.DatabaseUtility;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.print.PageFormat;
import java.awt.print.Paper;
import java.awt.print.Printable;
import static java.awt.print.Printable.NO_SUCH_PAGE;
import static java.awt.print.Printable.PAGE_EXISTS;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import javax.imageio.ImageIO;

public class PrintTicket implements Printable {

    private int ticketInfoNumer;
    private String functionName;
    private Image image;
    private final DatabaseUtility utilDB;
    private final boolean isConn;

    public PrintTicket() {
        utilDB = new DatabaseUtility();
        isConn = utilDB.connSQL();
    }

    //--- Private instances declarations
    public void printTicket(int ticketInfoNumer, String functionName) {

        this.ticketInfoNumer = ticketInfoNumer;
        this.functionName = functionName;
        double[] margin = {0, 0};

        PrinterJob printerJob = PrinterJob.getPrinterJob();
        Paper paper = new Paper();
        PageFormat pageFormat;
        pageFormat = printerJob.defaultPage();

        // paper.setSize(300, 200);
        paper.setImageableArea(margin[0], margin[1], paper.getWidth(), paper.getHeight()); // 取得紙張可列印範圍

        pageFormat.setPaper(paper); // 設定紙張規格
        printerJob.setPrintable(this, pageFormat); // 將紙張設定寫入
        // boolean OK = printJob.printDialog();
        if (isConn) {
            try {
                printerJob.print();
                LoggerInfo.loggerInfo.info("號碼牌列印成功");
            } catch (PrinterException e) {
                //System.out.println(e.getMessage());
                LoggerInfo.loggerInfo.info("號碼牌列印失敗");
            }
            utilDB.closeSQL();
        }
    }

    @Override
    public int print(Graphics g, PageFormat pageFormat, int page) {

        Graphics2D g2d;

        //--- Validate the page number, we only print the first page
        if (page == 0) {  //--- Create a graphic2D object a set the default parameters

            g2d = (Graphics2D) g;
            g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY()); // 設定到(0,0)

            List<ViewFontInfo> _listViewFontInfo = utilDB.selectViewFontInfo(new ViewFontInfo());
            List<ViewImageInfo> _listViewImageInfo = utilDB.selectViewImageInfo(new ViewImageInfo());

            for (int i = 0; i < _listViewFontInfo.size(); i++) {

                ViewFontInfo viewFontInfo = _listViewFontInfo.get(i);

                switch (viewFontInfo.getProperty()) {

                    case "Number": // 印數字 9 → 0009
                        viewFontInfo.setTexts(ProcessWord.IntToString(this.ticketInfoNumer));
                        break;
                    case "Time": // 印時間
                        viewFontInfo.setTexts(String.valueOf(TimeNow.ToSqlDate() + " " + TimeNow.ToSqlTime()));
                        break;
                    case "BusinessTypes": // 印業務類型
                        viewFontInfo.setTexts(this.functionName);
                        break;
                    default:
                        break;
                }
                printString(g2d, viewFontInfo);
            }

            for (int i = 0; i < _listViewImageInfo.size(); i++) {

                ViewImageInfo viewImageInfo = _listViewImageInfo.get(i);

                // System.out.println("viewImageInfo.getPaths() = " + viewImageInfo.getPaths());
                printImage(g2d, viewImageInfo);
//                System.out.println("viewImageInfo = " + viewImageInfo.getX());
            }
            return (PAGE_EXISTS);
        } else {
            return (NO_SUCH_PAGE);
        }
    }

    //----------小工具----------//
    public int[] getGRB(String colors) { // 將(255,255,255)切開
        String[] _colors = colors.split(",");
        int[] textColor = {Integer.parseInt(_colors[0]), Integer.parseInt(_colors[1]), Integer.parseInt(_colors[2])};
        return textColor;
    }

    public void printString(Graphics2D g2d, ViewFontInfo fontViewInfo) {
        int[] textColor = getGRB(fontViewInfo.getColorRGB());
        int[] textBackgroundColor = getGRB(fontViewInfo.getBackgroundColorRGB());

        g2d.setFont(new Font(fontViewInfo.getFontName(), fontViewInfo.getTypeCode(), fontViewInfo.getSizes()));
        g2d.setColor(new Color(textBackgroundColor[0], textBackgroundColor[1], textBackgroundColor[2])); // 文字底色

        if (!fontViewInfo.getBackgroundColorRGB().equals("255,255,255")) { // 底色白色就變透明
            g2d.fillRect(fontViewInfo.getX(), fontViewInfo.getY(), g2d.getFontMetrics().stringWidth(fontViewInfo.getTexts()), g2d.getFontMetrics().getHeight()); // 取得文字的寬、高
        }

        g2d.setColor(new Color(textColor[0], textColor[1], textColor[2]));// 文字顏色，正常顯示字符串，剛好在底色框內
        g2d.drawString(fontViewInfo.getTexts(), fontViewInfo.getX(), fontViewInfo.getY() + g2d.getFontMetrics().getAscent());
    }

    public void printImage(Graphics2D g2d, ViewImageInfo viewImageInfo) {

        try {
            // image = ImageIO.read(new File(picPath));

            InputStream errorImage;
            File fileImage;
            fileImage = new File("src/" + viewImageInfo.getPaths());

            errorImage = Run.class.getResourceAsStream("Data/Image/TicketInfo/No-Image.png");

            if (fileImage.exists()) {
                image = ImageIO.read(fileImage);
            } else {
                image = ImageIO.read(errorImage);
            }
        } catch (IOException ex) {
            //System.out.println("No example.jpg!!");
            LoggerInfo.loggerInfo.info("圖形讀取錯誤");
        }

        g2d.drawImage(image, viewImageInfo.getX(), viewImageInfo.getY(), null);
    }

    public int getTicketInfoNumer() {
        return ticketInfoNumer;
    }

    public void setTicketInfoNumer(int ticketInfoNumer) {
        this.ticketInfoNumer = ticketInfoNumer;
    }
}
