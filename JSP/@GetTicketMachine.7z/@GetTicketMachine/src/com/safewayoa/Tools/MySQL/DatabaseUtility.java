// ======資料庫處理====== //
package com.safewayoa.Tools.MySQL;

import com.safewayoa.GetTicketMachine.Data.Model.ButtonFunctionInfo;
import com.safewayoa.GetTicketMachine.Data.Model.ButtonInfo;
import com.safewayoa.GetTicketMachine.Data.Model.CountInfo;
import com.safewayoa.GetTicketMachine.Data.Model.FontInfo;
import com.safewayoa.GetTicketMachine.Data.Model.ViewFontInfo;
import com.safewayoa.GetTicketMachine.Data.Model.FunctionInfo;
import com.safewayoa.GetTicketMachine.Data.Model.LoggerInfo;
import com.safewayoa.GetTicketMachine.Data.Model.SQLConnentInfo;
import com.safewayoa.GetTicketMachine.Data.Model.TicketInfo;
import com.safewayoa.GetTicketMachine.Data.Model.ViewImageInfo;
import com.safewayoa.Tools.Utility.ProcessArray;
import com.safewayoa.Tools.Utility.TimeNow;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DatabaseUtility implements Serializable {

//----------------------------------------------------變數宣告-----------------------------------------------------//
    private Connection conn = null;
    private Statement stat = null;
    private ResultSet rs = null;
    private PreparedStatement pst = null;

    //---------------------------------------------------連線函數---------------------------------------------------//
    public boolean connSQL() {

        SQLConnentInfo infoSQL = new SQLConnentInfo();
        String driver = infoSQL.getDriver();
        String url = infoSQL.getUrl();
        String user = infoSQL.getUser();
        String password = infoSQL.getPassword();

        boolean isConn = false;

        try {

            Class.forName(driver);
            conn = DriverManager.getConnection(url, user, password);

            if (conn != null && !conn.isClosed()) {
//                System.out.println("資料庫連線測試成功…");
                LoggerInfo.loggerInfo.info("資料庫連線測試成功…");
            }

            isConn = true;

        } catch (ClassNotFoundException eNotFound) {
//            System.out.println("DriverClassNotFound :" + eNotFound.toString());
//            System.out.println("資料庫驅動程式出錯…");
            LoggerInfo.loggerInfo.info("資料庫驅動程式出錯…");
        } catch (SQLException eSQL) {
//            System.out.println("Exception :" + eSQL.toString());
//            System.out.println("資料庫帳號、密碼錯誤…");
            LoggerInfo.loggerInfo.info("資料庫帳號、密碼錯誤…");
        }
        return isConn;
    }

    //-------------------------------------------------資料庫連線關閉-----------------------------------------------//
    public void closeSQL() {
        try {

            if (rs != null) {
                rs.close();
                rs = null;
            }
            if (stat != null) {
                stat.close();
                stat = null;
            }
            if (pst != null) {
                pst.close();
                pst = null;
            }

//            System.out.println("資料庫連線關閉成功…");
            LoggerInfo.loggerInfo.info("資料庫連線關閉成功…");

        } catch (SQLException e) {
//            System.out.println("Close Exception :" + e.toString());
//            System.out.println("資料庫連線關閉失敗…");
            LoggerInfo.loggerInfo.info("資料庫連線關閉失敗…");
        }
    }

    //----------初始化按鈕個數----------//
    public CountInfo selectCountInfoOne(CountInfo countInfo) {

        String selectSQL = "SELECT * FROM " + countInfo.getTableName() + " WHERE Property = ?";

        try {

            pst = conn.prepareStatement(selectSQL);
            pst.setString(1, countInfo.getProperty());
            rs = pst.executeQuery();

            while (rs.next()) {
                // System.out.println("Counts = " + rs.getInt("Counts"));
                countInfo = setCountInfo();
            }
            LoggerInfo.loggerInfo.info("資料庫查詢成功…");

        } catch (SQLException e) {
//            System.out.println("SelectTable Exception :" + e.toString());
//            System.out.println("資料庫連線查詢失敗…");
            LoggerInfo.loggerInfo.info("資料庫查詢失敗…");
        } finally {
            closeSQL();
        }
        return countInfo;
    }

    //----------初始化按鈕個數----------//
    public ButtonFunctionInfo selectButtonFunctionInfoOne(ButtonInfo buttonInfo) {

        FunctionInfo functionInfo;
        ButtonFunctionInfo buttonFunctionInfo;

        functionInfo = new FunctionInfo();
        buttonFunctionInfo = new ButtonFunctionInfo();

        String fields = "GetTicketMachine.ButtonInfo.PrimaryKey, GetTicketMachine.ButtonInfo.ButtonName, GetTicketMachine.FunctionInfo.FunctionCode, GetTicketMachine.FunctionInfo.FunctionName, GetTicketMachine.FunctionInfo.ImagesURL";

        String selectSQL = "SELECT  " + fields + " FROM " + buttonInfo.getTableName() + " INNER JOIN " + functionInfo.getTableName() + " "
                + "ON GetTicketMachine.ButtonInfo.FunctionCode = GetTicketMachine.FunctionInfo.FunctionCode "
                + "WHERE GetTicketMachine.ButtonInfo.ButtonName = ?";

        try {

            pst = conn.prepareStatement(selectSQL);
            pst.setString(1, buttonInfo.getButtonName());
            //System.out.println("buttonInfo.getButtonName() = " + buttonInfo.getButtonName());
            rs = pst.executeQuery();

            while (rs.next()) {
                // System.out.println("Counts = " + rs.getInt("Counts"));
                buttonFunctionInfo = setButtonFunctionInfo();
            }
            LoggerInfo.loggerInfo.info("資料庫查詢成功…");

        } catch (SQLException e) {
//            System.out.println("SelectTable Exception :" + e.toString());
//            System.out.println("資料庫連線查詢失敗…");
            LoggerInfo.loggerInfo.info("資料庫查詢失敗…");
        } finally {
            closeSQL();
        }
        return buttonFunctionInfo;
    }

    //----------★初始化下拉式選單----------//
    public FunctionInfo selectFunctionInfoOne(ButtonInfo buttonInfo) {

        FunctionInfo functionInfo = new FunctionInfo();
        String selectSQL = "SELECT * FROM " + functionInfo.getTableName() + " WHERE FunctionCode = ? ";

        try {

            pst = conn.prepareStatement(selectSQL);
            pst.setString(1, buttonInfo.getFunctionCode());
            rs = pst.executeQuery();

            while (rs.next()) {
                functionInfo = setFunctionInfo();
            }
            LoggerInfo.loggerInfo.info("資料庫查詢成功…");

        } catch (SQLException e) {
//            System.out.println("SelectTable Exception :" + e.toString());
//            System.out.println("資料庫連線查詢失敗…");
            LoggerInfo.loggerInfo.info("資料庫查詢失敗…");
        } finally {
            closeSQL();
        }
        return functionInfo;
    }

    //----------初始化按鈕個數----------//
    public List<ButtonInfo> selectButtonInfo(ButtonInfo buttonInfo) {

        String selectSQL = "SELECT * FROM " + buttonInfo.getTableName() + " Order By ID";
        List<ButtonInfo> _list = new ArrayList();

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(selectSQL);
//            pst = conn.prepareStatement(selectSQL);
//            pst.setString(1, "1 = 1");
//            rs = pst.executeQuery();

            _list = new ArrayList();

            while (rs.next()) {

                buttonInfo = setButtonInfo();
                _list.add(buttonInfo);
            }
            LoggerInfo.loggerInfo.info("資料庫查詢成功…");

        } catch (SQLException e) {
//            System.out.println("SelectTable Exception :" + e.toString());
//            System.out.println("資料庫連線查詢失敗…");
            LoggerInfo.loggerInfo.info("資料庫查詢失敗…");

        } finally {
            closeSQL();
        }
        return _list;
    }

    //----------初始化下拉式選單----------//
    public List<FunctionInfo> selectFunctionInfo(FunctionInfo functionInfo) {

        String selectSQL = "SELECT * FROM " + functionInfo.getTableName() + " Order By FunctionCode";
        List<FunctionInfo> _list = new ArrayList();

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                functionInfo = setFunctionInfo();
                _list.add(functionInfo);
            }
            LoggerInfo.loggerInfo.info("資料庫查詢成功…");

        } catch (SQLException e) {
//            System.out.println("SelectTable Exception :" + e.toString());
//            System.out.println("資料庫連線查詢失敗…");
            LoggerInfo.loggerInfo.info("資料庫查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    //----------TicketInfo----------//
    public List<TicketInfo> selectTicketInfo(TicketInfo ticketInfo) {

        String selectSQL = "SELECT * FROM " + ticketInfo.getTableName() + " Order By PrimaryKey ";
        List<TicketInfo> _list = new ArrayList();

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                ticketInfo = setTicketInfo();
                _list.add(ticketInfo);
            }
            LoggerInfo.loggerInfo.info("資料庫查詢成功…");

        } catch (SQLException e) {
//            System.out.println("SelectTable Exception :" + e.toString());
//            System.out.println("資料庫連線查詢失敗…");
            LoggerInfo.loggerInfo.info("資料庫查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    //----------ViewFontInfo----------//
    public List<ViewFontInfo> selectViewFontInfo(ViewFontInfo fontViewInfo) {

        String selectSQL = "SELECT * FROM " + fontViewInfo.getTableName() + " Order By PrimaryKey ";
        List<ViewFontInfo> _list = new ArrayList();

        try {

            stat = conn.createStatement();
            // stat.setFetchSize(10); // 一次只讀10行
            rs = stat.executeQuery(selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                fontViewInfo = setViewFontInfo();
                _list.add(fontViewInfo);
            }
            LoggerInfo.loggerInfo.info("資料庫查詢成功…");

        } catch (SQLException e) {
//            System.out.println("SelectTable Exception :" + e.toString());
//            System.out.println("資料庫連線查詢失敗…");
            LoggerInfo.loggerInfo.info("資料庫查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    //----------ViewImageInfo----------//
    public List<ViewImageInfo> selectViewImageInfo(ViewImageInfo viewImageInfo) {

        String selectSQL = "SELECT * FROM " + viewImageInfo.getTableName() + " Order By PrimaryKey ";
        List<ViewImageInfo> _list = new ArrayList();

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                viewImageInfo = setViewImageInfo();
                _list.add(viewImageInfo);
            }
            LoggerInfo.loggerInfo.info("資料庫查詢成功…");

        } catch (SQLException e) {
//            System.out.println("SelectTable Exception :" + e.toString());
//            System.out.println("資料庫連線查詢失敗…");
            LoggerInfo.loggerInfo.info("資料庫查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    //----------FontInfo----------//
    public List<FontInfo> selectFontInfo(FontInfo fontInfo) {

        String selectSQL = "SELECT * FROM " + fontInfo.getTableName() + " Order By PrimaryKey ";
        List<FontInfo> _list = new ArrayList();

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                fontInfo = setFontInfo();
                _list.add(fontInfo);
            }
            LoggerInfo.loggerInfo.info("資料庫查詢成功…");

        } catch (SQLException e) {
//            System.out.println("SelectTable Exception :" + e.toString());
//            System.out.println("資料庫連線查詢失敗…");
            LoggerInfo.loggerInfo.info("資料庫查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    //----------更新按鈕個數----------//
    public void updateCounts(CountInfo countInfo) {

        String updateSQL = "UPDATE " + countInfo.getTableName() + " SET Counts = ?, InsertDate = ?, InsertTime = ? WHERE Property = ? ";

        try {

            pst = conn.prepareStatement(updateSQL);

            pst.setInt(1, countInfo.getCounts());
            pst.setDate(2, TimeNow.ToSqlDate());
            pst.setTime(3, TimeNow.ToSqlTime());
            pst.setString(4, countInfo.getProperty());

            pst.executeUpdate();
//            System.out.println("資料表更新成功…");
            LoggerInfo.loggerInfo.info("資料表更新成功…");

        } catch (SQLException e) {
//            System.out.println("UpdateDB Exception :" + e.toString());
//            System.out.println("資料表更新失敗…");
            LoggerInfo.loggerInfo.info("資料表更新失敗…");
        } finally {
            closeSQL();
        }
    }

    //----------更新按鈕資訊----------//
    public void updateButtonInfo(int nowID, int nowWidths, int nowHeights, String nowFunctionCodes) {

        String updateSQL = "UPDATE GetTicketMachine.ButtonInfo SET Width = ?, Height = ?, FunctionCode = ?, InsertDate = ?, InsertTime = ? WHERE ID = ? ";

        try {

            pst = conn.prepareStatement(updateSQL);

            pst.setInt(1, nowWidths);
            pst.setInt(2, nowHeights);
            pst.setString(3, nowFunctionCodes);
            pst.setDate(4, TimeNow.ToSqlDate());
            pst.setTime(5, TimeNow.ToSqlTime());
            pst.setInt(6, nowID);

            pst.executeUpdate();
//            System.out.println("資料表更新成功…");
            LoggerInfo.loggerInfo.info("資料表更新成功…");

        } catch (SQLException e) {
//            System.out.println("UpdateDB Exception :" + e.toString());
//            System.out.println("資料表更新失敗…");
            LoggerInfo.loggerInfo.info("資料表更新失敗…");
        } finally {
            closeSQL();
        }
    }

    //----------更新按鈕資訊----------//
    public void updateButtonInfo(ButtonInfo buttonInfo) {

        String updateSQL = "UPDATE " + buttonInfo.getTableName() + " "
                + "SET Width = ?, Height = ?, X = ?, Y = ?, Opacity = ?, Angle = ?, ZoomFactor = ?, InsertDate = ?, InsertTime = ? "
                + "WHERE ButtonName = ?";

        try {

            pst = conn.prepareStatement(updateSQL);

            pst.setInt(1, buttonInfo.getWidth());
            pst.setInt(2, buttonInfo.getHeight());
            pst.setInt(3, buttonInfo.getX());
            pst.setInt(4, buttonInfo.getY());
            pst.setDouble(5, buttonInfo.getOpacity());
            pst.setDouble(6, buttonInfo.getAngle());
            pst.setDouble(7, buttonInfo.getZoomFactor());
            pst.setDate(8, TimeNow.ToSqlDate());
            pst.setTime(9, TimeNow.ToSqlTime());
            pst.setString(10, buttonInfo.getButtonName());

            pst.executeUpdate();
//            System.out.println("資料表更新成功…");
            LoggerInfo.loggerInfo.info("資料表更新成功…");

        } catch (SQLException e) {
//            System.out.println("UpdateDB Exception :" + e.toString());
//            System.out.println("資料表更新失敗…");
            LoggerInfo.loggerInfo.info("資料表更新失敗…");
        } finally {
            closeSQL();
        }
    }

    //----------更新按鈕資訊----------//
    public void updateFunctionInfo(FunctionInfo functionInfo) {

        String updateSQL = "UPDATE " + functionInfo.getTableName() + " "
                + "SET Running = ?, Waitting = ?, InsertDate = ?, InsertTime = ? "
                + "WHERE FunctionCode = ? ";

        try {

            pst = conn.prepareStatement(updateSQL);

            pst.setInt(1, functionInfo.getRunning());
            pst.setInt(2, functionInfo.getWaitting());
            pst.setDate(3, TimeNow.ToSqlDate());
            pst.setTime(4, TimeNow.ToSqlTime());
            pst.setString(5, functionInfo.getFunctionCode());

            pst.executeUpdate();
//            System.out.println("資料表更新成功…");
            LoggerInfo.loggerInfo.info("資料表更新成功…");

        } catch (SQLException e) {
//            System.out.println("UpdateDB Exception :" + e.toString());
//            System.out.println("資料表更新失敗…");
            LoggerInfo.loggerInfo.info("資料表更新失敗…");
        } finally {
            closeSQL();
        }
    }

    //------------------------------------------------------新增數據----------------------------------------------------//
    public void insertTicketInfo(TicketInfo ticketInfo) {

        String insertdbSQL = "INSERT INTO " + ticketInfo.getTableName() + " (Numer, FunctionCode, insertDate, InsertTime) VALUES (?, ?, ?, ?)";

        try {

            pst = conn.prepareStatement(insertdbSQL);
            pst.setInt(1, ticketInfo.getNumer());
            pst.setString(2, ticketInfo.getFunctionCode());
            pst.setDate(3, TimeNow.ToSqlDate());
            pst.setTime(4, TimeNow.ToSqlTime());

            pst.executeUpdate();

//            System.out.println("資料庫連線新增成功…");
            LoggerInfo.loggerInfo.info("資料庫新增成功…");

        } catch (SQLException e) {
//            System.out.println("InsertDB Exception :" + e.toString());
//            System.out.println("資料庫尚未建立…");
            LoggerInfo.loggerInfo.info("資料庫新增失敗…");
        } finally {
            closeSQL();
        }
    }

    //------------------------------------------------------新增數據----------------------------------------------------//
    public void insertFile() {

        ProcessArray processArray = new ProcessArray();

        List<String> list = processArray.ReadFile("src/Data/Text/1.sql");

        String insertdbSQL;

        try {

            for (int i = 0; i < list.size(); i++) {
                insertdbSQL = list.get(i);

                pst = conn.prepareStatement(insertdbSQL);
                pst.executeUpdate();

//                System.out.println("資料庫連線新增成功…");
                LoggerInfo.loggerInfo.info("資料庫新增成功…");
            }

        } catch (SQLException e) {
//            System.out.println("InsertDB Exception :" + e.toString());
//            System.out.println("資料庫尚未建立…");
            LoggerInfo.loggerInfo.info("資料庫新增失敗…");
        } finally {
            closeSQL();
        }
    }

    //----------小工具----------//
    public ButtonInfo setButtonInfo() throws SQLException {

        ButtonInfo _buttonInfo = new ButtonInfo(); // 把Class資料清空

        _buttonInfo.setHeight(rs.getInt("Height"));
        _buttonInfo.setAngle(rs.getDouble("Angle"));
        _buttonInfo.setButtonName(rs.getString("ButtonName"));
        _buttonInfo.setFunctionCode(rs.getString("FunctionCode"));
        _buttonInfo.setHeight(rs.getInt("Height"));
        _buttonInfo.setOpacity(rs.getDouble("Opacity"));
        _buttonInfo.setPrimaryKey(rs.getInt("PrimaryKey"));
        _buttonInfo.setTableName("GetTicketMachine.ButtonInfo");
        _buttonInfo.setWidth(rs.getInt("Width"));
        _buttonInfo.setX(rs.getInt("X"));
        _buttonInfo.setY(rs.getInt("Y"));
        _buttonInfo.setZoomFactor(rs.getDouble("ZoomFactor"));
        _buttonInfo.setID(rs.getInt("ID"));
        _buttonInfo.setInsertStaff(rs.getString("InsertStaff"));
        _buttonInfo.setInsertDate(rs.getDate("InsertDate"));
        _buttonInfo.setInsertTime(rs.getTime("InsertTime"));

        return _buttonInfo;
    }

    public FunctionInfo setFunctionInfo() throws SQLException {

        FunctionInfo _functionInfo = new FunctionInfo(); // 把Class資料清空

        _functionInfo.setFunctionCode(rs.getString("FunctionCode"));
        _functionInfo.setFunctionName(rs.getString("FunctionName"));
        _functionInfo.setPrimaryKey(rs.getInt("PrimaryKey"));
        _functionInfo.setRangeEnd(rs.getInt("RangeEnd"));
        _functionInfo.setRangeStart(rs.getInt("RangeStart"));
        _functionInfo.setRunning(rs.getInt("Running"));
        _functionInfo.setTableName("GetTicketMachine.FunctionInfo");
        _functionInfo.setWaitting(rs.getInt("Waitting"));
        _functionInfo.setImagesURL(rs.getString("ImagesURL"));
        _functionInfo.setInsertDate(rs.getDate("InsertDate"));
        _functionInfo.setInsertTime(rs.getTime("InsertTime"));

        return _functionInfo;
    }

    public TicketInfo setTicketInfo() throws SQLException {

        TicketInfo _ticketInfo = new TicketInfo(); // 把Class資料清空

        _ticketInfo.setFunctionCode(rs.getString("FunctionCode"));
        _ticketInfo.setInsertDate(rs.getDate("InsertDate"));
        _ticketInfo.setInsertTime(rs.getTime("InsertTime"));
        _ticketInfo.setNumer(rs.getInt("Numer"));
        _ticketInfo.setPrimaryKey(rs.getInt("PrimaryKey"));
        _ticketInfo.setStatus(rs.getString("Status"));
        _ticketInfo.setTableName(rs.getString("TableName"));

        return _ticketInfo;
    }

    public ViewFontInfo setViewFontInfo() throws SQLException {

        ViewFontInfo _viewFontInfo = new ViewFontInfo(); // 把Class資料清空

        _viewFontInfo.setBackgroundColorRGB(rs.getString("BackgroundColorRGB"));
        _viewFontInfo.setColorRGB(rs.getString("ColorRGB"));
        _viewFontInfo.setFontName(rs.getString("FontName"));
        _viewFontInfo.setInsertDate(rs.getDate("InsertDate"));
        _viewFontInfo.setInsertStaff(rs.getString("InsertStaff"));
        _viewFontInfo.setInsertTime(rs.getTime("InsertTime"));
        _viewFontInfo.setPrimaryKey(rs.getInt("PrimaryKey"));
        _viewFontInfo.setSizes(rs.getInt("Sizes"));
        _viewFontInfo.setTableName(rs.getString("TableName"));
        _viewFontInfo.setTexts(rs.getString("Texts"));
        _viewFontInfo.setTypeCode(rs.getInt("TypeCode"));
        _viewFontInfo.setViewFontName(rs.getString("ViewFontName"));
        _viewFontInfo.setX(rs.getInt("X"));
        _viewFontInfo.setY(rs.getInt("Y"));
        _viewFontInfo.setProperty(rs.getString("Property"));

        return _viewFontInfo;
    }

    public ViewImageInfo setViewImageInfo() throws SQLException {

        ViewImageInfo _viewImageInfo = new ViewImageInfo(); // 把Class資料清空

        _viewImageInfo.setInsertDate(rs.getDate("InsertDate"));
        _viewImageInfo.setInsertStaff(rs.getString("InsertStaff"));
        _viewImageInfo.setInsertTime(rs.getTime("InsertTime"));
        _viewImageInfo.setPaths(rs.getString("Paths"));
        _viewImageInfo.setPrimaryKey(rs.getInt("PrimaryKey"));
        _viewImageInfo.setProperty(rs.getString("Property"));
        _viewImageInfo.setViewImageName(rs.getString("ViewImageName"));
        _viewImageInfo.setX(rs.getInt("X"));
        _viewImageInfo.setY(rs.getInt("Y"));

        return _viewImageInfo;
    }

    public CountInfo setCountInfo() throws SQLException {

        CountInfo _countInfo = new CountInfo(); // 把Class資料清空

        _countInfo.setCounts(rs.getInt("Counts"));
        _countInfo.setInsertDate(rs.getDate("InsertDate"));
        _countInfo.setInsertStaff(rs.getString("InsertStaff"));
        _countInfo.setInsertTime(rs.getTime("InsertTime"));
        _countInfo.setPrimaryKey(rs.getInt("PrimaryKey"));
        _countInfo.setProperty(rs.getString("Property"));
        _countInfo.setTableName(rs.getString("TableName"));

        return _countInfo;
    }

    public ButtonFunctionInfo setButtonFunctionInfo() throws SQLException {

        ButtonFunctionInfo _buttonFunctionInfo = new ButtonFunctionInfo(); // 把Class資料清空

        _buttonFunctionInfo.setButtonName(rs.getString("ButtonName"));
        _buttonFunctionInfo.setFunctionCode(rs.getString("FunctionCode"));
        _buttonFunctionInfo.setFunctionName(rs.getString("FunctionName"));
        _buttonFunctionInfo.setImagesURL(rs.getString("ImagesURL"));
        _buttonFunctionInfo.setPrimaryKey(rs.getInt("PrimaryKey"));

        return _buttonFunctionInfo;
    }

    public FontInfo setFontInfo() throws SQLException {

        FontInfo _fontInfo = new FontInfo(); // 把Class資料清空

        _fontInfo.setFontCode(rs.getString("FontCode"));
        _fontInfo.setFontName(rs.getString("FontName"));
        _fontInfo.setInsertDate(rs.getDate("InsertDate"));
        _fontInfo.setInsertStaff(rs.getString("InsertStaff"));
        _fontInfo.setInsertTime(rs.getTime("InsertTime"));
        _fontInfo.setPrimaryKey(rs.getInt("PrimaryKey"));
        _fontInfo.setProperty(rs.getString("Property"));
        _fontInfo.setTableName(rs.getString("TableName"));

        return _fontInfo;
    }

    //----------列印輸出----------//
    public void printButtonInfo(ButtonInfo buttonInfo) {
        //System.out.println("PrimaryKey" + "\t" + "ButtonName" + "\t" + "X" + "\t" + "Y" + "\t" + "Width" + "\t" + "Height" + "\t" + "Angle" + "\t" + "ZoomFactor" + "\t" + "Opacity" + "\t" + "FuntionCode" + "\t" + "TableName" + "\t" + "InsertStaff" + "\t" + "InsertDate" + "\t" + "InsertTime");

        System.out.print(buttonInfo.getPrimaryKey() + "\t");
        System.out.print(buttonInfo.getButtonName() + "\t");
        System.out.print(buttonInfo.getID() + "\t");
        System.out.print(buttonInfo.getX() + "\t");
        System.out.print(buttonInfo.getY() + "\t");
        System.out.print(buttonInfo.getWidth() + "\t");
        System.out.print(buttonInfo.getHeight() + "\t");
        System.out.print(buttonInfo.getAngle() + "\t");
        System.out.print(buttonInfo.getZoomFactor() + "\t");
        System.out.print(buttonInfo.getOpacity() + "\t");
        System.out.print(buttonInfo.getFunctionCode() + "\t");
        System.out.print(buttonInfo.getTableName() + "\t");
        System.out.print(buttonInfo.getInsertStaff() + "\t");
        System.out.print(buttonInfo.getInsertDate() + "\t");
        System.out.print(buttonInfo.getInsertTime() + "\n");
    }

    public void printFunctionInfo(FunctionInfo functionInfo) {
        // System.out.println("PrimaryKey" + "\t" + "FunctionCode" + "\t" + "FunctionName" + "\t" + "RangeStart" + "\t" + "RangeEnd" + "\t" + "Running" + "\t" + "TableName" + "\t" + "Waitting" + "\t" + "ImagesURL" + "\t" + "InsertDate" + "\t" + "InsertTime");

        System.out.print(functionInfo.getPrimaryKey() + "\t");
        System.out.print(functionInfo.getFunctionCode() + "\t");
        System.out.print(functionInfo.getFunctionName() + "\t");
        System.out.print(functionInfo.getRangeStart() + "\t");
        System.out.print(functionInfo.getRangeEnd() + "\t");
        System.out.print(functionInfo.getRunning() + "\t");
        System.out.print(functionInfo.getTableName() + "\t");
        System.out.print(functionInfo.getWaitting() + "\t");
        System.out.print(functionInfo.getImagesURL() + "\t");
        System.out.print(functionInfo.getInsertDate() + "\t");
        System.out.print(functionInfo.getInsertTime() + "\n");
    }

    public void printTicketInfo(TicketInfo ticketInfo) {
        //System.out.println("PrimaryKey" + "\t" + "Numer" + "\t" + "FunctionCode" + "\t" + "Status" + "\t" + "TableName" + "\t" + "InsertDate" + "\t" + "InsertTime");

        System.out.print(ticketInfo.getPrimaryKey() + "\t");
        System.out.print(ticketInfo.getNumer() + "\t");
        System.out.print(ticketInfo.getFunctionCode() + "\t");
        System.out.print(ticketInfo.getStatus() + "\t");
        System.out.print(ticketInfo.getTableName() + "\t");
        System.out.print(ticketInfo.getInsertDate() + "\t");
        System.out.print(ticketInfo.getInsertTime() + "\n");
    }

    public void printViewFontInfo(ViewFontInfo viewFontInfo) {
        //System.out.println("PrimaryKey" + "\t" + "Texts" + "\t" + "X" + "\t" + "Y" + "\t" + "Fonts" + "\t" + "Sizes" + "\t" + "Types" + "\t" + "ColorRGB" + "\t" + "BackgroundColorRGB" + "\t" + "InsertStaff" + "\t" + "InsertDate" + "\t" + "InsertTime" + "\t" + "TableName");

        System.out.print(viewFontInfo.getPrimaryKey() + "\t");
        System.out.print(viewFontInfo.getTexts() + "\t");
        System.out.print(viewFontInfo.getX() + "\t");
        System.out.print(viewFontInfo.getY() + "\t");
        System.out.print(viewFontInfo.getFontName() + "\t");
        System.out.print(viewFontInfo.getSizes() + "\t");
        System.out.print(viewFontInfo.getTypeCode() + "\t");
        System.out.print(viewFontInfo.getColorRGB() + "\t");
        System.out.print(viewFontInfo.getBackgroundColorRGB() + "\t");
        System.out.print(viewFontInfo.getInsertStaff() + "\t");
        System.out.print(viewFontInfo.getInsertDate() + "\t");
        System.out.print(viewFontInfo.getInsertTime() + "\t");
        System.out.print(viewFontInfo.getProperty() + "\t");
        System.out.print(viewFontInfo.getViewFontName() + "\t");
        System.out.print(viewFontInfo.getTableName() + "\n");
    }

    public void printViewImageInfo(ViewImageInfo viewImageInfo) {
        //System.out.println("PrimaryKey" + "\t" + "X" + "\t" + "Y" + "\t" + "Paths" + "\t" + "Property" + "\t" + "TableName" + "\t" + "InsertStaff" + "\t" + "InsertDate" + "\t" + "InsertTime");

        System.out.print(viewImageInfo.getPrimaryKey() + "\t");
        System.out.print(viewImageInfo.getX() + "\t");
        System.out.print(viewImageInfo.getY() + "\t");
        System.out.print(viewImageInfo.getPaths() + "\t");
        System.out.print(viewImageInfo.getProperty() + "\t");
        System.out.print(viewImageInfo.getTableName() + "\t");
        System.out.print(viewImageInfo.getViewImageName() + "\t");
        System.out.print(viewImageInfo.getInsertStaff() + "\t");
        System.out.print(viewImageInfo.getInsertDate() + "\t");
        System.out.print(viewImageInfo.getInsertTime() + "\n");
    }

    public void printCountInfo(CountInfo countInfo) {
        //System.out.println("PrimaryKey" + "\t" + "Counts" + "\t" + "Property" + "\t" + "TableName" + "\t" + "InsertStaff" + "\t" + "InsertDate" + "InsertTime");

        System.out.print(countInfo.getPrimaryKey() + "\t");
        System.out.print(countInfo.getCounts() + "\t");
        System.out.print(countInfo.getProperty() + "\t");
        System.out.print(countInfo.getTableName() + "\t");
        System.out.print(countInfo.getInsertStaff() + "\t");
        System.out.print(countInfo.getInsertDate() + "\t");
        System.out.print(countInfo.getInsertTime() + "\n");
    }

    public void printButtonFunctionInfo(ButtonFunctionInfo buttonFunctionInfo) {
        // System.out.println("PrimaryKey" + "\t" + "ButtonName" + "\t" + "FunctionCode" + "\t" + "FunctionName" + "\t" + "ImagesURL");

        System.out.print(buttonFunctionInfo.getPrimaryKey() + "\t");
        System.out.print(buttonFunctionInfo.getButtonName() + "\t");
        System.out.print(buttonFunctionInfo.getFunctionCode() + "\t");
        System.out.print(buttonFunctionInfo.getFunctionName() + "\t");
        System.out.print(buttonFunctionInfo.getImagesURL() + "\n");

    }

    public void printFontInfo(FontInfo fontInfo) {
        // System.out.println("PrimaryKey" + "\t" + "FontCode" + "\t" + "FontName" + "\t" + "Property" + "\t" + "TableName" + "\t" + "InsertStaff" + "\t" + "InsertDate" + "InsertTime");

        System.out.print(fontInfo.getPrimaryKey() + "\t");
        System.out.print(fontInfo.getFontCode() + "\t");
        System.out.print(fontInfo.getFontName() + "\t");
        System.out.print(fontInfo.getProperty() + "\t");
        System.out.print(fontInfo.getTableName() + "\t");
        System.out.print(fontInfo.getInsertStaff() + "\t");
        System.out.print(fontInfo.getInsertDate() + "\t");
        System.out.print(fontInfo.getInsertTime() + "\n");

    }
}
