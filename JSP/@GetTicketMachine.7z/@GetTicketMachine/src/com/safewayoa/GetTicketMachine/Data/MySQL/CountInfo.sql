DROP TABLE IF EXISTS GetTicketMachine.CountInfo; -- 刪除資料表

CREATE TABLE GetTicketMachine.CountInfo(
    PrimaryKey INTEGER(1) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
    Counts INTEGER(2) DEFAULT 3, -- 按鍵的數量
    Property VARCHAR(10) DEFAULT '----', -- 圖形特性
    TableName VARCHAR(32) DEFAULT 'GetTicketMachine.CountInfo', -- 功能識別碼
    InsertStaff VARCHAR(4) DEFAULT '----', -- 修改人員
    InsertDate DATE DEFAULT '1970-01-01', -- 修改日期
    InsertTime TIME DEFAULT '00:00:00' -- 修改時間
);

INSERT INTO GetTicketMachine.CountInfo (PrimaryKey, Counts, Property) VALUES (1, 3, 'Counts');
INSERT INTO GetTicketMachine.CountInfo (PrimaryKey, Counts, Property) VALUES (2, 2, 'ViewFont');
INSERT INTO GetTicketMachine.CountInfo (PrimaryKey, Counts, Property) VALUES (3, 1, 'ViewImage');
