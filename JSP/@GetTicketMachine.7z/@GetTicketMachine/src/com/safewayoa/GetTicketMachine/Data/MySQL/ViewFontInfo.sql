DROP TABLE IF EXISTS GetTicketMachine.ViewFontInfo; -- 刪除資料表

CREATE TABLE GetTicketMachine.ViewFontInfo(
    PrimaryKey INTEGER(2) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
    X INTEGER(4) DEFAULT 0, -- X坐標
    Y INTEGER(4) DEFAULT 0, -- Y坐標
    Sizes INTEGER(2) DEFAULT 12, -- 字體大小
    TypeCode INTEGER(1) DEFAULT 0, -- 粗體、斜體(0~3)
    Texts VARCHAR(255) DEFAULT '----', -- 文字內容
    FontName VARCHAR(255) DEFAULT '----', -- 字體名稱(新細明體)
    ColorRGB VARCHAR(12) DEFAULT '0,0,0', -- 字體前景色
    BackgroundColorRGB VARCHAR(12) DEFAULT '255,255,255', -- 字體背景色
    TableName VARCHAR(32) DEFAULT 'GetTicketMachine.ViewFontInfo', -- 資料表名稱
    Property VARCHAR(15) DEFAULT '----', -- 文字特性
    ViewFontName VARCHAR(10) UNIQUE DEFAULT '----', -- 文字特性
    InsertStaff VARCHAR(4) DEFAULT '----', -- 修改人員
    InsertDate DATE DEFAULT '1970-01-01', -- 修改日期
    InsertTime TIME DEFAULT '00:00:00' -- 修改時間
);

INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (1, '28934823', 'Number', 'ViewFont1', '25', '90', '30');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (2, '2014-10-10 12:00:00', 'Time', 'ViewFont2', '30', '240', '14');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (3, '業務類型', 'BusinessTypes', 'ViewFont3', '58', '65', '14');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (4, '大鑫資訊股份有限公司', '----', 'ViewFont4', '25', '10', '14');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (5, '新北市新店區民權路104號4樓', '----', 'ViewFont5', '10', '135', '12');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (6, 'TEL:02-2218-1199', '----', 'ViewFont6', '30', '165', '14');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (7, 'FAX:02-2218-2255', '----', 'ViewFont7', '30', '185', '14');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (8, '銀行、辦公耗材第一選擇', '----', 'ViewFont8', '15', '36', '14');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (9, 'http://safewayoa.myweb.hinet.net/', '----', 'ViewFont9', '15', '205', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (10, 'http://www.pcstore.com.tw/taiwan100/', '----', 'ViewFont10', '5', '220', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (11, '-----備用1-----', '----', 'ViewFont11', '5', '350', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (12, '-----備用2-----', '----', 'ViewFont12', '5', '365', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (13, '-----備用3-----', '----', 'ViewFont13', '5', '380', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (14, '-----備用4-----', '----', 'ViewFont14', '5', '395', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (15, '-----備用5-----', '----', 'ViewFont15', '5', '410', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (16, '-----備用6-----', '----', 'ViewFont16', '5', '425', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (17, '-----備用7-----', '----', 'ViewFont17', '5', '440', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (18, '-----備用8-----', '----', 'ViewFont18', '5', '455', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (19, '-----備用9-----', '----', 'ViewFont19', '5', '470', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (20, '-----備用10-----', '----', 'ViewFont20', '5', '485', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (21, '-----備用11-----', '----', 'ViewFont21', '90', '350', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (22, '-----備用12-----', '----', 'ViewFont22', '90', '365', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (23, '-----備用13-----', '----', 'ViewFont23', '90', '380', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (24, '-----備用14-----', '----', 'ViewFont24', '90', '395', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (25, '-----備用15-----', '----', 'ViewFont25', '90', '410', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (26, '-----備用16-----', '----', 'ViewFont26', '90', '425', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (27, '-----備用17-----', '----', 'ViewFont27', '90', '440', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (28, '-----備用18-----', '----', 'ViewFont28', '90', '455', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (29, '-----備用19-----', '----', 'ViewFont29', '90', '470', '10');
INSERT INTO GetTicketMachine.ViewFontInfo(PrimaryKey, Texts, Property, ViewFontName, X, Y, Sizes) VALUES (30, '-----備用20-----', '----', 'ViewFont30', '90', '485', '10');