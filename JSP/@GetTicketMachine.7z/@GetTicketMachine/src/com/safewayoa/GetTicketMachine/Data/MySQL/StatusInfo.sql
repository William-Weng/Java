DROP TABLE IF EXISTS GetTicketMachine.StatusInfo; -- 刪除資料表

CREATE TABLE GetTicketMachine.StatusInfo(
    PrimaryKey INTEGER(1) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
    StatusCode VARCHAR(10) NOT NULL, -- 按鍵的數量
    StatusName VARCHAR(32) NOT NULL, -- 功能識別碼
    InsertStaff VARCHAR(4) DEFAULT '----', -- 修改人員
    InsertDate DATE DEFAULT '1970-01-01', -- 修改日期
    InsertTime TIME DEFAULT '00:00:00' -- 修改時間
);

INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (1, 'OK', '處理完畢');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (2, 'Doing', '處理中');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (3, '----', '未處理');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (4, 'Transfer', '轉櫃');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (5, 'Others', '其它');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (6, '----', '----');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (7, '----', '----');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (8, '----', '----');
INSERT INTO GetTicketMachine.StatusInfo (PrimaryKey, StatusCode, StatusName) VALUES (9, '----', '----');
