DROP TABLE IF EXISTS GetTicketMachine.ViewImageInfo; -- 刪除資料表

CREATE TABLE GetTicketMachine.ViewImageInfo(
    PrimaryKey INTEGER(2) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
    X INTEGER(4) DEFAULT 0, -- X坐標
    Y INTEGER(4) DEFAULT 0, -- Y坐標
    Paths VARCHAR(255) DEFAULT '----.gif',
    TableName VARCHAR(32) DEFAULT 'GetTicketMachine.ViewImageInfo', -- 資料表名稱
    Property VARCHAR(10) DEFAULT '----', -- 圖形特性
    ViewImageName VARCHAR(15) UNIQUE DEFAULT '----', -- 圖形特性
    InsertStaff VARCHAR(4) DEFAULT '----', -- 修改人員
    InsertDate DATE DEFAULT '1970-01-01', -- 修改日期
    InsertTime TIME DEFAULT '00:00:00' -- 修改時間
);

INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (1, 'Image/TicketInfo/1.png', 5, 265, 'Logo', 'ViewImage1');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (2, 'Image/TicketInfo/2.png', 37, 265, 'Advertise', 'ViewImage2');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (3, 'Image/TicketInfo/3.png', 69, 265, 'QR-Code', 'ViewImage3');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (4, 'Image/TicketInfo/4.png', 101, 265, '----', 'ViewImage4');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (5, 'Image/TicketInfo/5.png', 133, 265, '----', 'ViewImage5');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (6, 'Image/TicketInfo/6.png', 5, 300, '----', 'ViewImage6');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (7, 'Image/TicketInfo/7.png', 37, 300, '----', 'ViewImage7');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (8, 'Image/TicketInfo/8.png', 69, 300, '----', 'ViewImage8');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (9, 'Image/TicketInfo/9.png', 101, 300, '----', 'ViewImage9');
INSERT INTO GetTicketMachine.ViewImageInfo(PrimaryKey, Paths, X, Y, Property, ViewImageName) VALUES (10, 'Image/TicketInfo/10.png', 133, 300, '----', 'ViewImage10');
