

import Tools.Utility.PlaySound;
import java.util.Random;

public class RandomClass {

    public static void main(String[] args) {

        PlaySound playSound = new PlaySound();
        Random random = new Random();

    }
}
