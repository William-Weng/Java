package Main;

/**
 * 請看加了註釋的兩行，要改變標題欄的顯示狀態， 關鍵代碼就是這兩行，第1行去掉窗口的裝飾， 第2行為窗口指定頭飾風格。 方法為窗口指定以下的裝飾風格：
 * NONE 無裝飾（即去掉標題欄） FRAME 普通窗口風格 PLAIN_DIALOG 簡單對話框風格 INFORMATION_DIALOG 信息對話框風格
 * ERROR_DIALOG 錯誤對話框風格 COLOR_CHOOSER_DIALOG 拾色器對話框風格 FILE_CHOOSER_DIALOG
 * 文件選擇對話框風格 QUESTION_DIALOG 問題對話框風格 WARNING_DIALOG 警告對話框風格
 *
 */
import Data.Model.Counts;
import Data.Model.AxisJButtonRun;
import Data.Model.JButtonInfo;
import Data.Model.Range;
import Data.Model.SizeJButtonClose;
import Data.Model.SizeJButtonRun;
import Data.Model.SizeJButtonSetup;
import Tools.MySQL.DatabaseUtility;
import Tools.Utility.ProcessFrame;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import Tools.Utility.PlaySound;
import Tools.Utility.Printer;
import Tools.Utility.ProcessWord;
import Tools.Utility.TimeNow;
import java.awt.event.MouseMotionListener;
import java.util.Random;

public class Menu extends JFrame {

    Counts counts; // 初始化個數…
    JButton[] jButtonClose;
    JButton[] jButtonSetup;
    JButton[] jButtonRun;
    JButtonInfo[] jButtonInfo;
    Range[] range;

    Container ContentPane;

    TimeNow timeNow;
    Printer printer;

    String sPassword = "";
    int widthAll;
    int heightAll;
    boolean isDrag = true;

    public Menu() {
        // 取得最底層容器…
        ContentPane = this.getContentPane(); // 取得容器實體…
        ContentPane.setLayout(null); // 容器的排列方法…

        ContentPane.setBackground(Color.magenta);

        Dimension ScreenSize = Toolkit.getDefaultToolkit().getScreenSize(); // 取得當前螢幕解析度…
        widthAll = (int) ScreenSize.getWidth() / 2;
        heightAll = (int) ScreenSize.getHeight() / 2;

        this.initJButtonClose();
        this.initJButtonRun();
        this.initJButtonSetup();

        this.setUndecorated(true); // 去掉視窗的裝飾
        this.getRootPane().setWindowDecorationStyle(JRootPane.NONE); // 採用指定的窗口裝飾風格
        this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE); // 設定視窗關閉按鈕…
        this.setSize(widthAll, heightAll);
        this.setVisible(true);
    }
//--------------------------------------------------按鈕動作-------------------------------------------------------//

    private void initJButtonClose() {

        int widthClose = 50;
        int heightClose = 50;

        jButtonClose = new JButton[4];
        SizeJButtonClose[] sizes = new SizeJButtonClose[jButtonClose.length];

        sizes[0] = new SizeJButtonClose(0, 0, widthClose, heightClose);
        sizes[1] = new SizeJButtonClose(widthAll - widthClose, 0, widthClose, heightClose);
        sizes[2] = new SizeJButtonClose(widthAll - widthClose, heightAll - heightClose, widthClose, heightClose);
        sizes[3] = new SizeJButtonClose(0, heightAll - heightClose, widthClose, heightClose);

        for (int i = 0; i < jButtonClose.length; i++) {
            jButtonClose[i] = new JButton();
            jButtonClose[i].addActionListener(new jButtonCloseListener()); // 使用按鍵的動作方式…
            jButtonClose[i].setBounds(sizes[i].getX_Axis(), sizes[i].getY_Axis(), sizes[i].getWidth(), sizes[i].getHeight());
            jButtonClose[i].setOpaque(false);
            jButtonClose[i].setBorder(null);
            jButtonClose[i].setPreferredSize(null);
            // jButtonClose[i].setContentAreaFilled(false);
            ContentPane.add(jButtonClose[i]);
        }
    }

    private void initJButtonSetup() {

        int widthClose = 100;
        int heightClose = 50;
        String[] str = {"記錄", "讀取", "初始", "設定"};
        jButtonSetup = new JButton[4];
        SizeJButtonSetup[] sizes = new SizeJButtonSetup[jButtonSetup.length];
        sizes[0] = new SizeJButtonSetup(100, 0, widthClose, heightClose);
        sizes[1] = new SizeJButtonSetup(300, 0, widthClose, heightClose);
        sizes[2] = new SizeJButtonSetup(500, 0, widthClose, heightClose);
        sizes[3] = new SizeJButtonSetup(700, 0, widthClose, heightClose);

        for (int i = 0; i < jButtonSetup.length; i++) {
            jButtonSetup[i] = new JButton(str[i]);
            jButtonSetup[i].addActionListener(new jButtonSetupListener()); // 使用按鍵的動作方式…
            jButtonSetup[i].setBounds(sizes[i].getX_Axis(), sizes[i].getY_Axis(), sizes[i].getWidth(), sizes[i].getHeight());
            jButtonSetup[i].setOpaque(false);
            jButtonSetup[i].setBorder(null);
            jButtonSetup[i].setPreferredSize(null);
            // jButtonClose[i].setContentAreaFilled(false);
            ContentPane.add(jButtonSetup[i]);
        }
    }

    private void initJButtonRun() {

        int gap = 20;

        counts = new Counts();
        jButtonRun = new JButton[counts.getCounts()];
        jButtonInfo = new JButtonInfo[jButtonRun.length];
        range = new Range[jButtonRun.length];

        range[0] = new Range(1, 100);
        range[1] = new Range(101, 200);

        SizeJButtonRun sizes = new SizeJButtonRun(jButtonRun.length, widthAll, heightAll, gap);

        JButtonRunListener jButtonRunListener = new JButtonRunListener();

        for (int i = 0; i < jButtonRun.length; i++) {

            AxisJButtonRun axisRun = new AxisJButtonRun(i + 1, sizes);

            jButtonRun[i] = new JButton("" + i);
            jButtonRun[i].addActionListener(jButtonRunListener); // 當按鍵按下時…
            jButtonRun[i].addMouseListener(jButtonRunListener); // 當滑鼠按下時…
            jButtonRun[i].addMouseMotionListener(jButtonRunListener); // 當滑鼠拖曳時…
            jButtonRun[i].setBounds(axisRun.getX_Axis(), axisRun.getY_Axis(), sizes.getWidth(), sizes.getHeight());
            jButtonRun[i].setVerticalAlignment(AbstractButton.BOTTOM);
            jButtonRun[i].setOpaque(false); // 設定透明…
            jButtonRun[i].setBorder(null); // 設定框線…
            // jButtonClose[i].setContentAreaFilled(false);
            ContentPane.add(jButtonRun[i]);

            jButtonInfo[i] = new JButtonInfo(i, sizes.getWidth(), sizes.getHeight(), axisRun.getX_Axis(), axisRun.getY_Axis(), "GetTicketMachine.JButtonInfo"); // 存相關數據…
        }
    }

    class jButtonCloseListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            int ID = ProcessFrame.JObjectWhichOne(e.getSource(), jButtonClose); // 看按到哪個按鈕…
            System.out.println("ID = " + ID);

            sPassword += ID;

            System.out.println("sPassword = " + sPassword);
            System.out.println("sPassword.length = " + sPassword.length());

            switch (sPassword) {

                case "0123": // sPassword = 0123，就結束程式…
                    System.exit(0);
                    break;
                case "0321": // sPassword = 0321，開閉功能按鍵移動…
                    isDrag = !isDrag;
                    System.out.println("isDrag = " + isDrag);
                    break;
                default:
                    System.out.println("Hello!!!");
            }

            if (sPassword.length() >= 4) { // sPassword只能有四個字
                System.out.println(sPassword.substring(1, 4));
                sPassword = sPassword.substring(1, 4); // 把第一個字去除，只留下後三個字…
            }
        }
    }

    class JButtonRunListener extends MouseAdapter implements ActionListener, MouseMotionListener {

        int x0, y0;

        @Override // 當按下時播放聲音…
        public void actionPerformed(ActionEvent e) {

            if (!isDrag == true) {
                int ID = ProcessFrame.JObjectWhichOne(e.getSource(), jButtonRun); // 看按到哪個按鈕…
                System.out.println("ID = " + ID);

                PlaySound playSound = new PlaySound();
                Random random = new Random();

                // playSound.playWav(random.nextInt(1000), random.nextInt(6));
            }
        }

        @Override // 取得滑鼠按下的相對初值位置(x0,y0)…
        public void mousePressed(MouseEvent e) {
            int ID = ProcessFrame.JObjectWhichOne(e.getSource(), jButtonRun); // 看按到哪個按鈕…

            x0 = e.getX();
            y0 = e.getY();
            int number = range[ID].getRunning();

            timeNow = new TimeNow();
            printer = new Printer();

            if (!isDrag == true) { // 不能拖曳才能印
                printer.PrintNumber(ProcessWord.IntToString(number), timeNow.getsAllTime());
                number++;
                range[ID].setRunning(number);
                System.out.println("x0=" + x0 + " , y0=" + y0);
                System.out.println("range[ID].getRunning() = " + range[ID].getRunning());
            }
        }

        @Override // 當滑鼠拖曳時移動該物件…
        public void mouseDragged(MouseEvent e) {

            Container _jObject = new Container(); // 找爸爸來當共用變數…

            int ID = 0, x = 0, y = 0;

            if (!isDrag == false) {

                if (e.getSource() instanceof JButton) {

                    _jObject = (JButton) e.getSource();
                    ID = ProcessFrame.JObjectWhichOne(e.getSource(), jButtonRun); // 看拖到哪一個JLabel
                    x = _jObject.getX() + e.getX() - x0;
                    y = _jObject.getY() + e.getY() - y0;
                    setJButtonInfo(ID, x, y, (JButton) _jObject);

                } else {
                    System.out.println("I am Obj");
                }

                System.out.println("X=" + x + " ,Y" + y);

                _jObject.setLocation(x, y); // 算出移動的位置，將JButton移動至此…
            }
        }

        @Override // 滑鼠放開後，讓Label邊框消失…
        public void mouseReleased(MouseEvent e) {
//            for (int i = 1; i < jButtonRun.length; i++) {
//                jButtonRun[i].setBorder(BorderFactory.createEmptyBorder()); // 去除邊框…
//            }
        }

        @Override
        public void mouseMoved(MouseEvent e) {
        }
    }

    class jButtonSetupListener implements ActionListener {

        int ID;
        DatabaseUtility utilDB = new DatabaseUtility();

        @Override
        public void actionPerformed(ActionEvent e) {

            ID = ProcessFrame.JObjectWhichOne(e.getSource(), jButtonSetup);

            switch (ID) {

                case 0: // 記錄位置
                    System.out.println(jButtonSetup[ID].getText());

                    for (int i = 0; i < jButtonRun.length; i++) {
                        utilDB.update(jButtonInfo[i]);
                    }

                    break;

                case 1: // 讀取位置
                    System.out.println(jButtonSetup[ID].getText());

                    java.util.List<JButtonInfo> _list;
                    _list = utilDB.select(new JButtonInfo());

                    for (int i = 0; i < jButtonRun.length; i++) {
                        jButtonRun[i].setBounds(_list.get(i).getX_Axis(), _list.get(i).getY_Axis(), _list.get(i).getWidth(), _list.get(i).getHeight());
                    }

                    break;

                case 2: // 初始設定
                    reload();
                    break;

                case 3: // 初始設定
                    break;

                default:
                    break;
            }
        }
    }

    public void setJButtonInfo(int ID, int x, int y, JButton jButton) {

        jButtonInfo[ID].setId(ID);
        jButtonInfo[ID].setX_Axis(x);
        jButtonInfo[ID].setY_Axis(y);
        jButtonInfo[ID].setWidth(jButton.getWidth());
        jButtonInfo[ID].setHeight(jButton.getHeight());
        jButtonInfo[ID].setTableName("GetTicketMachine.JButtonInfo");

        System.out.println("JButtonInfo[" + ID + "].getID()" + jButtonInfo[ID].getId());
        System.out.println("JButtonInfo[" + ID + "].getX_Axis()" + jButtonInfo[ID].getX_Axis());
        System.out.println("JButtonInfo[" + ID + "].getY_Axis()" + jButtonInfo[ID].getY_Axis());
        System.out.println("JButtonInfo[" + ID + "].getWidth()" + jButtonInfo[ID].getWidth());
        System.out.println("JButtonInfo[" + ID + "].getHeight()" + jButtonInfo[ID].getHeight());

    }

    public void reload() {
        for (JButton jButtonRun1 : jButtonRun) { // 先將JButton清除，再new回來
            ContentPane.remove(jButtonRun1);
        }

        initJButtonRun();
        ContentPane.repaint();
        System.out.println("");

    }

    public static void main(String[] args) {
        JFrame frame = new Menu();
    }
}
