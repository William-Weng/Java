package Main;

import Data.Model.Counts;
import Data.Model.JButtonInfo;
import Tools.MySQL.DatabaseUtility;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRootPane;
import javax.swing.WindowConstants;

public class Setup extends JFrame {

    private final static String[] sCounts = {
        "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"}; // 設定字體大小(pt)…

    private final static String[] sSize = {
        "20", "40", "60", "80", "100",
        "120", "140", "160", "180", "200",
        "220", "240", "260", "280", "300"}; // 設定字體大小(pt)…

    int iWidthAll, iHeightAll;
    int iSelectCounts;

    Container ContentPane;

    JComboBox jComboBoxCounts;
    JButton jButtonCounts, jButtonSize;
    JLabel jLabelCounts;
    DatabaseUtility utilDB;

    JLabel jLabelSize;
    JComboBox jComboBoxSize_Width, jComboBoxSize_Height;
    JButtonInfo[] jButtonInfo;
    Counts counts; // 初始化個數…

    public Setup() {

        ContentPane = this.getContentPane(); // 取得容器實體…
        ContentPane.setLayout(null); // 容器的排列方法…
        ContentPane.setBackground(Color.orange);

        Dimension ScreenSize = Toolkit.getDefaultToolkit().getScreenSize(); // 取得當前螢幕解析度…
        iWidthAll = (int) ScreenSize.getWidth() / 2;
        iHeightAll = (int) ScreenSize.getHeight() / 2;

        this.initNumber();
        this.initModel();
        this.initJComboBox();
        this.initJButton();
        this.initJLabel();

        this.setUndecorated(true); // 去掉視窗的裝飾
        this.getRootPane().setWindowDecorationStyle(JRootPane.PROPERTIES); // 採用指定的窗口裝飾風格
        this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE); // 設定視窗關閉按鈕…
        this.setBounds(256, 256, iWidthAll, iHeightAll);
        this.setVisible(true);
    }

    private void initNumber() {
        utilDB = new DatabaseUtility();
        utilDB.closeSQL();
        counts = new Counts();
    }

    private void initModel() {

        List<JButtonInfo> _list = utilDB.select(new JButtonInfo());

        jButtonInfo = new JButtonInfo[_list.size()];

        for (int i = 0; i < jButtonInfo.length; i++) {
            jButtonInfo[i] = _list.get(i);
        }
    }

    private void initJLabel() {
        jLabelCounts = new JLabel("設定按鍵個數…");
        jLabelCounts.setBounds(20, 20, 100, 30);

        jLabelSize = new JLabel("測試用…");
        jLabelSize.setBounds(200, 20, 100, 100);

        ContentPane.add(jLabelSize);
        ContentPane.add(jLabelCounts);
    }

    private void initJButton() {
        jButtonCounts = new JButton("送出");
        jButtonCounts.setBounds(200, 20, 60, 30);
        jButtonCounts.addActionListener(new JButtonCountsActionListener());

        jButtonSize = new JButton("寫入");
        jButtonSize.setBounds(300, 200, 100, 100);
        jButtonSize.addActionListener(new JButtonSizeActionListener());

        ContentPane.add(jButtonCounts);
        ContentPane.add(jButtonSize);
    }

    private void initJComboBox() {
        jComboBoxCounts = new JComboBox(sCounts);
        jComboBoxCounts.setBounds(120, 20, 60, 30);
        jComboBoxCounts.addActionListener(new JComboBoxCountsActionListener());

        jComboBoxSize_Width = new JComboBox(sSize);
        jComboBoxSize_Width.setBounds(200, 200, 50, 50);
        jComboBoxSize_Width.addActionListener(new JComboBoxSizeActionListener_Width());

        jComboBoxSize_Height = new JComboBox(sSize);
        jComboBoxSize_Height.setBounds(250, 200, 50, 50);
        jComboBoxSize_Height.addActionListener(new JComboBoxSizeActionListener_Height());

        ContentPane.add(jComboBoxCounts);
        ContentPane.add(jComboBoxSize_Width);
        ContentPane.add(jComboBoxSize_Height);
    }

    class JComboBoxCountsActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            JComboBox temp = (JComboBox) e.getSource();
            iSelectCounts = temp.getSelectedIndex();
            System.out.println("selectCounts = " + sCounts[iSelectCounts]);
        }
    }

    class JComboBoxSizeActionListener_Width implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            // int ID = ProcessFrame.JObjectWhichOne(e.getSource(), jComboBoxSize_Width);
            int ID = 1;

            JComboBox temp = (JComboBox) e.getSource();
            iSelectCounts = temp.getSelectedIndex();
            System.out.println("selectCounts_Width = " + sSize[iSelectCounts]);
            jButtonInfo[ID].setWidth(Integer.parseInt(sSize[iSelectCounts]));
        }
    }

    class JComboBoxSizeActionListener_Height implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            int ID = 1;

            JComboBox temp = (JComboBox) e.getSource();
            iSelectCounts = temp.getSelectedIndex();
            System.out.println("selectCounts_Height = " + sSize[iSelectCounts]);
            jButtonInfo[ID].setHeight(Integer.parseInt(sSize[iSelectCounts]));
        }
    }

    class JButtonCountsActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println("sCounts[iSelectCounts] = " + sSize[iSelectCounts]);
            utilDB.updateCounts(Integer.parseInt(sCounts[iSelectCounts]));
        }
    }

    class JButtonSizeActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            int ID = 1;
            System.out.println("jButtonInfoSize_Height[1] = " + jButtonInfo[ID].getHeight());
            System.out.println("jButtonInfoSize_Width[1] = " + jButtonInfo[ID].getWidth());
        }
    }

    public static void main(String[] args) throws Exception {
        // new Menu();
        new Setup();
    }
}
