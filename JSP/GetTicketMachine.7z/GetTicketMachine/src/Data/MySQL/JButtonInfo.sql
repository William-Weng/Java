DROP TABLE GetTicketMachine._JButtonInfo; -- 刪除資料表

USE GetTicketMachine; -- 使用資料庫

CREATE TABLE GetTicketMachine._JButtonInfo(
	PrimaryKey INTEGER(3) AUTO_INCREMENT PRIMARY KEY NOT NULL, -- 主鍵值
	ID INTEGER(5) DEFAULT 0, -- JButton編號
	Width INTEGER(4), -- 寬
	Height INTEGER(4), -- 高
	X_Axis INTEGER(4), -- X坐標
	Y_Axis INTEGER(4), -- Y坐標
	Font VARCHAR(30) DEFAULT '----', -- 字體名稱
	FontSize VARCHAR(4) DEFAULT '----', -- 字體大小
	FontType VARCHAR(4) DEFAULT '----', -- 字體樣式
	FontColor VARCHAR(10) DEFAULT '----', -- 字體顏色
	Texts VARCHAR(4) DEFAULT '----', -- 文字內容
	FunctionCode VARCHAR(4) DEFAULT '0000', -- 功能識別碼
	InsertStaff VARCHAR(4) DEFAULT '0000', -- 修改人員
        InsertDate DATE DEFAULT '1970-01-01', -- 修改日期
        InsertTime TIME DEFAULT '00:00:00' -- 修改時間
);