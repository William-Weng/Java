DROP TABLE GetTicketMachine.Funtions; -- 刪除資料表

CREATE TABLE GetTicketMachine.Funtions(
    PrimaryKey INTEGER(2) AUTO_INCREMENT PRIMARY KEY, -- 主鍵值
    FuntionName VARCHAR(255), -- 功能名稱：一般業務
    FuntionCode VARCHAR(5), -- 功能代碼：L001
    RangeStart INTEGER(5), -- 開始：1001
    RangeEnd INTEGER(5), -- 結束：2000
    RangeRunning INTEGER(5) -- 正在執行的號碼
);