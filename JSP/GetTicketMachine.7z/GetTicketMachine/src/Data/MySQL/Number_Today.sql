DROP TABLE Customers.Number_Today; -- 刪除資料表

USE Customers; -- 使用資料庫

CREATE TABLE Number_Today(
	N_Code INTEGER(10) AUTO_INCREMENT PRIMARY KEY NOT NULL, -- 流水號
	Only_Code VARCHAR(10) DEFAULT '----', -- 設備專用碼
        U_ID VARCHAR(10) DEFAULT '----', -- 使用者ID
        Number_ID VARCHAR(10) DEFAULT '----', -- 號碼單號碼ID
        T_ID VARCHAR(10) DEFAULT '----', -- 轉櫃服務人員ID
        Today Date DEFAULT '1911-01-01', -- 使用者ID
        F_Time Time DEFAULT '00:00:00', -- 取號時間
        C_Time Time DEFAULT '00:00:00', -- 叫號時間
        T_Time Time DEFAULT '00:00:00', -- 結束時間
        Item Time DEFAULT '00:00:00', -- 功能代號
);