package Data.Model;

import Tools.MySQL.DatabaseUtility;

public class Counts {

    private int counts;

    public Counts() {
        DatabaseUtility utilDB = new DatabaseUtility();
        this.counts = utilDB.selectCounts();

        if (counts < 1) {
            this.counts = 2;
        }
    }

    public int getCounts() {
        return counts;
    }

    public void setCounts(int counts) {
        this.counts = counts;
    }
}
