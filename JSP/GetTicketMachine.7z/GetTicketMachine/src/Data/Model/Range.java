package Data.Model;

public class Range {

    private int running; // 正在叫號的數字
    private int start; // 開始範圍
    private int end; // 結東範圍
    private String funtions; // 功能代碼

    public Range() {
    }

    public Range(int start, int end) {
        this.start = start;
        this.end = end;
        this.running = start;
    }

    public int getRunning() {
        return running;
    }

    public int getStart() {
        return start;
    }

    public int getEnd() {
        return end;
    }

    public String getFuntions() {
        return funtions;
    }

    public void setRunning(int running) {
        this.running = running;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public void setEnd(int end) {
        this.end = end;
    }

    public void setFuntions(String funtions) {
        this.funtions = funtions;
    }
}
