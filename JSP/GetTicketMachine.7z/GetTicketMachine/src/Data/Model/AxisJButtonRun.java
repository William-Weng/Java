package Data.Model;

public class AxisJButtonRun {

    private int x_Axis; // X坐標
    private int y_Axis; // X坐標
    private int whichOne; // 第幾個

    public AxisJButtonRun() {
    }

    public AxisJButtonRun(int whichOne, SizeJButtonRun sizes) {
        this.x_Axis = sizes.getGap() * whichOne + sizes.getWidth() * (whichOne - 1);
        this.y_Axis = (int) (sizes.getHeightAll() * 0.1);
        this.whichOne = whichOne;
    }

    public int getX_Axis() {
        return x_Axis;
    }

    public int getY_Axis() {
        return y_Axis;
    }

    public int getWhichOne() {
        return whichOne;
    }

    public void setX_Axis(int x_Axis) {
        this.x_Axis = x_Axis;
    }

    public void setY_Axis(int y_Axis) {
        this.y_Axis = y_Axis;
    }

    public void setWhichOne(int whichOne) {
        this.whichOne = whichOne;
    }

}
