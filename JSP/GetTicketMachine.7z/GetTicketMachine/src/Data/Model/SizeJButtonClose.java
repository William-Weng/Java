package Data.Model;

public class SizeJButtonClose {

    private int x_Axis; // X坐標
    private int y_Axis; // X坐標
    private int width; // 寬
    private int height; // 高

    public SizeJButtonClose() {
    }

    public SizeJButtonClose(int x_Axis, int y_Axis, int width, int height) {
        this.x_Axis = x_Axis;
        this.y_Axis = y_Axis;
        this.width = width;
        this.height = height;
    }

    public int getX_Axis() {
        return x_Axis;
    }

    public int getY_Axis() {
        return y_Axis;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public void setX_Axis(int x_Axis) {
        this.x_Axis = x_Axis;
    }

    public void setY_Axis(int y_Axis) {
        this.y_Axis = y_Axis;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public void setHeight(int height) {
        this.height = height;
    }

}
