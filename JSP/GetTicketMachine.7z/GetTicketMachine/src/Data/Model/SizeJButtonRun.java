package Data.Model;

public class SizeJButtonRun {

    private int width; // 寬
    private int height; // 高
    private int widthAll; // 全寬
    private int heightAll; // 全高
    private int gap; // 間隔
    private int count; // 個數

    public SizeJButtonRun() {
    }

    public SizeJButtonRun(int count, int widthAll, int heightAll, int gap) {
        this.widthAll = widthAll;
        this.heightAll = heightAll;
        this.gap = gap;
        this.width = (widthAll - (count + 1) * gap) / count;
        this.height = (int) (heightAll * 0.8);
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public int getWidthAll() {
        return widthAll;
    }

    public int getHeightAll() {
        return heightAll;
    }

    public int getGap() {
        return gap;
    }

    public int getCount() {
        return count;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public void setWidthAll(int widthAll) {
        this.widthAll = widthAll;
    }

    public void setHeightAll(int heightAll) {
        this.heightAll = heightAll;
    }

    public void setGap(int gap) {
        this.gap = gap;
    }

    public void setCount(int count) {
        this.count = count;
    }

}
