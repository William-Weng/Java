package Data.Model;

public class JButtonInfo {

    private int primaryKey; // JButton編號
    private int id; // JButton編號
    private int width; // 寬
    private int height; // 高
    private int x_Axis; // X坐標
    private int y_Axis; // Y坐標    
    private String tableName; // 使用的資料表
    private String funtionCode; // 使用的功能代碼

    public JButtonInfo() {
        this.tableName = "GetTicketMachine.JButtonInfo";
    }

    public JButtonInfo(int id, int width, int height, int x_Axis, int y_Axis, String tableName) {
        this.id = id;
        this.width = width;
        this.height = height;
        this.x_Axis = x_Axis;
        this.y_Axis = y_Axis;
        this.tableName = tableName;
    }

    public int getPrimaryKey() {
        return primaryKey;
    }

    public int getId() {
        return id;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public int getX_Axis() {
        return x_Axis;
    }

    public int getY_Axis() {
        return y_Axis;
    }

    public String getTableName() {
        return tableName;
    }

    public String getFuntionCode() {
        return funtionCode;
    }

    public void setPrimaryKey(int primaryKey) {
        this.primaryKey = primaryKey;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public void setX_Axis(int x_Axis) {
        this.x_Axis = x_Axis;
    }

    public void setY_Axis(int y_Axis) {
        this.y_Axis = y_Axis;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public void setFuntionCode(String funtionCode) {
        this.funtionCode = funtionCode;
    }

}
