// ======文數字處理====== //
package Tools.Utility;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ProcessArray {

//--------------------將ArrayList轉成Array----------------------//
    public String[] ListToArray(List<String> list) {
        String[] arrayStr = null;

        if (!list.isEmpty()) { // ArrayList 轉 Array
            arrayStr = new String[list.size()];
            arrayStr = list.toArray(arrayStr);
        } else {
            arrayStr = new String[]{"0", "0000"};
        }
        return arrayStr;
    }

    
    //--------------------寫入檔案並讀出-------------------//
    public void WriteFile() {

        try (PrintWriter pw = new PrintWriter("D:\\CSV\\1.TXT");) { // 自動嘗試關閉資源…

            for (int i = 1; i <= 9; i++) {
                for (int j = 1; j <= 9; j++) {
                    pw.print(i + "*" + j + "=" + (i * j < 10 ? i * j + " " : i * j) + " ");
                }
                pw.println();
            }
            pw.flush();
            //pw.close();

            ReadFile("D:\\CSV\\1.TXT");
        } catch (IOException e) {
            System.out.println(e.toString());
        }
    }

    
    //--------------------讀取檔案並存成ArrayList-------------------//
    public List<String> ReadFile(String path) {

        //path = this.getClass().getResource(path).getPath();
        try {
            path = URLDecoder.decode(path, "UTF-8");
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(ProcessArray.class.getName()).log(Level.SEVERE, null, ex);
        }

        //System.out.println(path);
        List<String> list = null;

        try (FileReader fr = new FileReader(path);
                BufferedReader br = new BufferedReader(fr);) { // 自動嘗試關閉資源…

            list = new ArrayList();

            String data;
            while ((data = br.readLine()) != null) {
                //System.out.println(data);
                list.add(data);
            }
        } catch (IOException e) {
            System.out.println(e.toString());
        }

        return list;
    }
}
