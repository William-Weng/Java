package Tools.Utility;

public class ProcessFrame {

    //-------------------判斷按到哪一個Swing物件-------------------//
    public static int JObjectWhichOne(Object getSource, Object[] jObject) {
        for (int i = 0; i < jObject.length; i++) {
            if (getSource == jObject[i]) {
                return i;
            }
        }
        return 0;
    }
}
