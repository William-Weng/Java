package Tools.MySQL;

import Data.Model.JButtonInfo;
import java.util.List;

public class NewMain {

    public static void main(String[] args) {
        DatabaseUtility utilDB = new DatabaseUtility();
        JButtonInfo jButtonInfo = new JButtonInfo();
        utilDB.truncateTable("GetTicketMachine._JButtonInfo");
        jButtonInfo.setTableName("GetTicketMachine.JButtonInfo");
        List<JButtonInfo> _list = utilDB.select(jButtonInfo);

        for (int i = 0; i < _list.size(); i++) {
            _list.get(i).setTableName("GetTicketMachine._JButtonInfo");
            utilDB.insert(_list.get(i));
        }

        utilDB.truncateTable("GetTicketMachine.JButtonInfo");

        for (int i = 0; i < 10; i++) {
            jButtonInfo = new JButtonInfo(i, 100, 100, i * 100, 50, "GetTicketMachine.JButtonInfo");
            utilDB.insert(jButtonInfo);
        }

        for (int i = 0; i < _list.size(); i++) {
            utilDB.update(_list.get(i));
        }

    }
}
