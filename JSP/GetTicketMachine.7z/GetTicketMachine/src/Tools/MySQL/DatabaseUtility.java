// ======資料庫處理====== //
package Tools.MySQL;

import Data.Model.JButtonInfo;
import Data.Model.SQLConnentInfo;
import Tools.Utility.TimeNow;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DatabaseUtility implements Serializable {

//----------------------------------------------------變數宣告-----------------------------------------------------//
    private Connection conn = null;
    private Statement stat = null;
    private ResultSet rs = null;
    private PreparedStatement pst = null;

//---------------------------------------------------初始化函數---------------------------------------------------//
    public DatabaseUtility() {

        SQLConnentInfo infoSQL = new SQLConnentInfo();
        String driver = infoSQL.getDriver();
        String url = infoSQL.getUrl();
        String user = infoSQL.getUser();
        String password = infoSQL.getPassword();

        try {

            Class.forName(driver);
            conn = DriverManager.getConnection(url, user, password);

            if (conn != null && !conn.isClosed()) {
                System.out.println("資料庫連線測試成功…");
            }

        } catch (ClassNotFoundException eNotFound) {
            System.out.println("DriverClassNotFound :" + eNotFound.toString());
            System.out.println("資料庫驅動程式出錯…");
        } catch (SQLException eSQL) {
            System.out.println("Exception :" + eSQL.toString());
            System.out.println("資料庫帳號、密碼錯誤…");
        }
    }

    //-------------------------------------------------資料庫連線關閉-----------------------------------------------//
    public void closeSQL() {
        try {

            if (rs != null) {
                rs.close();
                rs = null;
            }
            if (stat != null) {
                stat.close();
                stat = null;
            }
            if (pst != null) {
                pst.close();
                pst = null;
            }

            System.out.println("資料庫連線關閉成功…");

        } catch (SQLException e) {
            System.out.println("Close Exception :" + e.toString());
            System.out.println("資料庫連線關閉失敗…");
        }
    }

    public List<JButtonInfo> select(JButtonInfo jButtonInfo) {

        String selectSQL = "SELECT * FROM " + jButtonInfo.getTableName() + " Order By ID";
        List<JButtonInfo> _list = new ArrayList();

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                jButtonInfo = setJButtonInfo();
                printJButtonInfo(jButtonInfo);

                _list.add(jButtonInfo);
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    public int selectCounts() {

        String selectSQL = "SELECT Counts FROM GetTicketMachine.CountDB WHERE PrimaryKey = 1";
        int counts = 1;

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(selectSQL);

            while (rs.next()) {
                System.out.println("Counts = " + rs.getInt("Counts"));
                counts = rs.getInt("Counts");
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return counts;
    }

    //------------------------------------------------------新增單一數據----------------------------------------------------//
    public void insert(JButtonInfo jButtonInfo) {

        String insertSQL = "INSERT INTO " + jButtonInfo.getTableName() + " "
                + "(ID, Width, Height, X_Axis, Y_Axis, InsertDate, InsertTime) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try {

            pst = conn.prepareStatement(insertSQL);

            pst.setInt(1, jButtonInfo.getId());
            pst.setInt(2, jButtonInfo.getWidth());
            pst.setInt(3, jButtonInfo.getHeight());
            pst.setInt(4, jButtonInfo.getX_Axis());
            pst.setInt(5, jButtonInfo.getY_Axis());
            pst.setDate(6, TimeNow.ToSqlDate());
            pst.setTime(7, TimeNow.ToSqlTime());

            pst.executeUpdate();

            System.out.println("資料庫連線新增成功…");

        } catch (SQLException e) {
            System.out.println("InsertDB Exception :" + e.toString());
            System.out.println("資料庫尚未建立…");
        } finally {
            closeSQL();
        }
    }

    //---------------------------------------------------修改單一資料表---------------------------------------------------//
    public void update(JButtonInfo jButtonInfo) {

        String updateSQL = "UPDATE " + jButtonInfo.getTableName() + " "
                + "SET Width = ?, Height = ?, X_Axis = ?, Y_Axis = ? "
                + "WHERE ID =  ?";

        try {

            pst = conn.prepareStatement(updateSQL);

            pst.setInt(1, jButtonInfo.getWidth());
            pst.setInt(2, jButtonInfo.getHeight());
            pst.setInt(3, jButtonInfo.getX_Axis());
            pst.setInt(4, jButtonInfo.getY_Axis());

            pst.setInt(5, jButtonInfo.getId());

            pst.executeUpdate();
            System.out.println("資料表更新成功…");

        } catch (SQLException e) {
            System.out.println("UpdateDB Exception :" + e.toString());
            System.out.println("資料表更新失敗…");
        } finally {
            closeSQL();
        }
    }

    public void updateCounts(int iCounts) {

        String updateSQL = "UPDATE GetTicketMachine.CountDB SET Counts = ?";

        try {

            pst = conn.prepareStatement(updateSQL);

            pst.setInt(1, iCounts);

            pst.executeUpdate();
            System.out.println("資料表更新成功…");

        } catch (SQLException e) {
            System.out.println("UpdateDB Exception :" + e.toString());
            System.out.println("資料表更新失敗…");
        } finally {
            closeSQL();
        }
    }

    public void truncateTable(String delTable) {

        String dropdbSQL = "TRUNCATE TABLE " + delTable;

        try {
            stat = conn.createStatement();
            stat.executeUpdate(dropdbSQL);
        } catch (SQLException e) {
            System.out.println("DropDB Exception :" + e.toString());
        } finally {
            closeSQL();
        }
    }

    public JButtonInfo setJButtonInfo() throws SQLException {

        JButtonInfo jButtonInfo = new JButtonInfo(); // 把Class資料清空

        jButtonInfo.setTableName("GetTicketMachine.JButtonInfo");
        jButtonInfo.setHeight(rs.getInt("Height"));
        jButtonInfo.setWidth(rs.getInt("Width"));
        jButtonInfo.setX_Axis(rs.getInt("X_Axis"));
        jButtonInfo.setY_Axis(rs.getInt("Y_Axis"));
        jButtonInfo.setId(rs.getInt("ID"));
        jButtonInfo.setPrimaryKey(rs.getInt("PrimaryKey"));

        return jButtonInfo;
    }

    public void printJButtonInfo(JButtonInfo jButtonInfo) {
        System.out.print("PrimaryKey = " + jButtonInfo.getPrimaryKey() + "\t");
        System.out.print("ID = " + jButtonInfo.getId() + "\t");
        System.out.print("Height = " + jButtonInfo.getHeight() + "\t");
        System.out.print("Width = " + jButtonInfo.getWidth() + "\t");
        System.out.print("X_Axis = " + jButtonInfo.getX_Axis() + "\t");
        System.out.print("Y_Axis = " + jButtonInfo.getY_Axis() + "\t");
        System.out.print("TableName = " + jButtonInfo.getTableName() + "\n");
    }
}
