
import Data.Model.CallNumberInfo;
import Tools.MySQL.DatabaseUtility;

public class Test {

    public static void main(String[] args) {

        DatabaseUtility utilDB = new DatabaseUtility();
        CallNumberInfo callNumberInfo = new CallNumberInfo();

        callNumberInfo.setUniformNumber("11111111");
        callNumberInfo.setSort("2人");

        callNumberInfo = utilDB.selectOne(callNumberInfo);

        callNumberInfo.setNow(callNumberInfo.getNow() + 1);
        callNumberInfo.setWaitting(callNumberInfo.getWaitting() + 1);

        utilDB.update(callNumberInfo);

        System.out.println("callNumberInfo  = " + callNumberInfo);
    }
}
