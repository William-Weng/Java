// ======資料庫處理====== //
package Tools.MySQL;

import Data.Model.CallNumberInfo;
import Data.Model.CompanyInfo;
import Data.Model.EmployeeInfo;
import Data.Model.GuestInfo;
import Data.Model.GuestInfoPlus;
import Data.Model.SQLConnentInfo;
import Tools.Utility.TimeNow;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DatabaseUtility implements Serializable {

//----------------------------------------------------變數宣告-----------------------------------------------------//
    private Connection conn = null;
    private Statement stat = null;
    private ResultSet rs = null;
    private PreparedStatement pst = null;

//---------------------------------------------------初始化函數---------------------------------------------------//
    public DatabaseUtility() {

        SQLConnentInfo infoSQL = new SQLConnentInfo();
        String driver = infoSQL.getDriver();
        String url = infoSQL.getUrl();
        String user = infoSQL.getUser();
        String password = infoSQL.getPassword();

        try {

            Class.forName(driver);
            conn = DriverManager.getConnection(url, user, password);

            if (conn != null && !conn.isClosed()) {
                System.out.println("資料庫連線測試成功…");
            }

        } catch (ClassNotFoundException eNotFound) {
            System.out.println("DriverClassNotFound :" + eNotFound.toString());
            System.out.println("資料庫驅動程式出錯…");
        } catch (SQLException eSQL) {
            System.out.println("Exception :" + eSQL.toString());
            System.out.println("資料庫帳號、密碼錯誤…");
        }
    }

    //-------------------------------------------------資料庫連線關閉-----------------------------------------------//
    private void closeSQL() {
        try {

            if (rs != null) {
                rs.close();
                rs = null;
            }
            if (stat != null) {
                stat.close();
                stat = null;
            }
            if (pst != null) {
                pst.close();
                pst = null;
            }

            System.out.println("資料庫連線關閉成功…");

        } catch (SQLException e) {
            System.out.println("Close Exception :" + e.toString());
            System.out.println("資料庫連線關閉失敗…");
        }
    }

    //--------------------[查詢列印資訊]--------------------//
    public List<CallNumberInfo> select(CallNumberInfo callNumberInfo) {

        callNumberInfo = new CallNumberInfo();
        String _selectSQL = "SELECT * FROM " + callNumberInfo.getTableName();
        List<CallNumberInfo> _list = null;

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(_selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                callNumberInfo = new CallNumberInfo(); // 把Class資料清空

                callNumberInfo.setCode(rs.getString("Code"));
                callNumberInfo.setEnd(rs.getInt("End"));
                callNumberInfo.setID(rs.getInt("ID"));
                callNumberInfo.setNow(rs.getInt("Now"));
                callNumberInfo.setSort(rs.getString("Sort"));
                callNumberInfo.setStart(rs.getInt("Start"));
                callNumberInfo.setTableName(rs.getString("TableName"));
                callNumberInfo.setUniformNumber(rs.getString("UniformNumber"));
                callNumberInfo.setUpdateTime(rs.getString("UpdateTime"));
                callNumberInfo.setWaitting(rs.getInt("Waitting"));

                _list.add(callNumberInfo);
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    //--------------------[查詢公司資訊]--------------------//
    public List<CompanyInfo> select(CompanyInfo companyInfo) {

        companyInfo = new CompanyInfo();
        String _selectSQL = "SELECT * FROM " + companyInfo.getTableName();
        List<CompanyInfo> _list = null;

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(_selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                companyInfo = new CompanyInfo(); // 把Class資料清空

                companyInfo.setCode(rs.getString("Code"));
                companyInfo.setId(rs.getInt("ID"));
                companyInfo.setName(rs.getString("Name"));
                companyInfo.setTableName(rs.getString("TableName"));
                companyInfo.setUniformNumber(rs.getString("UniformNumber"));
                companyInfo.setUpdateTime(rs.getString("UpdateTime"));

                _list.add(companyInfo);
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    //--------------------[查詢店員資訊]--------------------//
    public List<EmployeeInfo> select(EmployeeInfo employeeInfo) {

        employeeInfo = new EmployeeInfo();
        String _selectSQL = "SELECT * FROM " + employeeInfo.getTableName();
        List<EmployeeInfo> _list = null;

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(_selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                employeeInfo = new EmployeeInfo(); // 把Class資料清空

                employeeInfo.setAccount(rs.getString("Account"));
                employeeInfo.setCode(rs.getString("Code"));
                employeeInfo.setId(rs.getInt("ID"));
                employeeInfo.setName(rs.getString("Name"));
                employeeInfo.setPassword(rs.getString("Password"));
                employeeInfo.setTableName(rs.getString("TableName"));
                employeeInfo.setUniformNumber(rs.getString("UniformNumber"));
                employeeInfo.setUpdateTime(rs.getString("UpdateTime"));

                _list.add(employeeInfo);
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    //--------------------[查詢顧客資訊]--------------------//
    public List<GuestInfo> select(GuestInfo guestInfo) {

        String _selectSQL = "SELECT * FROM " + guestInfo.getTableName();
        List<GuestInfo> _list = null;

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(_selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                guestInfo = new GuestInfo(); // 把Class資料清空

                guestInfo.setCode(rs.getString("Code"));
                guestInfo.setId(rs.getInt("ID"));
                guestInfo.setPhone(rs.getString("Phone"));
                guestInfo.setNumber(rs.getString("Number"));
                guestInfo.setSort(rs.getString("Sort"));
                guestInfo.setTableName(rs.getString("TableName"));
                guestInfo.setUpdateTime(rs.getString("UpdateTime"));
                guestInfo.setUniformNumber(rs.getString("UniformNumber"));

                _list.add(guestInfo);
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    //--------------------[查詢列印資訊]--------------------//
    public CallNumberInfo selectOne(CallNumberInfo callNumberInfo) {

        String _selectSQL = "SELECT * FROM " + callNumberInfo.getTableName() + " WHERE UniformNumber = '" + callNumberInfo.getUniformNumber() + "' AND Sort = '" + callNumberInfo.getSort() + "'";

        System.out.println("_selectSQL = " + _selectSQL);

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(_selectSQL);

            while (rs.next()) {

                callNumberInfo = new CallNumberInfo(); // 把Class資料清空

                callNumberInfo.setCode(rs.getString("Code"));
                callNumberInfo.setEnd(rs.getInt("End"));
                callNumberInfo.setID(rs.getInt("ID"));
                callNumberInfo.setNow(rs.getInt("Now"));
                callNumberInfo.setSort(rs.getString("Sort"));
                callNumberInfo.setStart(rs.getInt("Start"));
                callNumberInfo.setTableName(rs.getString("TableName"));
                callNumberInfo.setUniformNumber(rs.getString("UniformNumber"));
                callNumberInfo.setUpdateTime(rs.getString("UpdateTime"));
                callNumberInfo.setWaitting(rs.getInt("Waitting"));
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return callNumberInfo;
    }

    //--------------------[查詢顧客資訊~加強版]--------------------//
    public List<GuestInfoPlus> select(GuestInfoPlus guestPlus) {

        String _selectSQL = "SELECT ads.guest.*, ads.company.Name FROM ads.guest Inner Join ads.company ON ads.guest.UniformNumber=ads.company.UniformNumber";
        List<GuestInfoPlus> _list = null;

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(_selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                guestPlus = new GuestInfoPlus(); // 把Class資料清空

                guestPlus.setCode(rs.getString("Code"));
                guestPlus.setId(rs.getInt("ID"));
                guestPlus.setName(rs.getString("Name"));
                guestPlus.setPhone(rs.getString("Phone"));
                guestPlus.setSort(rs.getString("Sort"));
                guestPlus.setTableName(rs.getString("TableName"));
                guestPlus.setUpdateTime(rs.getString("UpdateTime"));
                guestPlus.setUniformNumber(rs.getString("UniformNumber"));

                _list.add(guestPlus);
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    //--------------------[查詢列印資訊]--------------------//
    public List<CallNumberInfo> select(CallNumberInfo callNumberInfo, String uniformNumber) {

        callNumberInfo = new CallNumberInfo();
        String _selectSQL = "SELECT * FROM " + callNumberInfo.getTableName() + " WHERE UniformNumber = '" + uniformNumber + "'";
        List<CallNumberInfo> _list = null;

        try {

            stat = conn.createStatement();
            rs = stat.executeQuery(_selectSQL);
            _list = new ArrayList();

            while (rs.next()) {

                callNumberInfo = new CallNumberInfo(); // 把Class資料清空

                callNumberInfo.setCode(rs.getString("Code"));
                callNumberInfo.setEnd(rs.getInt("End"));
                callNumberInfo.setID(rs.getInt("ID"));
                callNumberInfo.setNow(rs.getInt("Now"));
                callNumberInfo.setSort(rs.getString("Sort"));
                callNumberInfo.setStart(rs.getInt("Start"));
                callNumberInfo.setTableName(rs.getString("TableName"));
                callNumberInfo.setUniformNumber(rs.getString("UniformNumber"));
                callNumberInfo.setUpdateTime(rs.getString("UpdateTime"));
                callNumberInfo.setWaitting(rs.getInt("Waitting"));

                _list.add(callNumberInfo);
            }

        } catch (SQLException e) {
            System.out.println("SelectTable Exception :" + e.toString());
            System.out.println("資料庫連線查詢失敗…");
        } finally {
            closeSQL();
        }
        return _list;
    }

    public void insert(GuestInfo guest) {

        String insertSQL = "INSERT INTO " + guest.getTableName() + " (Number, Phone, Sort, UniformNumber) VALUES (?, ?, ?, ?)";

        try {

            pst = conn.prepareStatement(insertSQL);

            pst.setString(1, guest.getNumber());
            pst.setString(2, guest.getPhone());
            pst.setString(3, guest.getSort());
            pst.setString(4, guest.getUniformNumber());

            pst.executeUpdate();

            System.out.println("資料庫連線新增成功…");

        } catch (SQLException e) {
            System.out.println("InsertDB Exception :" + e.toString());
            System.out.println("資料庫尚未建立…");
        } finally {
            closeSQL();
        }
    }

    //-------------------------------------------------資料庫刪除-----------------------------------------------//
    public void delete(String tableName, int ID) {

        String deleteSQL = "DELETE FROM " + tableName + " WHERE ID = ?";

        System.out.println("deleteSQL = " + deleteSQL);
        try {

            pst = conn.prepareStatement(deleteSQL);
            pst.setInt(1, ID);
            pst.executeUpdate();
            System.out.println("資料刪除成功…");

        } catch (SQLException e) {
            System.out.println("DeleteDB Exception :" + e.toString());
            System.out.println("資料表沒有可刪除的資料…");
        } finally {
            closeSQL();
        }
    }

    //---------------------------------------------------修改單一資料表---------------------------------------------------//
    public void update(CallNumberInfo callNumberInfo) {

        String updateSQL = "UPDATE " + callNumberInfo.getTableName() + " SET Now = ?, Waitting = ?, UpdateTime = ? WHERE UniformNumber = ? AND Sort = ?";

        System.out.println("updateSQL = " + updateSQL);

        try {

            pst = conn.prepareStatement(updateSQL);

            pst.setInt(1, callNumberInfo.getNow());
            pst.setInt(2, callNumberInfo.getWaitting());
            pst.setString(3, new TimeNow().getAllTime());
            pst.setString(4, callNumberInfo.getUniformNumber());
            pst.setString(5, callNumberInfo.getSort());

            pst.executeUpdate();
            System.out.println("資料表更新成功…");

        } catch (SQLException e) {
            System.out.println("UpdateDB Exception :" + e.toString());
            System.out.println("資料表更新失敗…");
        } finally {
            closeSQL();
        }
    }
//-----------------------------------------------------結束----------------------------------------------------------//
}
