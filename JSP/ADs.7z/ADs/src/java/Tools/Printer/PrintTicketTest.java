package Tools.Printer;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;

public class PrintTicketTest implements Printable {

    private int ticketInfoNumer;
    Image image;

    //--- Private instances declarations
    public void printTicket(int ticketInfoNumer) {

        this.ticketInfoNumer = ticketInfoNumer;

        PrinterJob printJob = PrinterJob.getPrinterJob();
        printJob.setPrintable(this);

        boolean OK = printJob.printDialog();
        //boolean OK = true;

        if (OK) {
            try {
                printJob.print();
            } catch (PrinterException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    @Override
    public int print(Graphics g, PageFormat pageFormat, int page) {

        Graphics2D g2d;

        //--- Validate the page number, we only print the first page
        if (page == 0) {  //--- Create a graphic2D object a set the default parameters

            g2d = (Graphics2D) g;
            g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY()); // 設定到(0,0)

            printString(g2d);
            return (PAGE_EXISTS);

        } else {
            return (NO_SUCH_PAGE);
        }
    }

    private void printString(Graphics2D g2d) {
        g2d.drawString("測試用", 10, 10 + g2d.getFontMetrics().getAscent());
    }

    public static void main(String[] args) {
        PrintTicketTest printTicketTest = new PrintTicketTest();
        printTicketTest.printTicket(1234);
    }
}
