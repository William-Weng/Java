DROP DATABASE IF EXISTS ADs;

DROP TABLE IF EXISTS ADs.Company;
DROP TABLE IF EXISTS ADs.Employee;
DROP TABLE IF EXISTS ADs.CallNumber;

CREATE DATABASE ADs;

CREATE TABLE ADs.Company ( -- 公司資訊
	ID INTEGER(3) PRIMARY KEY AUTO_INCREMENT NOT NULL , -- 流水編號
	Name VARCHAR(20) NOT NULL DEFAULT '----', -- 公司名稱
	UniformNumber VARCHAR(20) NOT NULL DEFAULT '----' , -- 公司統編
	UpdateTime TIMESTAMP DEFAULT CURRENT_TIMESTAMP , -- 更新時間
	TableName VARCHAR(20) NOT NULL DEFAULT 'Company' , -- 資料表名
	Code VARCHAR(255) NOT NULL DEFAULT '----' -- 其它功能	
	);

CREATE TABLE ADs.Employee ( -- 店員資訊
	ID INTEGER(3) PRIMARY KEY AUTO_INCREMENT NOT NULL , -- 流水編號
	Name VARCHAR(20) NOT NULL DEFAULT '----', -- 店員名稱
	Account VARCHAR(20) NOT NULL DEFAULT '----', -- 店員帳號
	Password VARCHAR(20) NOT NULL DEFAULT '----', -- 店員密碼
	UniformNumber VARCHAR(20) NOT NULL DEFAULT '----' , -- 公司統編
	UpdateTime TIMESTAMP DEFAULT CURRENT_TIMESTAMP , -- 更新時間
	TableName VARCHAR(20) NOT NULL DEFAULT 'Employee' , -- 資料表名
	Code VARCHAR(255) NOT NULL DEFAULT '----' -- 其它功能	
	);
	
CREATE TABLE ADs.CallNumber ( -- 列印資訊
	ID INTEGER(10) PRIMARY KEY AUTO_INCREMENT NOT NULL , -- 流水編號
	Start INTEGER(4) NOT NULL DEFAULT 0, -- 開始號碼
	End INTEGER(4) NOT NULL DEFAULT 0, -- 結束號碼
	Now INTEGER(4) NOT NULL DEFAULT 0, -- 現在號碼
	Sort VARCHAR(20) NOT NULL DEFAULT '----', -- 列印分類
	Waitting INTEGER(3) NOT NULL DEFAULT 0 , -- 等待人數
	UniformNumber VARCHAR(8) NOT NULL DEFAULT '----' , -- 公司統編
	UpdateTime TIMESTAMP DEFAULT CURRENT_TIMESTAMP , -- 更新時間
	TableName VARCHAR(20) NOT NULL DEFAULT 'CallNumber' , -- 資料表名
	Code VARCHAR(255) NOT NULL DEFAULT '----' -- 其它功能	
	);

CREATE TABLE ADs.Guest ( -- 顧客歷史
	ID INTEGER(5) PRIMARY KEY AUTO_INCREMENT NOT NULL , -- 流水編號
	Phone VARCHAR(20) NOT NULL DEFAULT '----', -- 顧客電話
	UniformNumber VARCHAR(8) NOT NULL DEFAULT '----', -- 店家統編
	Number VARCHAR(20) NOT NULL DEFAULT '----', -- 抽到號碼
	Sort VARCHAR(20) NOT NULL DEFAULT '----', -- 人數分類
	UpdateTime TIMESTAMP DEFAULT CURRENT_TIMESTAMP , -- 更新時間
	TableName VARCHAR(20) NOT NULL DEFAULT 'Guest' , -- 資料表名
	Code VARCHAR(255) NOT NULL DEFAULT '----' -- 其它功能	
	);
	
INSERT INTO ADs.Company (Name, UniformNumber) VALUES ('7-11', '11111111');
INSERT INTO ADs.Company (Name, UniformNumber) VALUES ('全家', '22222222');
INSERT INTO ADs.Company (Name, UniformNumber) VALUES ('萊爾富', '33333333');
INSERT INTO ADs.Company (Name, UniformNumber) VALUES ('OK', '44444444');

INSERT INTO ADs.Employee (Name, Account, Password, UniformNumber) VALUES ('煒真A', 'jhen', '810725', '11111111');
INSERT INTO ADs.Employee (Name, Account, Password, UniformNumber) VALUES ('維益A', 'one', '710805', '11111111');
INSERT INTO ADs.Employee (Name, Account, Password, UniformNumber) VALUES ('小翁A', 'william', '680609', '11111111');
INSERT INTO ADs.Employee (Name, Account, Password, UniformNumber) VALUES ('煒真B', 'jhen', '810725', '22222222');
INSERT INTO ADs.Employee (Name, Account, Password, UniformNumber) VALUES ('維益B', 'one', '710805', '22222222');
INSERT INTO ADs.Employee (Name, Account, Password, UniformNumber) VALUES ('小翁B', 'william', '680609', '22222222');
INSERT INTO ADs.Employee (Name, Account, Password, UniformNumber) VALUES ('煒真C', 'jhen', '810725', '33333333');
INSERT INTO ADs.Employee (Name, Account, Password, UniformNumber) VALUES ('維益C', 'one', '710805', '33333333');
INSERT INTO ADs.Employee (Name, Account, Password, UniformNumber) VALUES ('小翁C', 'william', '680609', '33333333');	
	
INSERT INTO ADs.CallNumber (Start, End, Now, Sort, Waitting, UniformNumber) VALUES (0, 1000, 0, '1人', 0, '11111111');
INSERT INTO ADs.CallNumber (Start, End, Now, Sort, Waitting, UniformNumber) VALUES (1000, 2000, 1000, '2人', 0, '11111111');
INSERT INTO ADs.CallNumber (Start, End, Now, Sort, Waitting, UniformNumber) VALUES (2000, 3000, 2000, '3人', 0, '11111111');
INSERT INTO ADs.CallNumber (Start, End, Now, Sort, Waitting, UniformNumber) VALUES (3000, 4000, 3000, '4~5人', 0, '11111111');
INSERT INTO ADs.CallNumber (Start, End, Now, Sort, Waitting, UniformNumber) VALUES (0, 1000, 0, '1人', 0, '22222222');
INSERT INTO ADs.CallNumber (Start, End, Now, Sort, Waitting, UniformNumber) VALUES (1000, 2000, 2000, '2人', 0, '22222222');
INSERT INTO ADs.CallNumber (Start, End, Now, Sort, Waitting, UniformNumber) VALUES (2000, 3000, 3000, '3人', 0, '22222222');
INSERT INTO ADs.CallNumber (Start, End, Now, Sort, Waitting, UniformNumber) VALUES (3000, 4000, 4000, '4~5人', 0, '22222222');
INSERT INTO ADs.CallNumber (Start, End, Now, Sort, Waitting, UniformNumber) VALUES (0, 1000, 0, '1人', 0, '33333333');
INSERT INTO ADs.CallNumber (Start, End, Now, Sort, Waitting, UniformNumber) VALUES (1000, 2000, 2000, '2人', 0, '33333333');
INSERT INTO ADs.CallNumber (Start, End, Now, Sort, Waitting, UniformNumber) VALUES (2000, 3000, 3000, '3人', 0, '33333333');
INSERT INTO ADs.CallNumber (Start, End, Now, Sort, Waitting, UniformNumber) VALUES (3000, 4000, 4000, '4~5人', 0, '33333333');

INSERT INTO ADs.Guest (Phone, UniformNumber, Number, Sort) VALUES ('0916670057', '11111111', '1', '1人');
INSERT INTO ADs.Guest (Phone, UniformNumber, Number, Sort) VALUES ('0926670057', '22222222', '2', '2人');
INSERT INTO ADs.Guest (Phone, UniformNumber, Number, Sort) VALUES ('0936670057', '33333333', '3', '3人');
INSERT INTO ADs.Guest (Phone, UniformNumber, Number, Sort) VALUES ('0946670057', '44444444', '4', '4~5人');
INSERT INTO ADs.Guest (Phone, UniformNumber, Number, Sort) VALUES ('0916670057', '11111111', '5', '4~5人');
INSERT INTO ADs.Guest (Phone, UniformNumber, Number, Sort) VALUES ('0926670057', '22222222', '6', '3人');
INSERT INTO ADs.Guest (Phone, UniformNumber, Number, Sort) VALUES ('0936670057', '33333333', '7', '2人');
INSERT INTO ADs.Guest (Phone, UniformNumber, Number, Sort) VALUES ('0946670057', '44444444', '8', '1人');
