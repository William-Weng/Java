// =====資料庫連接相關數據===== //
package Data.Model;

public class GuestInfoPlus extends GuestInfo {

    private String name; // 店家名稱

    //--------------------[初始化變數]--------------------//
    public GuestInfoPlus() {
        super();
    }

    public GuestInfoPlus(String phone, String uniformNumber, String number, String sort, String name) {
        super(phone, uniformNumber, number, sort);
        this.name = name;
    }

    //--------------------[自定義輸出格式]--------------------//
    //--------------------[設定、取值]--------------------//
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
