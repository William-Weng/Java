// =====資料庫連接相關數據===== //
package Data.Model;

public class GuestInfo {

    private int id; // 流水編號
    private String phone; // 顧客電話
    private String uniformNumber; // 店家統編
    private String number; // 抽到號碼
    private String sort; // 人數分類
    private String updateTime; // 更新時間
    private String code; // 其它功能
    private String tableName; // 資料表名

    //--------------------[初始化變數]--------------------//
    public GuestInfo() {
        this.tableName = "Guest";
    }

    public GuestInfo(String phone, String uniformNumber, String number, String sort) {
        this();
        this.phone = phone;
        this.uniformNumber = uniformNumber;
        this.number = number;
        this.sort = sort;
    }

    //--------------------[自定義輸出格式]--------------------//
    //--------------------[設定、取值]--------------------//
    public int getId() {
        return id;
    }

    public String getPhone() {
        return phone;
    }

    public String getUniformNumber() {
        return uniformNumber;
    }

    public String getNumber() {
        return number;
    }

    public String getSort() {
        return sort;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public String getCode() {
        return code;
    }

    public String getTableName() {
        return tableName;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setUniformNumber(String uniformNumber) {
        this.uniformNumber = uniformNumber;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

}
