// =====資料庫連接相關數據===== //
package Data.Model;

public class CompanyInfo {

    private int id; // 流水編號
    private String name; // 公司名稱
    private String uniformNumber; // 公司統編
    private String updateTime; // 更新時間
    private String code; // 其它功能
    private String tableName; // 資料表名

    //--------------------[初始化變數]--------------------//
    public CompanyInfo() {
        this.tableName = "Company";
    }

    public CompanyInfo(String name, String uniformNumber) {
        this();
        this.name = name;
        this.uniformNumber = uniformNumber;
    }

    //--------------------[自定義輸出格式]--------------------//
    //--------------------[設定、取值]--------------------//
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getUniformNumber() {
        return uniformNumber;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public String getCode() {
        return code;
    }

    public String getTableName() {
        return tableName;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setUniformNumber(String uniformNumber) {
        this.uniformNumber = uniformNumber;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
}
