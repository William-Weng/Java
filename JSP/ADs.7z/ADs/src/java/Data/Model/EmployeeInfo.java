// =====資料庫連接相關數據===== //
package Data.Model;

public class EmployeeInfo {

    private int id; // 流水編號
    private String name; // 店員名稱
    private String account; // 店員帳號
    private String password; // 店員密碼
    private String uniformNumber; // 公司統編
    private String updateTime; // 更新時間
    private String code; // 其它功能
    private String tableName; // 資料表名

    //--------------------[初始化變數]--------------------//
    public EmployeeInfo() {
        this.tableName = "Employee";
    }

    public EmployeeInfo(String name, String account, String password, String uniformNumber) {
        this();
        this.name = name;
        this.uniformNumber = uniformNumber;
        this.account = account;
        this.password = password;
    }

    //--------------------[自定義輸出格式]--------------------//
    //--------------------[設定、取值]--------------------//
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAccount() {
        return account;
    }

    public String getPassword() {
        return password;
    }

    public String getUniformNumber() {
        return uniformNumber;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public String getCode() {
        return code;
    }

    public String getTableName() {
        return tableName;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUniformNumber(String uniformNumber) {
        this.uniformNumber = uniformNumber;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
}
