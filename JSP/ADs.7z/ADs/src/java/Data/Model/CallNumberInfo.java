// =====資料庫連接相關數據===== //
package Data.Model;

public class CallNumberInfo {

    private int id; // 流水編號
    private int start; // 開始號碼
    private int end; // 結束號碼
    private int now; // 現在號碼
    private int waitting; // 等待人數
    private String sort; // 列印分類
    private String uniformNumber; // 公司統編
    private String updateTime; // 更新時間
    private String tableName; // 資料表名
    private String code; // 其它功能

    //--------------------[初始化變數]--------------------//
    public CallNumberInfo() {
        this.tableName = "CallNumber";
    }

    //--------------------[自定義輸出格式]--------------------//
    @Override
    public String toString() {
        String _tab = "\t";
        String _str = this.getID() + _tab + this.getStart() + _tab + this.getEnd() + _tab + this.getNow() + _tab + this.getSort() + _tab + this.getWaitting() + _tab + this.getUniformNumber() + _tab + this.getUpdateTime() + _tab + this.getTableName() + _tab + this.getCode();
        return _str;
    }

    //--------------------[設定、取值]--------------------//
    public int getID() {
        return id;
    }

    public int getStart() {
        return start;
    }

    public int getEnd() {
        return end;
    }

    public int getNow() {
        return now;
    }

    public int getWaitting() {
        return waitting;
    }

    public String getSort() {
        return sort;
    }

    public String getUniformNumber() {
        return uniformNumber;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public String getTableName() {
        return tableName;
    }

    public String getCode() {
        return code;
    }

    public void setID(int id) {
        this.id = id;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public void setEnd(int end) {
        this.end = end;
    }

    public void setNow(int now) {
        this.now = now;
    }

    public void setWaitting(int waitting) {
        this.waitting = waitting;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    public void setUniformNumber(String uniformNumber) {
        this.uniformNumber = uniformNumber;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
