package Java.Servlet;

import Data.Model.CallNumberInfo;
import Data.Model.CompanyInfo;
import Data.Model.EmployeeInfo;
import Data.Model.GuestInfo;
import Tools.MySQL.DatabaseUtility;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/hello.update"})

public class Update extends HttpServlet {

    int id;
    String keyword, name, password;
    DatabaseUtility utilDB;
    String _type;

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String tableName = "";
        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        keyword = request.getParameter("KEYWORD");
        name = request.getParameter("name");
        password = request.getParameter("password");
        _type = request.getParameter("type");
        if (name.equalsIgnoreCase("root") && password.equalsIgnoreCase("1234")) {

            utilDB = new DatabaseUtility();

            switch (keyword) {
                case "CallNumber":
                    tableName = new CallNumberInfo().getTableName();

                    String uniformNumber = request.getParameter("uniformNumber");
                    String sort = request.getParameter("sort");
                    String type = request.getParameter("type");

                    CallNumberInfo callNumberInfo = new CallNumberInfo(); // 讀取舊資料

                    callNumberInfo.setUniformNumber(uniformNumber); // 設定搜尋條件
                    callNumberInfo.setSort(sort);

                    callNumberInfo = utilDB.selectOne(callNumberInfo);

                    switch (type) {
                        case "add":
                            callNumberInfo.setNow(callNumberInfo.getNow() + 1); // 現在號碼+1
                            callNumberInfo.setWaitting(callNumberInfo.getWaitting() + 1); // 等待人數+1
                            break;
                        case "minus":
                            callNumberInfo.setNow(callNumberInfo.getNow()); // 現在號碼不變
                            callNumberInfo.setWaitting(callNumberInfo.getWaitting() - 1); // 等待人數-1
                            break;
                        default:
                            break;
                    }

                    utilDB.update(callNumberInfo);

                    break;

                case "Company":
                    tableName = new CompanyInfo().getTableName();
                    break;

                case "Employee":
                    tableName = new EmployeeInfo().getTableName();
                    break;

                case "Guest":
                    tableName = new GuestInfo().getTableName();
                    break;
            }

            isOK(response, out, keyword);

        } else {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            out.write("帳號、密碼錯誤… (╥﹏╥)");
            System.out.println("帳號、密碼錯誤… (╥﹏╥)");
        }
    }

    public void isOK(HttpServletResponse response, PrintWriter out, String keyword) {
        response.setStatus(HttpServletResponse.SC_OK);
        out.write(keyword + " 修改成功… (｡◕∀◕｡)" + _type);
        System.out.println(keyword + " 修改成功… (｡◕∀◕｡)");
    }
}
