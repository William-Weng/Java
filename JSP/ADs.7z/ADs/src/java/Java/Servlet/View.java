package Java.Servlet;

import Data.Model.GuestInfo;
import Data.Model.GuestInfoPlus;
import Tools.MySQL.DatabaseUtility;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@WebServlet(urlPatterns = {"/hello.view"})

public class View extends HttpServlet implements Serializable {

    private List<GuestInfo> listGuestInfo;

    String start = "{";
    String end = "}";
    String colon = ":";
    String comma = ",";
    String name, password, uniformNumber;

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        name = request.getParameter("name");
        password = request.getParameter("password");
        uniformNumber = request.getParameter("uniformNumber");

        if (name.equalsIgnoreCase("root") && password.equalsIgnoreCase("1234")) {
            getJSON(response);
            response.setStatus(HttpServletResponse.SC_OK);
        } else {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            out.write("帳號、密碼錯誤… (╥﹏╥)");
        }
        System.out.println(response.getStatus());
    }

    public void getJSON(HttpServletResponse response) throws ServletException, IOException {

        //準備使用者資料
        DatabaseUtility utilDB = new DatabaseUtility();

        String guestInfoPlusName = "\"" + new GuestInfoPlus().getTableName() + "\"";

        try (PrintWriter out = response.getWriter()) {

            listGuestInfo = utilDB.select(new GuestInfo());

            JSONArray array = new JSONArray();

            out.write(start + guestInfoPlusName + colon);

            for (GuestInfo bean : listGuestInfo) {

                JSONObject obj = new JSONObject();

                try {
                    obj.put("Code", bean.getCode());
                    obj.put("ID", bean.getId());
                    obj.put("Number", bean.getNumber());
                    obj.put("Phone", bean.getPhone());
                    obj.put("Sort", bean.getSort());
                    obj.put("TableName", bean.getTableName());
                    obj.put("UniformNumber", bean.getUniformNumber());
                    obj.put("UpdateTime", bean.getUpdateTime().substring(0, 19));
                } catch (JSONException e) {
                    System.out.println(e.getMessage());
                }
                array.put(obj);
            }

            out.write(array.toString() + end);
            out.flush();
        }
    }
}
