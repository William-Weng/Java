package Java.Servlet;

import Data.Model.GuestInfo;
import Tools.MySQL.DatabaseUtility;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/hello.insert"})

public class Insert extends HttpServlet {

    DatabaseUtility utilDB;
    String keyword, name, password;

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        keyword = request.getParameter("KEYWORD");
        name = request.getParameter("name");
        password = request.getParameter("password");

        if (name.equalsIgnoreCase("root") && password.equalsIgnoreCase("1234")) {

            switch (keyword) {
                case "CallNumber":
                    break;

                case "Company":
                    break;

                case "Employee":
                    break;

                case "Guest":

                    String phone = request.getParameter("phone");
                    String uniformNumber = request.getParameter("uniformNumber");
                    String number = request.getParameter("number");
                    String sort = request.getParameter("sort");

                    utilDB = new DatabaseUtility();

                    GuestInfo guest = new GuestInfo(phone, uniformNumber, number, sort);

                    utilDB.insert(guest);

                    response.setStatus(HttpServletResponse.SC_OK);
                    out.write("Guest 新增成功… (｡◕∀◕｡)");
                    System.out.println("Guest 新增成功… (｡◕∀◕｡)");

                    break;
            }
        } else {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            out.write("帳號、密碼錯誤… (╥﹏╥)");
            System.out.println("帳號、密碼錯誤… (╥﹏╥)");
        }
    }
}
