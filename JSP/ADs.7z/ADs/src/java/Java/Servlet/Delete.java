package Java.Servlet;

import Data.Model.CallNumberInfo;
import Data.Model.CompanyInfo;
import Data.Model.EmployeeInfo;
import Data.Model.GuestInfo;
import Tools.MySQL.DatabaseUtility;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/hello.delete"})

public class Delete extends HttpServlet {

    int id;
    String keyword, name, password;
    DatabaseUtility utilDB;

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String tableName = "";
        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        keyword = request.getParameter("KEYWORD");
        name = request.getParameter("name");
        password = request.getParameter("password");
        id = Integer.parseInt(request.getParameter("ID"));

        if (name.equalsIgnoreCase("root") && password.equalsIgnoreCase("1234")) {

            utilDB = new DatabaseUtility();

            switch (keyword) {
                case "CallNumber":
                    tableName = new CallNumberInfo().getTableName();
                    break;

                case "Company":
                    tableName = new CompanyInfo().getTableName();
                    break;

                case "Employee":
                    tableName = new EmployeeInfo().getTableName();
                    break;
                case "Guest":
                    tableName = new GuestInfo().getTableName();
                    break;
            }

            utilDB.delete(tableName, id);
            isOK(response, out, keyword);
        } else {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            out.write("帳號、密碼錯誤… (╥﹏╥)");
            System.out.println("帳號、密碼錯誤… (╥﹏╥)");
        }
    }

    public void isOK(HttpServletResponse response, PrintWriter out, String keyword) {
        response.setStatus(HttpServletResponse.SC_OK);
        out.write(keyword + " 刪除成功… (｡◕∀◕｡)");
        System.out.println(keyword + " 刪除成功… (｡◕∀◕｡)");
    }
}
